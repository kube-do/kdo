# TROUBLESHOOTING.md — 故障排查知识库

> 记录故障排查知识、根本原因和解决方案。积累机构记忆。

---

## 最后更新：2026-07-17

---

## 模板：添加新条目

```
## Problem: <标题>

### Symptoms
- <可观察到的症状 1>
- <可观察到的症状 2>

### Root Cause
<技术原因>

### Fix
<解决步骤>

### Prevention
<如何防止再次发生>

### Related Skills
- skill:cluster-ops:health-check
- skill:observability:alert-triage
```

---

## 常见问题模式

### 集群问题

| 问题 | 快速检查 | 技能 |
|---------|-------------|-------|
| Node Not Ready | `kubectl get nodes` | cluster-ops:health-check |
| API Server Down | `kubectl cluster-info` | cluster-ops:health-check |
| Pod CrashLoopBackOff | `kubectl describe pod <name>` | dev-experience:debug-pod |
| etcd 问题 | `kubectl exec -n kube-system etcd-0 -- etcdctl` | cluster-ops:etcd-backup |

### GitOps 问题

| 问题 | 快速检查 | 技能 |
|---------|-------------|-------|
| 同步失败 | `argocd app get <app>` | gitops:argocd-app-sync |
| 检测到漂移 | `argocd app diff <app>` | gitops:drift-detect |
| Helm 升级失败 | `helm list -A` | gitops:helm-diff |

### 安全问题

| 问题 | 快速检查 | 技能 |
|---------|-------------|-------|
| RBAC 配置错误 | `kubectl auth can-i` | security:rbac-audit |
| 镜像存在漏洞 | `trivy image <image>` | security:image-scan |
| 密钥泄露 | 检查 Pod 日志/环境 | security:secret-rotation |

---

## KDO 平台问题解决方案

> 所有 KDO 平台问题，优先参考官方文档：https://docs.kube-do.cn/

### 应用管理问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| 应用无法创建 | [应用管理](https://docs.kube-do.cn/docs/dev/applications/) | 1. 检查命名空间 2. 检查配额 3. 检查权限 |
| 工作负载异常 | [工作负载](https://docs.kube-do.cn/docs/dev/workloads/) | 1. `kubectl get pods -n <ns>` 2. `kubectl describe pod <name>` 3. 检查日志 |
| ConfigMap/Secret 问题 | [配置管理](https://docs.kube-do.cn/docs/dev/configurations/) | 1. 检查 YAML 语法 2. 检查挂载路径 3. 检查权限 |
| 存储挂载失败 | [存储](https://docs.kube-do.cn/docs/dev/network-stroage/) | 1. 检查 PVC 状态 2. 检查 StorageClass 3. 检查节点存储 |
| Service/Ingress 问题 | [网络](https://docs.kube-do.cn/docs/dev/network-stroage/) | 1. 检查 Endpoints 2. 检查端口 3. 检查 DNS |

### 工作负载操作问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| PDB 创建失败 | [创建 PDB](https://docs.kube-do.cn/docs/workload-actions/pdb/) | 1. 检查选择器匹配 2. 检查副本数 3. 检查命名空间 |
| HPA 不生效 | [创建 HPA](https://docs.kube-do.cn/docs/workload-actions/hpa/) | 1. 检查指标 2. 检查资源限制 3. 检查副本数范围 |
| 滚动更新卡住 | [更新策略](https://docs.kube-do.cn/docs/workload-actions/edit-update-strategy/) | 1. 检查 PDB 2. 检查资源 3. 检查健康检查 |
| 健康检查失败 | [健康检查](https://docs.kube-do.cn/docs/workload-actions/edit-health-checks/) | 1. 检查探针路径 2. 检查端口 3. 检查超时设置 |
| 资源限制冲突 | [资源](https://docs.kube-do.cn/docs/workload-actions/edit-resource-limits/) | 1. 检查 ResourceQuota 2. 检查 LimitRange 3. 调整 requests/limits |

### DevOps 流水线问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| 流水线创建失败 | [创建流水线](https://docs.kube-do.cn/docs/dev/applications/pipelines/) | 1. 检查 Tekton 2. 检查权限 3. 检查 Git 仓库 |
| 应用部署失败 | [应用部署](https://docs.kube-do.cn/docs/devops/app-deploy/) | 1. 检查构建日志 2. 检查镜像 3. 检查部署配置 |
| GitFlow 配置错误 | [GitFlow](https://docs.kube-do.cn/docs/devops/gitflow/) | 1. 检查分支策略 2. 检查钩子 3. 检查权限 |
| 持续交付失败 | [持续交付](https://docs.kube-do.cn/docs/devops/continuous/) | 1. 检查环境 2. 检查审批 3. 检查回滚配置 |
| 项目权限问题 | [项目管理](https://docs.kube-do.cn/docs/devops/project-manage/) | 1. 检查 RBAC 2. 检查用户组 3. 检查项目配额 |

### 可观测性问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| 监控数据缺失 | [监控](https://docs.kube-do.cn/docs/observability/monitoring/) | 1. 检查 Prometheus 2. 检查 Grafana 3. 检查指标采集 |
| 日志无法查询 | [日志](https://docs.kube-do.cn/docs/observability/logging/) | 1. 检查 Loki 2. 检查日志采集 3. 检查查询语法 |
| 事件记录缺失 | [事件](https://docs.kube-do.cn/docs/observability/events/ | 1. 检查 EventServer 2. 检查事件过滤 3. 检查存储 |

### RBAC 与用户管理问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| 认证失败 | [认证](https://docs.kube-do.cn/docs/rbac/) | 1. 检查 OIDC 2. 检查证书 3. 检查 Token |
| 权限不足 | [授权](https://docs.kube-do.cn/docs/rbac/) | 1. 检查 Role 2. 检查 RoleBinding 3. 检查 ServiceAccount |
| 用户无法登录 | [用户管理](https://docs.kube-do.cn/docs/user/) | 1. 检查用户状态 2. 检查密码 3. 检查外部认证 |
| 组权限不生效 | [用户组管理](https://docs.kube-do.cn/docs/user/) | 1. 检查组成员 2. 检查角色绑定 3. 检查继承关系 |
| ServiceAccount 问题 | [ServiceAccount](https://docs.kube-do.cn/docs/rbac/) | 1. 检查 Secret 2. 检查权限 3. 检查自动挂载 |

### 运维管理问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| 节点状态异常 | [节点](https://docs.kube-do.cn/docs/admin/management/nodes/) | 1. 检查节点 conditions 2. 检查资源 3. 检查网络 |
| 命名空间问题 | [命名空间](https://docs.kube-do.cn/docs/admin/management/namespaces/) | 1. 检查状态 2. 检查配额 3. 检查标签 |
| 配额不足 | [配额](https://docs.kube-do.cn/docs/admin/management/resourcequotas/) | 1. 检查使用量 2. 检查限制 3. 调整配额 |
| LimitRange 冲突 | [限制范围](https://docs.kube-do.cn/docs/admin/management/limitranges/) | 1. 检查默认值 2. 检查范围 3. 调整限制 |
| CRD 问题 | [CRD](https://docs.kube-do.cn/docs/admin/management/customresourcedefinitions/) | 1. 检查定义 2. 检查实例 3. 检查控制器 |

### 云终端问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| CloudShell 无法连接 | [CloudShell](https://docs.kube-do.cn/docs/terminal/) | 1. 检查网络 2. 检查权限 3. 检查镜像 |
| LocalShell 连接失败 | [LocalShell](https://docs.kube-do.cn/docs/terminal/) | 1. 检查 kubectl 2. 检查配置 3. 检查网络 |
| 终端命令执行失败 | [终端](https://docs.kube-do.cn/docs/terminal/) | 1. 检查权限 2. 检查资源 3. 检查日志 |

### AI 助手问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| AI 助手无响应 | [AI 助手](https://docs.kube-do.cn/docs/aiops/) | 1. 检查 Ollama 2. 检查模型 3. 检查网络 |
| AIOps 功能异常 | [AIOps](https://docs.kube-do.cn/docs/aiops/) | 1. 检查配置 2. 检查数据源 3. 检查权限 |

### 应用商店问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| OperatorHub 无法访问 | [OperatorHub](https://docs.kube-do.cn/docs/admin/application-management/operator-hub/) | 1. 检查网络 2. 检查 CatalogSource 3. 检查权限 |
| Operator 安装失败 | [Operator 管理](https://docs.kube-do.cn/docs/admin/application-management/operators/) | 1. 检查依赖 2. 检查权限 3. 检查日志 |

### 集群配置问题

| 问题场景 | 官方文档 | 排查步骤 |
|---------|----------|----------|
| KDO 控制台异常 | [KDO Web 控制台](https://docs.kube-do.cn/docs/config/console/) | 1. 检查服务状态 2. 检查配置 3. 检查日志 |
| 平台安装问题 | [安装](https://docs.kube-do.cn/docs/install/kdo/) | 1. 检查前置条件 2. 检查配置 3. 检查网络 |

---

## KDO 平台故障模式速查

> 基于实际集群分析的常见故障模式，详见 [[wiki/platform/kdo-troubleshooting-patterns]]

### Pod 故障模式

| 故障模式 | 症状 | 快速排查 |
|---------|------|----------|
| ImagePullBackOff | Pod 无法拉取镜像 | `kubectl describe pod <name>` |
| CrashLoopBackOff | Pod 反复重启 | `kubectl logs <name> --previous` |
| Pending | Pod 卡在等待 | `kubectl describe pod <name>` |
| OOMKilled | 内存不足被杀 | `kubectl describe pod <name>` |
| Init:Error | 初始化容器失败 | `kubectl logs <name> -c init` |

### 流水线故障模式

| 故障模式 | 症状 | 快速排查 |
|---------|------|----------|
| Git 认证失败 | 无法拉取代码 | 检查 Git 凭证 Secret |
| 镜像构建失败 | 构建阶段报错 | 检查 Dockerfile 和构建日志 |
| 镜像推送失败 | 无法推送到 Harbor | 检查 Harbor 凭证 |
| 部署失败 | 部署阶段报错 | 检查 Kubernetes 权限 |

### 存储故障模式

| 故障模式 | 症状 | 快速排查 |
|---------|------|----------|
| PVC Pending | PVC 无法绑定 | 检查 StorageClass 和 NFS |
| 挂载失败 | Pod 无法挂载卷 | 检查 PVC 状态 |
| 空间不足 | 存储配额用尽 | 检查 PVC 使用率 |

### 网络故障模式

| 故障模式 | 症状 | 快速排查 |
|---------|------|----------|
| DNS 解析失败 | 服务无法访问 | `kubectl run -it --rm dns-test --image=busybox:1.36 -- nslookup <service>` |
| Ingress 502 | 外部访问失败 | 检查 Ingress Controller 日志 |
| Service 无 Endpoints | 后端无 Pod | 检查 Pod 标签和 Selector |

### 认证故障模式

| 故障模式 | 症状 | 快速排查 |
|---------|------|----------|
| OIDC 认证失败 | 用户无法登录 | 1. 检查 Keycloak 状态 2. 校验 OIDC 三组件一致性 (kube-apiserver/Console/Grafana) |
| RBAC 权限不足 | API 请求 403 | `kubectl auth can-i <verb> <resource>` |
| 证书过期 | HTTPS 错误 | 检查 Cert-Manager 证书状态 |

---

## 常用排查命令速查

```bash
# 集群状态
kubectl get nodes
kubectl cluster-info

# Pod 状态
kubectl get pods -A --field-selector=status.phase!=Running
kubectl get pods -A -o wide

# 资源使用
kubectl top nodes
kubectl top pods -A

# 事件
kubectl get events -A --sort-by='.lastTimestamp' | tail -20

# 组件状态
kubectl get componentstatuses

# KDO 组件
kubectl get pods -n kubedo-system
kubectl get pods -n tekton-pipelines
kubectl get pods -n monitoring
kubectl get pods -n openshift-logging
```

---

## 诊断命令

### 快速集群健康检查
```bash
kubectl get nodes -o wide
kubectl get pods -A -o wide
kubectl get events -A --sort-by='.lastTimestamp'
```

### OpenShift 专用
```bash
oc get nodes -o wide
oc get co
oc status
```

### 日志与指标
```bash
kubectl logs <pod> -n <ns> --tail=100
kubectl top nodes
kubectl top pods -A
```

---

## 升级矩阵

| 问题类型 | 第一响应 Agent | 升级对象 |
|------------|-------------|------------|
| 节点问题 | Atlas (cluster-ops) | @human |
| 部署问题 | Flow (gitops) | @human |
| 安全问题 | Shield (security) | @human 立即 |
| 性能问题 | Pulse (observability) | @Atlas |
| 开发者问题 | Desk (dev-experience) | @Flow |

---

## 排查工作流

1. **观察** — 收集症状、检查状态
2. **假设** — 形成原因推测
3. **调查** — 运行诊断命令
4. **验证** — 确认根本原因
5. **修复** — 应用解决方案（生产环境需要审批）
6. **记录** — 记录到 TROUBLESHOOTING.md
7. **预防** — 添加自动化/防护措施

---

## 未经人工审批绝不可做

- 删除任何资源
- 修改 RBAC
- 更改集群范围策略
- 回滚生产部署
- 修改密钥
- 超出限制扩缩容
- 应用未知 YAML
- 在生产环境执行临时脚本
