---
title: KDO 网络架构
description: Calico/Ingress/Service 网络配置详解
created: 2026-07-17
author: atlas
tags: [kdo, 网络, calico, ingress, service]
---

# KDO 网络架构

## 网络概述

KDO 使用 Calico 作为 CNI 插件，NGINX Ingress 作为入口控制器，提供完整的网络解决方案。

## 组件架构

```
┌─────────────────────────────────────────────────────┐
│                 外部流量 (External)                  │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│              Ingress NGINX (入口控制器)              │
│         命名空间: ingress-nginx                     │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│                 Service 层                          │
│   ClusterIP │ NodePort │ LoadBalancer              │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│                 Pod 网络                            │
│            Calico CNI (VXLAN/IPIP)                 │
└─────────────────────────────────────────────────────┘
```

## Calico 配置

### 组件部署

```yaml
# DaemonSet: calico-node (kube-system)
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: calico-node
  namespace: kube-system
spec:
  template:
    spec:
      containers:
      - name: calico-node
        ports:
        - containerPort: 179
          name: bgp
        - containerPort: 4789
          name: vxlan
```

### Calico 配置

```yaml
# ConfigMap: calico-config (kube-system)
data:
  calico_backend: "vxlan"
  cluster_type: "k8s,vxlan"
  ipam: "host-local"
  cni_network_config: |
    {
      "name": "k8s-pod-network",
      "cniVersion": "0.3.1",
      "plugins": [
        {
          "type": "calico",
          "datastore_type": "kubernetes",
          "nodod_file": "/node/enode",
          "log_level": "info",
          "log_file_path": "/var/log/calico/cni/cni.log",
          "ipam": {
            "type": "host-local",
            "subnet": "usePodCidr"
          },
          "container_settings": {
            "allow_ip_forwarding": true
          },
          "policy": {
            "type": "k8s"
          }
        }
      ]
    }
```

### NetworkPolicy

```bash
# 查看 NetworkPolicy
kubectl get networkpolicy -A

# 示例: 限制命名空间访问
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: deny-all
  namespace: my-namespace
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
```

```bash
# 查看 Calico 状态
kubectl get pods -n kube-system -l k8s-app=calico-node
kubectl get pods -n kube-system -l k8s-app=calico-kube-controllers

# 查看 Calico 配置
kubectl get cm calico-config -n kube-system -o yaml
```

---

## Ingress NGINX 配置

### 部署配置

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ingress-nginx-controller
  namespace: ingress-nginx
spec:
  replicas: 1
  template:
    spec:
      containers:
      - name: controller
        ports:
        - containerPort: 80
          name: http
        - containerPort: 443
          name: https
        - containerPort: 10254
          name: metrics
```

### Ingress 服务

| 服务名 | 类型 | 端口 | 用途 |
|--------|------|------|------|
| ingress-nginx-controller | ClusterIP | 80, 443 | HTTP/HTTPS 代理 |
| ingress-nginx-controller-admission | ClusterIP | 443 | Webhook 准入 |

### Ingress 示例

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-app
  namespace: my-namespace
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/proxy-body-size: "10m"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - my-app.example.com
    secretName: my-app-tls
  rules:
  - host: my-app.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: my-app
            port:
              number: 80
```

```bash
# 查看 Ingress 状态
kubectl get ingress -A
kubectl get pods -n ingress-nginx

# 查看 Ingress 配置
kubectl get ingress my-app -n my-namespace -o yaml

# 查看 Ingress 日志
kubectl logs -f deploy/ingress-nginx-controller -n ingress-nginx
```

---

## Service 类型

### ClusterIP

```yaml
# 内部服务访问
apiVersion: v1
kind: Service
metadata:
  name: my-service
  namespace: my-namespace
spec:
  type: ClusterIP
  selector:
    app: my-app
  ports:
  - port: 80
    targetPort: 8080
```

### NodePort

```yaml
# 节点端口访问
apiVersion: v1
kind: Service
metadata:
  name: my-service
  namespace: my-namespace
spec:
  type: NodePort
  selector:
    app: my-app
  ports:
  - port: 80
    targetPort: 8080
    nodePort: <console-nodeport>
```

### LoadBalancer

```yaml
# 负载均衡器访问
apiVersion: v1
kind: Service
metadata:
  name: my-service
  namespace: my-namespace
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: nlb
spec:
  type: LoadBalancer
  selector:
    app: my-app
  ports:
  - port: 80
    targetPort: 8080
```

---

## DNS 配置

### CoreDNS

```yaml
# Deployment: coredns (kube-system)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: coredns
  namespace: kube-system
spec:
  replicas: 2
  template:
    spec:
      containers:
      - name: coredns
        ports:
        - containerPort: 53
          name: dns
          protocol: UDP
        - containerPort: 53
          name: dns-tcp
          protocol: TCP
        - containerPort: 9153
          name: metrics
```

### DNS 解析规则

```
# 服务 DNS
<service-name>.<namespace>.svc.cluster.local

# Pod DNS
<pod-ip>.<namespace>.pod.cluster.local

# 有状态服务 DNS
<pod-name>.<service-name>.<namespace>.svc.cluster.local
```

```bash
# 查看 CoreDNS 状态
kubectl get pods -n kube-system -l k8s-app=kube-dns
kubectl get cm coredns -n kube-system -o yaml

# 测试 DNS 解析
kubectl run -it --rm dns-test --image=busybox:1.36 -- nslookup my-service.my-namespace.svc.cluster.local
```

---

## 端口规划

### 控制平面端口

| 端口 | 协议 | 用途 |
|------|------|------|
| 6443 | TCP | Kubernetes API Server |
| 2379-2380 | TCP | etcd |
| 10250 | TCP | Kubelet API |
| 10251 | TCP | Scheduler |
| 10252 | TCP | Controller Manager |
| 10257 | TCP | Controller Manager (secure) |
| 10259 | TCP | Scheduler (secure) |

### 工作负载端口

| 端口 | 协议 | 用途 |
|------|------|------|
| 179 | TCP | Calico BGP |
| 4789 | UDP | Calico VXLAN |
| 53 | UDP/TCP | CoreDNS |
| 80 | TCP | HTTP |
| 443 | TCP | HTTPS |
| 3000 | TCP | Grafana |
| 3100 | TCP | Loki |
| 9000 | TCP | MinIO API |
| 9001 | TCP | MinIO Console |
| 9090 | TCP | Prometheus |
| 9093 | TCP | Alertmanager |
| 9100 | TCP | Node Exporter |

### KDO 平台端口

| 端口 | 协议 | 用途 |
|------|------|------|
| 8080 | TCP | Keycloak |
| 9000 | TCP | Console |
| `<harbor-nodeport>` | TCP | Harbor (NodePort) |
| 8080 | TCP | Pipelines-as-Code |

```bash
# 查看所有 Service 端口
kubectl get svc -A -o jsonpath='{range .items[*]}{.metadata.namespace}/{.metadata.name}: {.spec.ports[*].port}{"\n"}{end}'

# 查看所有 Ingress
kubectl get ingress -A -o jsonpath='{range .items[*]}{.metadata.namespace}/{.metadata.name}: {.spec.rules[*].host}{"\n"}{end}'
```

---

## 网络策略

### 默认拒绝策略

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: my-namespace
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
```

### 允许特定流量

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-frontend
  namespace: my-namespace
spec:
  podSelector:
    matchLabels:
      app: backend
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: frontend
    ports:
    - port: 8080
      protocol: TCP
```

---

## 排查命令

```bash
# 查看网络插件状态
kubectl get pods -n kube-system -l k8s-app=calico-node
kubectl get pods -n kube-system -l k8s-app=kube-dns

# 查看 Ingress 状态
kubectl get ingress -A
kubectl get pods -n ingress-nginx

# 查看 Service 状态
kubectl get svc -A

# 查看 NetworkPolicy
kubectl get networkpolicy -A

# 测试网络连通性
kubectl run -it --rm net-test --image=busybox:1.36 -- wget -qO- http:/my-service.my-namespace.svc.cluster.local

# 查看 Pod IP
kubectl get pods -o wide -n my-namespace

# 测试 DNS 解析
kubectl run -it --rm dns-test --image=busybox:1.36 -- nslookup my-service.my-namespace.svc.cluster.local
```

## 相关页面

- [[wiki/concepts/kdo-networking]] — 网络概念
- [[wiki/platform/kdo-component-details]] — 组件详情
- [[wiki/platform/kdo-cluster-architecture]] — 架构全景图
- [[wiki/platform/kdo-troubleshooting-patterns]] — 故障排查
