---
title: KDO 应用与流水线模板
description: KDO 平台预置的应用模板和流水线模板详解
created: 2026-07-17
author: desk
tags: [kdo, 模板, 应用, 流水线, CI/CD]
---

# KDO 应用与流水线模板

## 模板概述

KDO 平台在 `kubedo` 命名空间中预置了多种应用模板和流水线模板，支持快速创建应用。

## 应用模板

### Java 模板

| 模板名 | 基础镜像 | 用途 |
|--------|----------|------|
| `java-openjdk8` | registry.cn-shenzhen.aliyuncs.com/kubedo/openjdk:8 | Java 8 应用 |
| `java-openjdk11` | registry.cn-shenzhen.aliyuncs.com/kubedo/openjdk:11 | Java 11 应用 |
| `java-openjdk17` | registry.cn-shenzhen.aliyuncs.com/kubedo/openjdk:17 | Java 17 应用 |
| `java-openjdk21` | registry.cn-shenzhen.aliyuncs.com/kubedo/openjdk:21 | Java 21 应用 |

**模板结构** (以 java-openjdk17 为例):

```
ConfigMap: java-openjdk17
├── Dockerfile        # Docker 构建文件
└── deploy.yaml       # Kubernetes 部署清单
```

**Dockerfile 模板**:
```dockerfile
FROM registry.cn-shenzhen.aliyuncs.com/kubedo/openjdk:17
COPY ./target/*.jar /app/target/{{repo_name}}.jar
EXPOSE {{port_number}}
ENTRYPOINT [ "java", "-jar", "/app/target/{{repo_name}}.jar", "--server.port={{port_number}}" ]
```

**deploy.yaml 模板变量**:
- `{{repo_name}}` — 仓库名称
- `{{branch}}` — 分支名称
- `{{image_url}}` — 镜像 URL
- `{{port_name}}` — 端口名称
- `{{port_number}}` — 端口号
- `{{port_protocol}}` — 端口协议 (TCP/UDP)

```bash
# 查看 Java 模板
kubectl get cm java-openjdk17 -n kubedo -o yaml
kubectl get cm pipelinerun-java -n kubedo -o yaml
```

### Python 模板

| 模板名 | 用途 |
|--------|------|
| `python-flask` | Flask Web 应用 |
| `python-django` | Django Web 应用 |
| `python-fastapi` | FastAPI 应用 |

```bash
# 查看 Python 模板
kubectl get cm python-flask -n kubedo -o yaml
kubectl get cm pipelinerun-python -n kubedo -o yaml
```

### Node.js 模板

| 模板名 | 用途 |
|--------|------|
| `nodejs-express` | Express.js 应用 |
| `nodejs-next` | Next.js 应用 |
| `nodejs-vue` | Vue.js 应用 |

**流水线模板**:
- `pipelinerun-nodejs-express` — Express 流水线
- `pipelinerun-nodejs-next` — Next.js 流水线
- `pipelinerun-nodejs-npm` — NPM 通用流水线
- `pipelinerun-nodejs-yarn` — Yarn 通用流水线

```bash
# 查看 Node.js 模板
kubectl get cm nodejs-express -n kubedo -o yaml
kubectl get cm pipelinerun-nodejs-express -n kubedo -o yaml
```

### Go 模板

| 模板名 | 用途 |
|--------|------|
| `golang-gin` | Gin Web 应用 |

```bash
# 查看 Go 模板
kubectl get cm golang-gin -n kubedo -o yaml
kubectl get cm pipelinerun-golang -n kubedo -o yaml
```

### Rust 模板

| 模板名 | 用途 |
|--------|------|
| `rust-actix` | Actix Web 应用 |

```bash
# 查看 Rust 模板
kubectl get cm rust-actix -n kubedo -o yaml
kubectl get cm pipelinerun-rust -n kubedo -o yaml
```

### Nginx 模板

| 模板名 | 用途 |
|--------|------|
| `nginx-html` | 静态 HTML 站点 |

```bash
# 查看 Nginx 模板
kubectl get cm nginx-html -n kubedo -o yaml
kubectl get cm pipelinerun-template-nginx -n kubedo -o yaml
```

---

## 流水线模板

### 流水线模板结构

所有流水线模板都遵循相同的结构：

```yaml
apiVersion: tekton.dev/v1
kind: PipelineRun
metadata:
  name: "{{repo_name}}-{{app_env}}-{{branch}}"
  annotations:
    pipelinesascode.tekton.dev/on-event: "[{{on_events}}]"
    pipelinesascode.tekton.dev/on-target-branch: "[{{branch_name}}]"
    pipelinesascode.tekton.dev/max-keep-runs: "1"
spec:
  params:
    - name: repo_url
      value: "{{ repo_url }}"
    - name: revision
      value: "{{ revision }}"
    - name: namespace
      value: "{{target_namespace}}"
    - name: image_tag
      value: "{{image_tag}}"
  pipelineSpec:
    # 流水线定义
```

### 流水线阶段

典型流水线包含以下阶段：

```
fetch-repository → build → push-image → deploy
   (git-clone)    (buildah)  (buildah)   (kubectl)
```

**阶段详解**:

1. **fetch-repository**: 从 Git 仓库拉取代码
   - Task: `git-clone` (来自 `kubedo` 命名空间，`resolver: cluster` 引用)
   - Workspaces: output, basic-auth

2. **build**: 构建容器镜像
   - Task: `maven` / `buildpacks` / `buildah`
   - 根据语言选择不同构建任务

3. **push-image**: 推送镜像到 Harbor
   - Task: `buildah`
   - 使用 dockerconfig-ws Workspace

4. **deploy**: 部署到 Kubernetes
   - Task: `kubectl-deploy`
   - 使用 kubeconfig-ws Workspace

### 流水线模板列表

| 模板名 | 语言 | 构建工具 | 用途 |
|--------|------|----------|------|
| `pipelinerun-java` | Java | Maven | Java 应用 CI/CD |
| `pipelinerun-python` | Python | Pip | Python 应用 CI/CD |
| `pipelinerun-python-flask` | Python | Pip | Flask 应用 CI/CD |
| `pipelinerun-python-fastapi` | Python | Pip | FastAPI 应用 CI/CD |
| `pipelinerun-nodejs-express` | Node.js | NPM | Express 应用 CI/CD |
| `pipelinerun-nodejs-next` | Node.js | NPM | Next.js 应用 CI/CD |
| `pipelinerun-nodejs-npm` | Node.js | NPM | Node.js 通用 CI/CD |
| `pipelinerun-nodejs-yarn` | Node.js | Yarn | Node.js 通用 CI/CD |
| `pipelinerun-golang` | Go | Go Build | Go 应用 CI/CD |
| `pipelinerun-rust` | Rust | Cargo | Rust 应用 CI/CD |
| `pipelinerun-template-nginx` | HTML | Nginx | 静态站点 CI/CD |

### 流水线参数

| 参数名 | 类型 | 描述 |
|--------|------|------|
| `repo_url` | string | Git 仓库 URL |
| `revision` | string | Git 分支/标签 |
| `namespace` | string | 部署命名空间 |
| `image_tag` | string | 镜像标签 |

### 流水线注解

| 注解名 | 值 | 描述 |
|--------|-----|------|
| `pipelinesascode.tekton.dev/on-event` | `[push, pull_request]` | 触发事件 |
| `pipelinesascode.tekton.dev/on-target-branch` | `[main, develop]` | 目标分支 |
| `pipelinesascode.tekton.dev/max-keep-runs` | `1` | 保留最近 N 次运行 |

```bash
# 查看所有流水线模板（按语言：devLanguage 标签，模板 ConfigMap 存于 kubedo）
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage

# 查看特定流水线模板
kubectl get cm pipelinerun-java -n kubedo -o yaml

# 查看 Tekton Tasks（可选 Task 来自 kubedo，cluster resolver 引用）
kubectl get tasks -n kubedo
```

---

## 模板自定义

### 创建自定义应用模板

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: my-custom-template
  namespace: kubedo
  labels:
    app: template
data:
  Dockerfile: |
    FROM my-base-image:latest
    COPY . /app
    WORKDIR /app
    RUN build-command
    CMD ["start-command"]
  deploy.yaml: |
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: {{repo_name}}-{{branch}}
    spec:
      replicas: 1
      selector:
        matchLabels:
          app: "{{repo_name}}-{{branch}}"
      template:
        metadata:
          labels:
            app: "{{repo_name}}-{{branch}}"
        spec:
          containers:
          - name: {{repo_name}}
            image: {{image_url}}
            ports:
            - containerPort: {{port_number}}
```

### 创建自定义流水线模板

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: pipelinerun-my-template
  namespace: kubedo
  labels:
    app: pipelinerun
data:
  template: |
    apiVersion: tekton.dev/v1
    kind: PipelineRun
    metadata:
      name: "{{repo_name}}-{{app_env}}-{{branch}}"
    spec:
      params:
        - name: repo_url
          value: "{{ repo_url }}"
        - name: revision
          value: "{{ revision }}"
      pipelineSpec:
        tasks:
        - name: fetch
          taskRef:
            resolver: cluster
            params:
              - name: kind
                value: task
              - name: namespace
                value: kubedo
              - name: name
                value: git-clone
        - name: build
          runAfter: [fetch]
          taskRef:
            resolver: cluster
            params:
              - name: kind
                value: task
              - name: namespace
                value: kubedo
              - name: name
                value: my-build-task
```

---

## 模板使用流程

```
1. 选择模板 → 2. 配置参数 → 3. 关联 Git 仓库 → 4. 触发流水线
     │              │              │              │
     ↓              ↓              ↓              ↓
  kubedo 命名空间  ConfigMap      Repository CRD   Webhook
```

### 快速开始

```bash
# 1. 查看可用模板
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devTemplate

# 2. 创建应用 (通过 Console 或 kubectl)
# Console: 应用管理 → 创建应用 → 选择模板
# kubectl: 创建 PipelineRun 引用模板

# 3. 查看流水线运行
kubectl get pipelineruns -n <namespace>

# 4. 查看日志
kubectl logs -l tekton.dev/pipelineRun=<run-name> -n <namespace> --all-containers
```

---

## 常见问题

### 模板不显示

```bash
# 检查 ConfigMap 标签
kubectl get cm -n kubedo --show-labels

# 确保标签正确（模板 ConfigMap 需带 devLanguage/devTemplate 标签）
kubectl label cm my-template pipelinesascode.tekton.dev/devLanguage=java -n kubedo
```

### 流水线模板不匹配

```bash
# 检查模板变量
kubectl get cm pipelinerun-java -n kubedo -o jsonpath='{.data.template}' | jq

# 验证变量替换
# 确保 {{变量名}} 与 Pipeline 参数匹配
```

## 相关页面

- [[wiki/topics/kdo-pipelines]] — Tekton 流水线详解
- [[wiki/topics/kdo-applications]] — 应用管理
- [[wiki/topics/kdo-platform-project-management]] — 项目管理
- [[wiki/platform/kdo-component-details]] — 组件详情
