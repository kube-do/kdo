---
title: KDO 存储配置
description: NFS/Harbor/存储类配置详解
created: 2026-07-17
author: atlas
tags: [kdo, 存储, nfs, harbor, pvc]
---

# KDO 存储配置

## 存储概述

KDO 使用 NFS 作为默认存储后端，通过 NFS Provisioner 自动提供 PersistentVolume，Harbor 作为容器镜像仓库。

## 组件架构

```
┌─────────────────────────────────────────────────────┐
│                 应用 Pod                            │
│              PVC → PV                              │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│              NFS Provisioner                       │
│         自动创建 PV (nfs-client)                   │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│                 NFS 服务器                          │
│            /exports/data                           │
└─────────────────────────────────────────────────────┘
```

## NFS Provisioner 配置

### 部署配置

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nfs-subdir-external-provisioner
  namespace: kubedo-system
spec:
  replicas: 1
  template:
    spec:
      containers:
      - name: nfs-subdir-external-provisioner
        env:
        - name: PROVISIONER_NAME
          value: nfs-client
        - name: NFS_SERVER
          value: <nfs-server-ip>
        - name: NFS_PATH
          value: /exports/data
```

### StorageClass 配置

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: nfs-client
  annotations:
    storageclass.kubernetes.io/is-default-class: "true"
provisioner: nfs-client
parameters:
  archiveOnDelete: "true"
  pathPattern: "${.PVC.namespace}-${.PVC.name}"
reclaimPolicy: Delete
volumeBindingMode: Immediate
allowVolumeExpansion: true
```

### PV/PVC 示例

```yaml
# PVC 示例
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: my-pvc
  namespace: my-namespace
spec:
  accessModes:
  - ReadWriteOnce
  storageClassName: nfs-client
  resources:
    requests:
      storage: 10Gi

# 自动创建的 PV
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pvc-xxxxx
spec:
  capacity:
    storage: 10Gi
  accessModes:
  - ReadWriteOnce
  persistentVolumeReclaimPolicy: Delete
  storageClassName: nfs-client
  nfs:
    server: <nfs-server-ip>
    path: /exports/data/my-namespace-my-pvc
```

```bash
# 查看 NFS Provisioner 状态
kubectl get pods -n kubedo-system -l app=nfs-subdir-external-provisioner

# 查看 StorageClass
kubectl get storageclass

# 查看 PV/PVC
kubectl get pv
kubectl get pvc -A

# 查看 PVC 详情
kubectl describe pvc my-pvc -n my-namespace
```

---

## Harbor 配置

### 组件部署

```yaml
# Harbor Core
apiVersion: apps/v1
kind: Deployment
metadata:
  name: harbor-core
  namespace: harbor

# Harbor Registry
apiVersion: apps/v1
kind: Deployment
metadata:
  name: harbor-registry
  namespace: harbor

# Harbor Portal
apiVersion: apps/v1
kind: Deployment
metadata:
  name: harbor-portal
  namespace: harbor

# Harbor Jobservice
apiVersion: apps/v1
kind: Deployment
metadata:
  name: harbor-jobservice
  namespace: harbor

# Harbor Notary Server
apiVersion: apps/v1
kind: Deployment
metadata:
  name: harbor-notary-server
  namespace: harbor
```

### Harbor 服务

| 服务名 | 类型 | 端口 | 用途 |
|--------|------|------|------|
| harbor | NodePort | `<harbor-nodeport>` | HTTP 访问 |
| harbor-core | ClusterIP | 80 | 核心 API |
| harbor-registry | ClusterIP | 5000 | 镜像存储 |
| harbor-portal | ClusterIP | 80 | Web 控制台 |
| harbor-notary-server | ClusterIP | 4443 | 镜像签名 |

### Harbor 配置

```yaml
# ConfigMap: harbor-core
data:
  app.conf: |
    appname = harbor
    httpport = 8080
    runmode = prod
    [prod]
        httpport = 8080
    [dev]
        httpport = 8080

# ConfigMap: harbor-registry
config.yml: |
  version: 0.1
  log:
    level: info
  storage:
    filesystem:
      rootdirectory: /storage
    cache:
      blobdescriptor: inmemory
    maintenance:
      uploadpurging:
        enabled: false
    delete:
      enabled: true
  http:
    addr: :5000
```

```bash
# 查看 Harbor 状态
kubectl get pods -n harbor
kubectl get svc harbor -n harbor

# 访问 Harbor 控制台
kubectl port-forward svc/harbor <harbor-nodeport>:80 -n harbor
# 或直接访问 http:/<node-ip>:<harbor-nodeport>

# 查看 Harbor 配置
kubectl get cm harbor-core -n harbor -o yaml
```

---

## Harbor 镜像仓库使用

### 推送镜像

```bash
# 登录 Harbor
docker login <harbor-endpoint>

# 推送镜像
docker tag my-app:1.0 <harbor-endpoint>/my-project/my-app:1.0
docker push <harbor-endpoint>/my-project/my-app:1.0
```

### 拉取镜像

```bash
# 拉取镜像
docker pull <harbor-endpoint>/my-project/my-app:1.0

# 在 Kubernetes 中使用
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  template:
    spec:
      containers:
      - name: my-app
        image: <harbor-endpoint>/my-project/my-app:1.0
      imagePullSecrets:
      - name: harbor-secret
```

### 创建 ImagePullSecret

> ⚠️ 如 Harbor 密码已修改，需同步更新 `harbor-core` Secret: `kubectl patch secret -n harbor harbor-core --type merge -p '{"data":{"HARBOR_ADMIN_PASSWORD":"<base64-新密码>"}}'`

```bash
kubectl create secret docker-registry harbor-secret \
  --docker-server=<harbor-endpoint> \
  --docker-username=admin \
  --docker-password=<harbor-password> \
  -n my-namespace
```

---

## 存储最佳实践

### 1. PVC 命名规范

```yaml
# 好的命名
metadata:
  name: my-app-data
  namespace: my-namespace
  labels:
    app: my-app
    component: data

# 避免的命名
metadata:
  name: test
  namespace: my-namespace
```

### 2. 资源请求

```yaml
# 生产环境
resources:
  requests:
    storage: 50Gi
  limits:
    storage: 100Gi

# 开发环境
resources:
  requests:
    storage: 10Gi
```

### 3. 访问模式选择

| 访问模式 | 用途 | 示例 |
|----------|------|------|
| ReadWriteOnce (RWO) | 单节点读写 | 数据库、单实例应用 |
| ReadOnlyMany (ROX) | 多节点只读 | 静态文件、配置 |
| ReadWriteMany (RWX) | 多节点读写 | 共享存储、文件服务器 |

### 4. 回收策略

| 策略 | 行为 | 用途 |
|------|------|------|
| Retain | 保留 PV | 生产数据、重要数据 |
| Delete | 删除 PV | 临时数据、开发环境 |
| Recycle | 清空 PV | 已废弃 |

---

## 存储监控

### PVC 使用率

```promql
# PVC 使用率
kubelet_volume_stats_used_bytes / kubelet_volume_stats_capacity_bytes * 100

# PVC 剩余空间
kubelet_volume_stats_available_bytes

# PVC 使用量
kubelet_volume_stats_used_bytes
```

### Grafana 仪表板

- Persistent Volumes Usage
- K8s Resources Pod (存储部分)

```bash
# 查看 PVC 使用情况
kubectl get pvc -A -o jsonpath='{range .items[*]}{.metadata.namespace}/{.metadata.name}: {.status.capacity.storage}{"\n"}{end}'

# 查看 PV 状态
kubectl get pv -o wide
```

---

## 排查命令

```bash
# 查看 NFS Provisioner 状态
kubectl get pods -n kubedo-system -l app=nfs-subdir-external-provisioner
kubectl logs -f deploy/nfs-subdir-external-provisioner -n kubedo-system

# 查看 StorageClass
kubectl get storageclass
kubectl describe storageclass nfs-client

# 查看 PV/PVC
kubectl get pv
kubectl get pvc -A
kubectl describe pvc <pvc-name> -n <namespace>

# 查看 Harbor 状态
kubectl get pods -n harbor
kubectl get svc harbor -n harbor

# 查看 Harbor 日志
kubectl logs -f deploy/harbor-core -n harbor
kubectl logs -f deploy/harbor-registry -n harbor

# 测试 PVC 挂载
kubectl run -it --rm test-pvc --image=busybox:1.36 -- mount | grep my-pvc
```

## 相关页面

- [[wiki/concepts/kdo-storage]] — 存储概念
- [[wiki/platform/kdo-component-details]] — 组件详情
- [[wiki/platform/kdo-cluster-architecture]] — 架构全景图
- [[wiki/platform/kdo-troubleshooting-patterns]] — 故障排查
