---
title: KDO 平台架构全景图
description: 基于实际集群分析的 KDO 平台架构详解
created: 2026-07-17
author: atlas
tags: [kdo, 架构, 平台, 集群]
---

# KDO 平台架构全景图

## 平台概述

KDO (KubeDo) 是一个基于 Kubernetes 的企业级 DevOps 平台，提供应用全生命周期管理能力。

## 架构分层

```
┌─────────────────────────────────────────────────────────────┐
│                    用户层 (User Layer)                       │
├─────────────────────────────────────────────────────────────┤
│  Console (Web UI)  │  Keycloak (认证)  │  Lightspeed (AI)  │
└─────────────────────────────────────────────────────────────┘
                            │
┌─────────────────────────────────────────────────────────────┐
│                  控制平面 (Control Plane)                    │
├─────────────────────────────────────────────────────────────┤
│  KDC Controller  │  Tekton Operator  │  Prometheus Operator │
└─────────────────────────────────────────────────────────────┘
                            │
┌─────────────────────────────────────────────────────────────┐
│                    工作负载层 (Workloads)                    │
├─────────────────────────────────────────────────────────────┤
│  Applications  │  Pipelines  │  Monitoring  │  Logging     │
└─────────────────────────────────────────────────────────────┘
                            │
┌─────────────────────────────────────────────────────────────┐
│                    基础设施层 (Infrastructure)               │
├─────────────────────────────────────────────────────────────┤
│  Calico (网络)  │  NFS (存储)  │  Harbor (镜像)  │  Cert-Manager │
└─────────────────────────────────────────────────────────────┘
```

## 命名空间规划

| 命名空间 | 用途 | 组件 |
|----------|------|------|
| `kubedo-system` | KDO 核心组件 | Console, KDC Controller, Keycloak, Lightspeed |
| `kubedo` | 模板仓库 | 应用模板, 流水线模板 |
| `kdo` | 默认环境 | 应用工作负载 |
| `kdo-dev` | 开发环境 | 应用工作负载 |
| `kdo-stage` | 预发布环境 | 应用工作负载 |
| `kdo-prod` | 生产环境 | 应用工作负载 |
| `kdo-test` | 测试环境 | 应用工作负载 |
| `tekton-pipelines` | CI/CD 引擎 | Tekton Pipelines, Triggers, Chains |
| `pipelines-as-code` | GitOps 流水线 | PAC Controller, Webhook |
| `monitoring` | 监控栈 | Prometheus, Grafana, Alertmanager |
| `openshift-logging` | 日志栈 | Loki Stack, MinIO, EventRouter |
| `harbor` | 镜像仓库 | Harbor Core, Registry, Trivy |
| `cert-manager` | 证书管理 | Cert-Manager, CA Injector |
| `ingress-nginx` | 入口控制器 | NGINX Ingress |
| `kube-system` | Kubernetes 核心 | CoreDNS, Calico, kube-proxy |

## 组件依赖关系

```
Console ──────┬──→ Keycloak (认证)
              ├──→ KDC Controller (资源管理)
              └──→ Lightspeed (AI 助手)

Tekton ───────┬──→ Pipelines-as-Code (Git 触发)
              ├──→ Shipwright (镜像构建)
              └──→ Chains (签名)

Monitoring ───┬──→ Prometheus (指标采集)
              ├──→ Grafana (可视化)
              └──→ Alertmanager (告警)

Logging ──────┬──→ Loki (日志存储)
              └──→ MinIO (对象存储)
```

## 数据流

### 应用部署流程

```
开发者 → Console → Pipelines-as-Code → Tekton Pipeline → Harbor → Kubernetes
                    (Git Webhook)        (构建/推送)      (拉取镜像)
```

### 监控数据流

```
节点/Pod → Prometheus → Grafana (可视化)
    │                    └──→ Alertmanager → 通知
    └──→ Loki → 日志查询
```

### 认证流程

```
用户 → Console → Keycloak → OIDC Token → Kubernetes API
              (认证/授权)    (RBAC 检查)
```

## 高可用设计

| 组件 | 高可用方式 | 副本数 |
|------|-----------|--------|
| Kubernetes Control Plane | 多节点 etcd + apiserver | 3 |
| Keycloak | StatefulSet + PostgreSQL | 1 (可扩展) |
| Prometheus | 单实例 + 持久化 | 1 |
| Grafana | 单实例 | 1 |
| Tekton | Operator 管理 | 按需 |
| Harbor | 组件分离部署 | 按需 |

## 资源规划

### 节点规格 (当前集群)

| 节点 | CPU | 内存 | 角色 |
|------|-----|------|------|
| node31 | 8 cores | 15 GiB | control-plane, worker |
| node32 | 8 cores | 15 GiB | control-plane, worker |
| node33 | 8 cores | 15 GiB | control-plane, worker |

### 推荐资源配置

| 组件 | CPU Request | Memory Request | Storage |
|------|-------------|----------------|---------|
| KDO Core | 2-4 cores | 4-8 GiB | 20 Gi |
| Tekton | 1-2 cores | 2-4 GiB | 10 Gi |
| Monitoring | 2-4 cores | 8-16 GiB | 100-200 Gi |
| Logging | 1-2 cores | 4-8 GiB | 50-100 Gi |
| Harbor | 2-4 cores | 4-8 GiB | 100+ Gi |

## 扩展点

### 水平扩展

- **KDC Controller**: 增加副本数
- **Tekton**: 增加并发任务数
- **Prometheus**: Federation 或 Thanos
- **Loki**: 增加 Querier/Ingester 副本

### 垂直扩展

- **Keycloak**: 增加 PostgreSQL 资源
- **Harbor**: 增加 Trivy 扫描器副本
- **Monitoring**: 增加 Prometheus 存储

## 安全边界

```
┌─────────────────────────────────────────────────┐
│              外部访问 (External)                 │
│  ┌─────────────────────────────────────────┐   │
│  │         Ingress NGINX (入口)            │   │
│  └─────────────────────────────────────────┘   │
│                    │                            │
│  ┌─────────────────────────────────────────┐   │
│  │      NetworkPolicy (网络隔离)           │   │
│  └─────────────────────────────────────────┘   │
│                    │                            │
│  ┌─────────────────────────────────────────┐   │
│  │      RBAC (权限控制)                     │   │
│  └─────────────────────────────────────────┘   │
│                    │                            │
│  ┌─────────────────────────────────────────┐   │
│  │      Pod Security (容器安全)             │   │
│  └─────────────────────────────────────────┘   │
└─────────────────────────────────────────────────┘
```

## 相关页面

- [[wiki/concepts/kdo-architecture]] — 原始架构文档
- [[wiki/platform/kdo-component-details]] — 组件详细配置
- [[wiki/platform/kdo-networking]] — 网络架构
- [[wiki/platform/kdo-storage-setup]] — 存储架构
- [[wiki/platform/kdo-security]] — 安全架构
