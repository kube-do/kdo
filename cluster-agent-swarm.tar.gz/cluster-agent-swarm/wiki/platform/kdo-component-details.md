---
title: KDO 组件详细配置
description: KDO 平台各组件的详细配置、端口、资源和依赖
created: 2026-07-17
author: atlas
tags: [kdo, 组件, 配置, 详细]
---

# KDO 组件详细配置

## KDO 核心组件

### Console (Web UI)

| 属性 | 值 |
|------|-----|
| **命名空间** | kubedo-system |
| **工作负载类型** | Deployment |
| **副本数** | 1 |
| **端口** | 9000 (HTTP) |
| **健康检查** | GET /health |
| **服务账号** | kdc-controller-manager |
| **配置文件** | /opt/bridge/config.yaml (ConfigMap: console) |

**资源需求**: 无显式配置 (由 LimitRange 管理)

**依赖**:
- Keycloak (认证)
- KDC Controller Manager (资源管理)

```bash
# 查看 Console 状态
kubectl get deploy console -n kubedo-system
kubectl logs -f deploy/console -n kubedo-system

# 查看 Console 配置
kubectl get cm console -n kubedo-system -o yaml
```

### KDC Controller Manager

| 属性 | 值 |
|------|-----|
| **命名空间** | kubedo-system |
| **工作负载类型** | Deployment |
| **副本数** | 1 |
| **服务账号** | kdc-controller-manager |
| **CRD** | AppProject, AppEnv, ImageStream |

**职责**:
- 管理 KDO 项目生命周期
- 自动创建命名空间和 RBAC
- 管理 ImageStream 导入

```bash
# 查看 KDC Controller 状态
kubectl get deploy kdc-controller-manager -n kubedo-system
kubectl logs -f deploy/kdc-controller-manager -n kubedo-system

# 查看 KDC CRD
kubectl get crd | grep kdc
```

### Keycloak (认证)

| 属性 | 值 |
|------|-----|
| **命名空间** | kubedo-system |
| **工作负载类型** | StatefulSet |
| **副本数** | 1 |
| **端口** | 8080 (HTTP), 8443 (HTTPS) |
| **数据库** | PostgreSQL (StatefulSet) |
| **Helm Chart** | keycloak-15.1.4 |

**环境变量**:
- `KEYCLOAK_ADMIN_PASSWORD`: 管理员密码 (Secret: keycloak)
- `KEYCLOAK_DATABASE_PASSWORD`: 数据库密码 (Secret: keycloak-postgresql)

**依赖**:
- PostgreSQL (StatefulSet: keycloak-postgresql)

```bash
# 查看 Keycloak 状态
kubectl get statefulset keycloak -n kubedo-system
kubectl logs keycloak-0 -n kubedo-system

# 查看 Keycloak 密码
kubectl get secret keycloak -n kubedo-system -o jsonpath='{.data.admin-password}' | base64 -d

# 访问 Keycloak 控制台
kubectl port-forward svc/keycloak 8080:80 -n kubedo-system
```

### Lightspeed (AI 助手)

| 属性 | 值 |
|------|-----|
| **命名空间** | kubedo-system |
| **工作负载类型** | Deployment |
| **服务名** | lightspeed-app-server |
| **配置** | OLSConfig CRD |

**依赖**:
- Ollama 模型 (本地或远程)

```bash
# 查看 Lightspeed 状态
kubectl get deploy lightspeed-w-rag -n kubedo-system
kubectl logs -f deploy/lightspeed-w-rag -n kubedo-system

# 查看 OLSConfig
kubectl get olsconfig -n kubedo-system -o yaml
```

---

## CI/CD 组件

### Tekton Pipelines

| 属性 | 值 |
|------|-----|
| **命名空间** | tekton-pipelines |
| **组件** | Controller, Webhook, Triggers, Chains, Results |
| **存储** | Tekton Results (PostgreSQL) |

**主要组件**:
- `tekton-pipelines-controller`: 核心控制器
- `tekton-pipelines-webhook`: Webhook 处理
- `tekton-triggers-controller`: 事件触发
- `tekton-chains-controller`: 镜像签名
- `tekton-results-api`: 执行记录 API

```bash
# 查看 Tekton 组件
kubectl get pods -n tekton-pipelines
kubectl get tektonconfig cluster -o yaml

# 查看 Pipeline/PipelineRun
kubectl get pipelines -A
kubectl get pipelineruns -A
```

### Pipelines-as-Code

| 属性 | 值 |
|------|-----|
| **命名空间** | pipelines-as-code |
| **组件** | Controller, Watcher, Webhook |
| **端口** | 8080 (Controller, NodePort) |

**配置**:
- ConfigMap: `pipelines-as-code` (主配置)
- ConfigMap: `pac-config-logging` (日志配置)

```bash
# 查看 PAC 状态
kubectl get pods -n pipelines-as-code
kubectl get cm pipelines-as-code -n pipelines-as-code -o yaml

# 查看 Repository CRD
kubectl get repositories -A
```

### Shipwright Build

| 属性 | 值 |
|------|-----|
| **命名空间** | shipwright-build |
| **组件** | Controller, Webhook |

```bash
# 查看 Shipwright 状态
kubectl get pods -n shipwright-build
kubectl get buildstrategy -A
```

---

## 监控组件

### Prometheus

| 属性 | 值 |
|------|-----|
| **命名空间** | monitoring |
| **版本** | v3.5.0 |
| **存储** | 200Gi PVC |
| **评估间隔** | 30s |
| **集群标签** | `<cluster-name>` |

**ServiceMonitor**:
- alertmanager-main, blackbox-exporter, coredns, grafana
- kube-apiserver, kube-controller-manager, kube-scheduler
- kube-state-metrics, kubelet, node-exporter
- prometheus-adapter, prometheus-operator

```bash
# 查看 Prometheus 状态
kubectl get prometheus -n monitoring
kubectl logs -f prometheus-k8s-0 -n monitoring

# 查看告警规则
kubectl get prometheusrule -n monitoring

# 查询指标
kubectl port-forward svc/prometheus-k8s 9090:9090 -n monitoring
```

### Grafana

| 属性 | 值 |
|------|-----|
| **命名空间** | monitoring |
| **端口** | 3000 |
| **数据源** | Prometheus, Loki |
| **仪表板** | 预装 K8s 监控仪表板 |

**预装仪表板**:
- Kubernetes Cluster Monitoring
- Pod/Node/Workload 资源监控
- Prometheus 监控
- Persistent Volumes 使用

```bash
# 查看 Grafana 状态
kubectl get deploy grafana -n monitoring
kubectl port-forward svc/grafana 3000:3000 -n monitoring

# 查看数据源
kubectl get secret grafana-config -n monitoring -o jsonpath='{.data.prometheus-yaml}' | base64 -d
```

### Alertmanager

| 属性 | 值 |
|------|-----|
| **命名空间** | monitoring |
| **版本** | v0.28.1 |
| **副本数** | 1 |
| **保留时间** | 120h |
| **资源限制** | CPU: 100m, Memory: 100Mi |

```bash
# 查看 Alertmanager 状态
kubectl get alertmanager -n monitoring
kubectl port-forward svc/alertmanager-main 9093:9093 -n monitoring

# 查看告警路由
kubectl get secret alertmanager-main-generated -n monitoring -o jsonpath='{.data.alertmanager\.yaml}' | base64 -d
```

---

## 日志组件

### Loki Stack

| 属性 | 值 |
|------|-----|
| **命名空间** | openshift-logging |
| **组件** | Distributor, Gateway, Querier, Query-Frontend, Ingester, Compactor, Index-Gateway, Ruler |
| **存储** | MinIO |

**LokiStack CRD**: `lokistack-dev`

```bash
# 查看 Loki 状态
kubectl get lokistack -n openshift-logging
kubectl get pods -n openshift-logging -l app.kubernetes.io/component

# 查询日志
kubectl port-forward svc/lokistack-dev-gateway-http 3100:8080 -n openshift-logging
```

### MinIO

| 属性 | 值 |
|------|-----|
| **命名空间** | openshift-logging |
| **服务** | minio (ClusterIP), minio-console (ClusterIP) |
| **配置** | ConfigMap: minio, Secret: minio |

```bash
# 查看 MinIO 状态
kubectl get pods -n openshift-logging -l app=minio
kubectl get secret minio -n openshift-logging -o jsonpath='{.data}' | jq
```

### EventRouter

| 属性 | 值 |
|------|-----|
| **命名空间** | openshift-logging |
| **配置** | ConfigMap: eventrouter |

```bash
# 查看 EventRouter 状态
kubectl get pods -n openshift-logging -l app=eventrouter
```

---

## 存储组件

### NFS Provisioner

| 属性 | 值 |
|------|-----|
| **命名空间** | kubedo-system |
| **Helm Chart** | nfs-subdir-external-provisioner |
| **默认 StorageClass** | nfs-client |

```bash
# 查看 NFS Provisioner 状态
kubectl get pods -n kubedo-system -l app=nfs-subdir-external-provisioner
kubectl get storageclass

# 查看 PVC
kubectl get pvc -A
```

### Harbor

| 属性 | 值 |
|------|-----|
| **命名空间** | harbor |
| **组件** | Core, Registry, Portal, Jobservice, Notary, Trivy, Database, Redis |
| **端口** | `<harbor-nodeport>` (NodePort, HTTP) |

```bash
# 查看 Harbor 状态
kubectl get pods -n harbor
kubectl get svc harbor -n harbor

# 访问 Harbor
kubectl port-forward svc/harbor <harbor-nodeport>:80 -n harbor
```

---

## 网络组件

### Calico

| 属性 | 值 |
|------|-----|
| **命名空间** | kube-system |
| **组件** | Calico Node (DaemonSet), Kube-Controllers |
| **模式** | VXLAN/IPIP |

```bash
# 查看 Calico 状态
kubectl get pods -n kube-system -l k8s-app=calico-node
calicoctl node status  (需要 calicoctl)
```

### Ingress NGINX

| 属性 | 值 |
|------|-----|
| **命名空间** | ingress-nginx |
| **组件** | Controller, Admission |
| **类型** | LoadBalancer/NodePort |

```bash
# 查看 Ingress 状态
kubectl get ingress -A
kubectl get pods -n ingress-nginx
```

---

## 安全组件

### Cert-Manager

| 属性 | 值 |
|------|-----|
| **命名空间** | cert-manager |
| **组件** | Cert-Manager, CA Injector, Webhook |
| **CRD** | Certificate, ClusterIssuer, Issuer |

```bash
# 查看 Cert-Manager 状态
kubectl get pods -n cert-manager
kubectl get clusterissuer
kubectl get certificates -A
```

---

## 排查命令速查

```bash
# 查看所有组件状态
kubectl get pods -A --field-selector=status.phase!=Running

# 查看资源使用
kubectl top nodes
kubectl top pods -A

# 查看事件
kubectl get events -A --sort-by='.lastTimestamp' | tail -20

# 查看组件日志
kubectl logs -f deploy/<component> -n <namespace>

# 查看组件配置
kubectl get cm <configmap> -n <namespace> -o yaml
```

## 相关页面

- [[wiki/platform/kdo-cluster-architecture]] — 架构全景图
- [[wiki/platform/kdo-templates]] — 应用/流水线模板
- [[wiki/platform/kdo-monitoring-setup]] — 监控配置
- [[wiki/platform/kdo-logging-setup]] — 日志配置
- [[wiki/platform/kdo-networking]] — 网络配置
- [[wiki/platform/kdo-storage-setup]] — 存储配置
- [[wiki/platform/kdo-security]] — 安全配置
