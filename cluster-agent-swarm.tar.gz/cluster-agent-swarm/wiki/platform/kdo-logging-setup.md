---
title: KDO 日志栈配置
description: Loki/MinIO 日志栈详细配置
created: 2026-07-17
author: pulse
tags: [kdo, 日志, loki, minio, logging]
---

# KDO 日志栈配置

## 日志栈概述

KDO 使用 Loki 作为日志聚合系统，MinIO 作为对象存储后端，配合 Grafana 进行日志查询和可视化。

## 组件架构

```
┌─────────────────────────────────────────────────────┐
│                  Grafana (查询/告警 UI)              │
│              告警经 Grafana Unified Alerting         │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│            LokiStack (日志存储/查询)                 │
│  query-frontend HTTP:3100 | gateway HTTP:8080       │
│  8 组件: distributor/ingester/querier/queryFrontend │
│          compactor/indexGateway/ruler/gateway       │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│                  MinIO (对象存储)                    │
│            端口: 9000 (API) / 9001 (Console)        │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│              日志采集 (Vector)                      │
│   DaemonSet: logging (openshift-logging)            │
│   镜像: registry.cn-shenzhen.aliyuncs.com/kubedo/vector:6.0 │
└─────────────────────────────────────────────────────┘
```

## Loki Stack 配置

### LokiStack CRD

```yaml
apiVersion: loki.grafana.com/v1
kind: LokiStack
metadata:
  name: lokistack-dev
  namespace: openshift-logging
spec:
  size: 1x.small
  managementState: Managed
  tenants:
    mode: openshift-logging   # application / infrastructure / audit 三租户
  limits:
    global:
      retention:
        days: 15              # 全局日志保留 15 天
  rules:
    enabled: true
    namespaceSelector:
      matchLabels:
        openshift.io/cluster-monitoring: "true"
  storage:
    schemas:
    - version: v13
      effectiveDate: "2023-10-15"
    secret:
      name: s3               # S3 访问凭据 Secret（MinIO）
      type: s3
    storageClassName: nfs-client
  template:
    compactor:     { replicas: 1 }
    distributor:   { replicas: 2 }
    gateway:       { replicas: 1 }
    indexGateway:  { replicas: 2 }
    ingester:      { replicas: 2 }
    querier:       { replicas: 2 }
    queryFrontend: { replicas: 2 }
    ruler:         { replicas: 2 }
```

### Loki 组件

| 组件 | 用途 | 副本数 |
|------|------|--------|
| Distributor | 日志分发 | 2 |
| Gateway | API 网关（对外入口 + OPA 鉴权） | 1 |
| Ingester | 日志摄入 | 2 |
| Querier | 日志查询 | 2 |
| Query Frontend | 查询前端 | 2 |
| Compactor | 数据压缩 + 保留清理 | 1 |
| Index Gateway | 索引网关 | 2 |
| Ruler | 规则评估 | 2 |

### Loki 服务

| 服务名 | 端口 | 用途 |
|--------|------|------|
| lokistack-dev-gateway-http | 8080 / 8081 / 8083 | 对外 HTTP API / Observatorium API / 内部指标页 |
| lokistack-dev-query-frontend-http | 3100 / 9095 | HTTP 查询入口（Grafana 直连）/ gRPC |
| lokistack-dev-distributor-http | 3100 / 9095 | HTTP 摄入 / gRPC 分发 |
| lokistack-dev-ingester-http | 3100 / 9095 | HTTP / gRPC 摄入 |
| lokistack-dev-querier-http | 3100 / 9095 | HTTP / gRPC 查询 |
| lokistack-dev-compactor-http | 3100 / 9095 | HTTP / gRPC 压缩 |
| lokistack-dev-index-gateway-http | 3100 / 9095 | HTTP / gRPC 索引 |
| lokistack-dev-ruler-http | 3100 / 9095 | HTTP / gRPC 规则 |
| lokistack-dev-gossip-ring | 7946 | 组件间 gossip 通信 |

```bash
# 查看 Loki 状态
kubectl get lokistack -n openshift-logging
kubectl get pods -n openshift-logging -l app.kubernetes.io/name=lokistack-dev

# 访问 Loki API（gateway 8080）
kubectl port-forward svc/lokistack-dev-gateway-http 8080:8080 -n openshift-logging
# 注：gateway 需要 OAuth token，直接访问需认证
```

---

## MinIO 配置

### 部署配置

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: minio
  namespace: openshift-logging
spec:
  replicas: 1
  template:
    spec:
      containers:
      - name: minio
        ports:
        - containerPort: 9000
          name: api
        - containerPort: 9001
          name: console
```

### MinIO 服务

| 服务名 | 端口 | 用途 |
|--------|------|------|
| minio | 9000 | S3 API |
| minio-console | 9001 | Web 控制台 |

### MinIO 配置

MinIO 访问凭据不硬编码，从 Secret 读取：

```bash
# 查看 MinIO 访问凭据（S3 配置存于 LokiStack 引用的 s3 Secret）
kubectl get secret s3 -n openshift-logging -o jsonpath='{.data}' | jq

# S3 端点 = http://minio.openshift-logging.svc:9000
# 存储桶 bucketnames = loki-k8s，region = eu-central-1（s3forcepathstyle: true）
# 存储后端 storageClassName = nfs-client
```

```bash
# 查看 MinIO 状态
kubectl get pods -n openshift-logging -l app=minio

# 访问 MinIO 控制台
kubectl port-forward svc/minio-console 9001:9001 -n openshift-logging
```

---

## 日志采集配置

采集代理为 **Vector**（DaemonSet `logging`，镜像 `registry.cn-shenzhen.aliyuncs.com/kubedo/vector:6.0`），直连 LokiStack，无需 ClusterLogForwarder/ClusterLogging CR（当前集群未部署这两类 CR）。

### 日志采集 DaemonSet

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: logging
  namespace: openshift-logging
spec:
  template:
    spec:
      containers:
      - name: vector
        image: registry.cn-shenzhen.aliyuncs.com/kubedo/vector:6.0
```

```bash
# 查看日志采集状态
kubectl get pods -n openshift-logging -l app=logging
kubectl logs -f ds/logging -n openshift-logging
```

---

## 日志查询语法

### LogQL 基础

流选择器标签（viaq schema，集群实际标签，来自 Vector 采集）：

| 标签 | 用途 | 示例 |
|------|------|------|
| `kubernetes_namespace_name` | 命名空间 | `{kubernetes_namespace_name="book-uat"}` |
| `kubernetes_pod_name` | Pod | `{kubernetes_pod_name="productpage-xxx"}` |
| `kubernetes_container_name` | 容器 | `{kubernetes_container_name="istio-proxy"}` |
| `kubernetes_host` | 节点主机 | `{kubernetes_host="h202.xsyx.dev"}` |
| `log_type` | 日志类型 | `{log_type="application"}`（另有 infrastructure/audit） |

> `level`/`message`/`@timestamp` 等为 viaq 日志体 JSON 字段，需 `| json` 解析后再过滤。日志体形如 `{"@timestamp":..., "kubernetes":{...}, "level":"info", "log_type":"application", "message":"..."}`。

```logql
# 查询命名空间日志
{kubernetes_namespace_name="my-namespace"}

# 查询 Pod 日志
{kubernetes_namespace_name="my-namespace", kubernetes_pod_name="my-pod-xxxxx"}

# 查询特定容器日志
{kubernetes_namespace_name="my-namespace", kubernetes_pod_name="my-pod-xxxxx", kubernetes_container_name="my-container"}

# 按关键字过滤
{kubernetes_namespace_name="my-namespace"} |= "error"
{kubernetes_namespace_name="my-namespace"} |= "timeout"

# 按正则表达式过滤
{kubernetes_namespace_name="my-namespace"} |~ "ERROR|WARN"
{kubernetes_namespace_name="my-namespace"} !~ "DEBUG"

# 日志解析
{kubernetes_namespace_name="my-namespace"} | json | level="error"
{kubernetes_namespace_name="my-namespace"} | logfmt | duration > 1s

# 日志统计
count_over_time({kubernetes_namespace_name="my-namespace"}[5m])
rate({kubernetes_namespace_name="my-namespace"} |= "error"[5m])
sum(rate({kubernetes_namespace_name="my-namespace"} |= "error"[5m])) by (kubernetes_pod_name)
```

### 常用查询示例

```logql
# 查找所有错误日志
{kubernetes_namespace_name="my-namespace"} |= "error" | level="error"

# 查找最近 5 分钟的错误
{kubernetes_namespace_name="my-namespace"} |= "error" [5m]

# 统计每分钟错误数
sum(count_over_time({kubernetes_namespace_name="my-namespace"} |= "error"[1m])) by (kubernetes_pod_name)

# 查找慢请求
{kubernetes_namespace_name="my-namespace"} | json | duration > 1s

# 查找特定应用的日志
{kubernetes_namespace_name="my-namespace", kubernetes_container_name="my-app"} |~ "ERROR|WARN"
```

```bash
# 通过 Grafana 查询日志
kubectl port-forward svc/grafana 3000:3000 -n monitoring
# 访问 http://localhost:3000 → Explore → Loki

# 通过 API 查询日志（需带租户头 X-Scope-OrgID，否则报 "no org id"）
kubectl port-forward svc/lokistack-dev-gateway-http 3100:8080 -n openshift-logging
curl -G http://localhost:3100/loki/api/v1/query_range \
  -H 'X-Scope-OrgID: application' \
  --data-urlencode 'query={kubernetes_namespace_name="my-namespace"} |= "error"' \
  --data-urlencode 'start='$(date -d '1 hour ago' +%s) \
  --data-urlencode 'end='$(date +%s)
```

---

## Grafana 数据源配置

### Loki 数据源

Grafana 已配置 **3 个 Loki 数据源**（存于 monitoring ns `grafana-datasources` Secret），直连 LokiStack query-frontend，通过 `X-Scope-OrgID` 请求头区分租户：

| 数据源 | 租户 (X-Scope-OrgID) | URL |
|--------|---------------------|-----|
| `application-log` | application | http://lokistack-dev-query-frontend-http.openshift-logging.svc:3100 |
| `infrastructure-log` | infrastructure | 同上 |
| `audit-log` | audit | 同上 |

### 命名空间 → 租户映射

KDO Console 日志插件按命名空间前缀判定日志归属租户（正则：`/^openshift-|^openshift$|^default$|^kubedo-|^kube-/`）：

| 租户 | 归属命名空间 |
|------|-------------|
| **infrastructure** | 前缀 `openshift-`（如 openshift-logging）、`openshift`、`default`、`kubedo-`（如 kubedo-system）、`kube-`（kube-system/kube-public/kube-node-lease） |
| **application**（默认） | 其余全部命名空间（业务 ns 及 argo/istio-system/tekton-pipelines/monitoring/kubedo/kubernetes-terminal 等平台组件 ns） |
| **audit** | Kubernetes 审计日志 |

```bash
# 判定单个命名空间归属（infrastructure 命中则查 infrastructure/audit 租户，否则查 application）
kubectl get ns <ns> -o name | grep -qE '^(openshift-|openshift$|default$|kubedo-|kube-)' \
  && echo "infrastructure" || echo "application"
```

> ⚠️ 易混点：`kubedo`（无连字符）→ **application**；`kubedo-system` → 插件判 **infrastructure**，但 Vector 采集实际进 **application**（见下）。平台组件 ns（`monitoring`/`tekton-pipelines`/`pipelines-as-code`/`loki-operator`/`istio-system`）均属 **application** 租户。

### Vector 采集管道（logging-config ConfigMap）

采集代理为 Vector（DaemonSet `logging`），配置存于 openshift-logging ns 的 `logging-config` ConfigMap（`vector.toml`），按 **pod 日志路径 glob** 分流租户（`/var/log/pods/<ns>_<pod>/<container>/*.log`）：

| Source | 匹配路径 | log_type | 目标租户 |
|--------|---------|----------|---------|
| `input_application_container` | 除 `default_*/kube*_*/openshift*_*` 外的全部 pod | application | application |
| `input_infrastructure_container` | `default_*/kube*_*/openshift*_*` 前缀 | infrastructure | infrastructure |
| `input_infrastructure_journal` | journald（node 级，过滤 PRIORITY=7） | infrastructure | infrastructure |
| `input_audit_host/kube/openshift/ovn` | `/var/log/audit`、kube-apiserver、openshift-apiserver、oauth、ovn 审计文件 | audit | audit |

```bash
# 查看 Vector 采集配置
kubectl get cm -n openshift-logging logging-config -o jsonpath='{.data.vector\.toml}'
```

- **3 个 Loki sink** 各自独立 endpoint（`lokistack-dev-gateway-http:8080/api/logs/v1/{application|audit|infrastructure}`），bearer token 读自 Secret `logcollector-token`
- sink 统一 viaq 五标签：`kubernetes_container_name`/`kubernetes_host`/`kubernetes_namespace_name`/`kubernetes_pod_name`/`log_type`
- **openshift-logging ns 的 gateway/loki/opa/elasticsearch/kibana 容器被显式 exclude**，不采集自身日志

> 🔴 **插件正则与 Vector glob 不一致**：插件正则含 `kubedo-` 前缀（判 `kubedo-system` → infrastructure），但 Vector glob 只有 `default_*|kube*_*|openshift*_*`，不含 `kubedo-` → `kubedo-system` 日志**实际落入 application 租户**。查询时应以 Vector 实际采集为准（按路径验证），插件判定仅用于 UI 初始租户选择。

```yaml
# datasources.yaml（grafana-datasources Secret，示意结构）
apiVersion: 1
datasources:
- name: application-log
  type: loki
  access: proxy
  url: http://lokistack-dev-query-frontend-http.openshift-logging.svc:3100
  jsonData:
    httpHeaderName1: X-Scope-OrgID
  secureJsonData:
    httpHeaderValue1: application   # 分别用 application/infrastructure/audit
```

```bash
# 查看 Grafana 数据源
kubectl get secret grafana-datasources -n monitoring -o jsonpath='{.data.datasources\.yaml}' | base64 -d
```

---

## 日志保留策略

### Loki 配置（实测）

保留策略由 LokiStack CR 全局控制，当前为 **15 天**：

```yaml
# LokiStack spec.limits.global.retention
limits:
  global:
    retention:
      days: 15        # 所有租户统一保留 15 天

# Compactor 配置（lokistack-dev-config ConfigMap）
compactor:
  compaction_interval: 2h
  retention_enabled: true
  retention_delete_delay: 4h
  delete_request_store: s3
```

### 调整保留天数

```bash
kubectl patch lokistack lokistack-dev -n openshift-logging --type merge \
  -p '{"spec":{"limits":{"global":{"retention":{"days":30}}}}}'
```

### MinIO 存储策略

```yaml
# MinIO 存储类配置
storageClass:
  standard:
    type: standard
    parity: 2
```

```bash
# 查看 MinIO 存储使用
kubectl exec -it minio-0 -n openshift-logging -- mc admin info local

# 查看 Loki 存储大小
kubectl exec -it minio-0 -n openshift-logging -- mc du local/loki
```

## Loki 日志告警（Grafana 管理）

> **Loki 日志及日志告警只能通过 Grafana 管理**（Grafana Unified Alerting）。LokiStack Ruler 虽启用但**不直接承载日志告警规则**（当前 `lokistack-dev-rules-0` ConfigMap 为空）；openshift-logging ns 的 `collector` PrometheusRule 仅为 Vector/采集器指标告警（PromQL），不进入日志告警。

### 告警链路

```
Loki 数据源 (query-frontend:3100, X-Scope-OrgID 租户头)
  → Grafana Alert Rule (LogQL 查询, Unified Alerting)
  → Grafana 内置 Alertmanager (Unified Alerting 集成，非外部 alertmanager-main)
  → 企微接收器 → 企微通知
```

### 前置条件（已就绪）

- Grafana `[unified_alerting]` 已启用，告警状态历史存 Loki（`loki_remote_url` 指向 query-frontend:3100）
- 3 个 Loki 数据源已配置（application-log / infrastructure-log / audit-log）
- Grafana 内置 Alertmanager 已配置企微接收器（Grafana → Alerting → Contact points，具体 agent_id/to_user/api_secret 等硬编码信息**不可写入文档**）

### 创建前需向用户确认的信息

创建/管理日志告警前，agent 应先向用户收集以下参数（缺省项给默认值并说明）：

| 类别 | 要收集的信息 | 默认值 |
|------|-------------|--------|
| 监控范围 | 租户/数据源（application/infrastructure/audit）、目标命名空间（或全租户） | application |
| 日志条件 | 级别（8 级之一，如 error）、关键字/正则（可选）、排除条件（可选） | level="error" |
| 窗口与阈值 | 时间窗口（如 `[5m]`）、触发阈值（条数 N） | [5m] / N 由用户指定 |
| 触发设置 | 评估间隔、pending 时长、`for` | 间隔 1m、pending 2m |
| 分级标签 | severity（critical/warning 等） | critical |
| 通知 | 通知渠道（默认企微）、是否沿用默认 Contact point | 企微默认 |
| 基本信息 | 规则名称、描述、所属 rule group | rule group=kdo-logs |

> agent 创建前把收集到的参数拼成 LogQL 并回显给用户确认，再进入创建步骤。

### 创建日志告警（Grafana UI）

1. Grafana → Alerting → Alert rules → New alert rule
2. 数据源选择 `application-log`（按租户）
3. 查询：LogQL 表达式，如：

```logql
# 最近 5 分钟应用 error 级日志条数超过阈值（必须用 sum() 聚合，见下）
sum(count_over_time({kubernetes_namespace_name="my-app"} | level="error" [5m])) > 10

# 按命名空间聚合的错误率
sum(rate({kubernetes_namespace_name="my-app"} |= "ERROR" [5m])) > 0.1

# infrastructure 租户（数据源 infrastructure-log）异常系统日志
sum(count_over_time({kubernetes_namespace_name=~"kube-system|openshift-.*"} | level=~"error|critical" [10m])) > 5
```

> 租户/标签见插件 schema：viaq 标签为 `kubernetes_container_name`/`kubernetes_namespace_name`/`kubernetes_pod_name`/`level`/`log_type`；otel 为 `k8s_container_name`/`k8s_namespace_name`/`k8s_pod_name`/`severity_text`/`openshift_log_type`。

4. 评估行为（Evaluation group）：间隔 1-5m，pending 1-5m
5. 通知：选择 Contact point（Grafana 内置 Alertmanager 的企微接收器）

### 常见报错与修复

创建/评估告警时若 Grafana 报以下错误，按对应方式修复：

| 报错 | 原因 | 修复 |
|------|------|------|
| `invalid format of evaluation results for the alert definition : frame cannot uniquely be identified by its labels: has duplicate results with labels {}` | 表达式**未聚合**（如直接 `count_over_time(...) > N`），多流匹配时 Grafana 无法唯一识别 frame | LogQL 加 `sum()` 聚合：`sum(count_over_time({...}[5m])) > N` |
| `looks like time series data, only reduced data can be alerted on` | threshold 条件**直接消费时间序列**，未先 reduce 成单值 | 使用标准 3 数据点结构：**查询 A**（LogQL 计算）→ **reduce B**（Last/Sum 归约为标量）→ **threshold C**（`> N`） |

> 标准数据点结构（Grafana 告警表达式）：
> - A: `sum(count_over_time({kubernetes_namespace_name="my-app"} | level="error" [5m]))`
> - B (reduce): 类型 `Reduce`，函数 `Last`（或 Sum），将 A 的时间序列归约为标量
> - C (threshold): 类型 `Threshold`，`IS ABOVE 10`

### 管理日志告警前需向用户确认的信息

管理（编辑/删除/静默）已有告警时，agent 应先向用户确认：

| 操作 | 要确认的信息 |
|------|-------------|
| 编辑 | 规则名称或 uid、要修改的字段（查询/阈值/评估/pending/分级/通知） |
| 删除 | 规则名称或 uid（Grafana UI 删除，或 API `DELETE /api/v1/provisioning/alert-rules/{uid}`） |
| 静默 | 规则名称、静默时长（Grafana → Alerting → Silences） |
| 查看 | 规则名称/uid 或按 rule group/命名空间/级别过滤 |

> agent 可先用 `GET /api/v1/provisioning/alert-rules` 列出规则（名称/uid/ruleGroup）回显给用户确认目标，再进行操作。

### 分级对齐

日志严重级别以插件 8 级为准：`critical / error / warning / info / debug / trace / unknown / other`（阈值建议：critical→critical/emerg/fatal/alert，error→error/err，warning→warn/warning，info→info/notice，debug→debug）。

### 排查

```bash
# Grafana 内置 Alertmanager 的企微接收器在 Grafana UI 管理（Alerting → Contact points / Notification policies），
# 不存于集群 alertmanager-main Secret；monitoring ns 的 alertmanager-main 是外部 Prometheus 告警的，与日志告警无关。
kubectl get secret alertmanager-main -n monitoring -o jsonpath='{.data.alertmanager\.yaml}' | base64 -d  # 仅用于外部 Prometheus 告警

# 确认 Grafana 告警状态历史写入 Loki
kubectl get secret grafana-config -n monitoring -o jsonpath='{.data.grafana\.ini}' | base64 -d | grep -A3 unified_alerting
```

### 通过 API 创建的规则无法在 UI 编辑

通过 provisioning API（`/api/v1/provisioning/alert-rules`）创建的告警规则带 `provenance: api` 标记，Grafana UI **默认禁止编辑**（提示「此 alert rule 无法通过用户界面编辑」）。

**解锁方式**：对 **rule group** 执行 PUT 并带 `X-Disable-Provenance: true` 请求头，会同时解除该组下所有规则的 provenance，恢复 UI 可编辑：

```bash
# 先取规则组定义，再带 header PUT（folderUID/group 见规则详情）
curl -s -u admin:xxx "http://<grafana>/api/v1/provisioning/folder/<folderUID>/rule-groups/<group>" > /tmp/group.json
curl -s -u admin:xxx -X PUT \
  "http://<grafana>/api/v1/provisioning/folder/<folderUID>/rule-groups/<group>" \
  -H "Content-Type: application/json" -H "X-Disable-Provenance: true" -d @/tmp/group.json
```

> 注意：解锁粒度在 rule group 层。直接在**单条 rule** 上 PUT 带此 header 会返回 500。解锁后规则 `provenance` 变为 `null`（可编辑）；未被解锁的规则保持 `api`。

---

### 1. 日志标签规范

```yaml
# Pod 标签规范
metadata:
  labels:
    app: my-app
    app.kubernetes.io/name: my-app
    app.kubernetes.io/instance: my-app-1.0.0
    app.kubernetes.io/component: backend
    app.kubernetes.io/part-of: my-platform
```

### 2. 日志格式规范

```json
{
  "timestamp": "2026-07-17T10:00:00Z",
  "level": "info",
  "message": "Request processed",
  "service": "my-service",
  "method": "GET",
  "path": "/api/users",
  "duration": 150,
  "status": 200
}
```

### 3. 日志级别使用

- **ERROR**: 需要立即关注的错误
- **WARN**: 潜在问题，需要监控
- **INFO**: 重要业务事件
- **DEBUG**: 调试信息（生产环境关闭）

---

## 排查命令

```bash
# 查看 Loki 状态
kubectl get lokistack -n openshift-logging
kubectl get pods -n openshift-logging -l app.kubernetes.io/name=lokistack-dev

# 查看 MinIO 状态
kubectl get pods -n openshift-logging -l app=minio
kubectl get secret s3 -n openshift-logging

# 查看日志采集状态
kubectl get pods -n openshift-logging -l app=logging
kubectl logs -f ds/logging -n openshift-logging

# 测试 Loki 查询
kubectl port-forward svc/lokistack-dev-query-frontend-http 3100:3100 -n openshift-logging
curl -G http://localhost:3100/loki/api/v1/labels

# 查看 Grafana 数据源
kubectl get secret grafana-datasources -n monitoring -o jsonpath='{.data.datasources\.yaml}' | base64 -d
```

## 相关页面

- [[wiki/topics/kdo-observability]] — 可观测性概述
- [[wiki/platform/kdo-monitoring-setup]] — 监控配置
- [[wiki/platform/kdo-component-details]] — 组件详情
- [[wiki/platform/kdo-troubleshooting-patterns]] — 故障排查
