---
title: KDO 平台故障排查模式
description: 基于实际集群的常见故障模式与排查路径
created: 2026-07-17
author: pulse
tags: [kdo, 故障排查, 问题诊断, 运维]
---

# KDO 平台故障排查模式

## 排查原则

1. **从外到内**: 先检查外部访问，再检查内部组件
2. **从上到下**: 先检查应用层，再检查基础设施
3. **从现象到本质**: 先收集症状，再分析原因
4. **文档优先**: 优先参考官方文档 https://docs.kube-do.cn/

## 排查路径图

```
用户报告问题
    │
    ├──→ 应用无法访问
    │       ├──→ Ingress/Service 检查
    │       ├──→ Pod 状态检查
    │       └──→ 网络连通性检查
    │
    ├──→ Pod 启动失败
    │       ├──→ 镜像拉取检查
    │       ├──→ 资源配额检查
    │       └──→ 配置/密钥检查
    │
    ├──→ 流水线失败
    │       ├──→ Tekton 状态检查
    │       ├──→ Git 仓库访问检查
    │       └──→ Harbor 推送检查
    │
    ├──→ 监控/日志异常
    │       ├──→ Prometheus 状态检查
    │       ├──→ Loki 状态检查
    │       └──→ Grafana 数据源检查
    │
    └──→ 认证/权限问题
            ├──→ Keycloak 状态检查
            ├──→ RBAC 配置检查
            └──→ 证书检查
```

---

## 故障模式 1: Pod 无法启动

### 症状

```bash
kubectl get pods -n my-namespace
# NAME                    READY   STATUS             RESTARTS   AGE
# my-app-xxxxx           0/1     ImagePullBackOff   0          5m
```

### 排查步骤

```bash
# 1. 查看 Pod 事件
kubectl describe pod my-app-xxxxx -n my-namespace

# 2. 检查镜像拉取错误
kubectl get events -n my-namespace --field-selector involvedObject.name=my-app-xxxxx

# 3. 检查镜像是否存在
kubectl get pod my-app-xxxxx -n my-namespace -o jsonpath='{.spec.containers[*].image}'

# 4. 检查 imagePullSecrets
kubectl get pod my-app-xxxxx -n my-namespace -o jsonpath='{.spec.imagePullSecrets}'

# 5. 手动拉取测试
kubectl run -it --rm test-pull --image=my-image:tag --restart=Never
```

### 常见原因与解决方案

| 原因 | 症状 | 解决方案 |
|------|------|----------|
| 镜像不存在 | ImagePullBackOff | 检查镜像名称和标签 |
| 镜像拉取凭证错误 | Unauthorized | 检查 imagePullSecrets |
| 网络问题 | Timeout | 检查网络连通性 |
| 资源不足 | Pending | 检查资源配额 |

---

## 故障模式 2: Pod CrashLoopBackOff

### 症状

```bash
kubectl get pods -n my-namespace
# NAME                    READY   STATUS             RESTARTS   AGE
# my-app-xxxxx           0/1     CrashLoopBackOff   5          10m
```

### 排查步骤

```bash
# 1. 查看 Pod 日志
kubectl logs my-app-xxxxx -n my-namespace --previous

# 2. 查看 Pod 事件
kubectl describe pod my-app-xxxxx -n my-namespace

# 3. 检查容器退出码
kubectl get pod my-app-xxxxx -n my-namespace -o jsonpath='{.status.containerStatuses[*].lastState.terminated.exitCode}'

# 4. 进入容器调试
kubectl exec -it my-app-xxxxx -n my-namespace -- /bin/sh

# 5. 检查资源限制
kubectl describe pod my-app-xxxxx -n my-namespace | grep -A 5 "Limits"
```

### 常见退出码

| 退出码 | 含义 | 排查方向 |
|--------|------|----------|
| 0 | 正常退出 | 检查启动命令 |
| 1 | 应用错误 | 检查应用日志 |
| 137 | OOMKilled | 增加内存限制 |
| 139 | 段错误 | 检查应用代码 |
| 143 | SIGTERM | 检查优雅终止 |

---

## 故障模式 3: Pod Pending

### 症状

```bash
kubectl get pods -n my-namespace
# NAME                    READY   STATUS    RESTARTS   AGE
# my-app-xxxxx           0/1     Pending   0          5m
```

### 排查步骤

```bash
# 1. 查看 Pod 事件
kubectl describe pod my-app-xxxxx -n my-namespace

# 2. 检查资源配额
kubectl get resourcequota -n my-namespace

# 3. 检查节点状态
kubectl get nodes

# 4. 检查节点资源
kubectl top nodes

# 5. 检查 PVC 状态
kubectl get pvc -n my-namespace
```

### 常见原因与解决方案

| 原因 | 症状 | 解决方案 |
|------|------|----------|
| 资源不足 | Insufficient cpu/memory | 增加节点或调整资源请求 |
| PVC 未绑定 | Waiting for PVC | 检查 StorageClass 和 NFS |
| 节点选择器不匹配 | no nodes match | 检查 nodeSelector/affinity |
| taint 容忍 | no taint toleration | 添加 tolerations |

---

## 故障模式 4: 流水线失败

### 症状

```bash
kubectl get pipelineruns -n my-namespace
# NAME                    SUCCEEDED   REASON   STARTTIME   COMPLETIONTIME
# my-app-main-xxxxx      False       Failed   5m          2m
```

### 排查步骤

```bash
# 1. 查看 PipelineRun 状态
kubectl get pipelinerun my-app-main-xxxxx -n my-namespace -o yaml

# 2. 查看 TaskRun 状态
kubectl get taskruns -n my-namespace

# 3. 查看失败任务日志
kubectl logs -l tekton.dev/pipelineRun=my-app-main-xxxxx -n my-namespace --all-containers

# 4. 查看 Tekton 控制器日志
kubectl logs -f deploy/tekton-pipelines-controller -n tekton-pipelines

# 5. 检查 Git 仓库访问
kubectl get secret -n my-namespace -l tekton.dev/git-0
```

### 常见原因与解决方案

| 原因 | 症状 | 解决方案 |
|------|------|----------|
| Git 仓库访问失败 | authentication required | 检查 Git 凭证 |
| 镜像构建失败 | build failed | 检查 Dockerfile |
| 镜像推送失败 | push denied | 检查 Harbor 凭证 |
| 部署失败 | deployment failed | 检查 Kubernetes 权限 |

---

## 故障模式 5: 监控数据缺失

### 症状

- Grafana 仪表板无数据
- Prometheus 查询无结果
- 告警不触发

### 排查步骤

```bash
# 1. 检查 Prometheus 状态
kubectl get prometheus -n monitoring
kubectl logs prometheus-k8s-0 -n monitoring

# 2. 检查 ServiceMonitor
kubectl get servicemonitor -n monitoring

# 3. 检查 Endpoints
kubectl get endpoints -n monitoring

# 4. 测试 Prometheus 查询
kubectl port-forward svc/prometheus-k8s 9090:9090 -n monitoring
# 访问 http:/localhost:9090

# 5. 检查 Grafana 数据源
kubectl get secret grafana-config -n monitoring -o jsonpath='{.data.prometheus-yaml}' | base64 -d
```

### 常见原因与解决方案

| 原因 | 症状 | 解决方案 |
|------|------|----------|
| ServiceMonitor 缺失 | 无 targets | 创建 ServiceMonitor |
| 端口不匹配 | scrape failed | 检查端口配置 |
| 标签不匹配 | 无数据 | 检查标签选择器 |
| 网络隔离 | timeout | 检查 NetworkPolicy |

---

## 故障模式 6: 日志查询失败

### 症状

- Grafana Loki 查询无结果
- 日志延迟严重
- 日志丢失

### 排查步骤

```bash
# 1. 检查 Loki 状态
kubectl get lokistack -n openshift-logging
kubectl get pods -n openshift-logging -l app.kubernetes.io/component

# 2. 检查日志采集
kubectl get pods -n openshift-logging -l app=logging
kubectl logs -f ds/logging -n openshift-logging

# 3. 检查 MinIO 存储
kubectl get pods -n openshift-logging -l app=minio
kubectl exec -it minio-0 -n openshift-logging -- mc admin info local

# 4. 测试 Loki 查询
kubectl port-forward svc/lokistack-dev-gateway-http 3100:8080 -n openshift-logging
curl http:/localhost:3100/loki/api/v1/labels

# 5. 检查 Grafana 数据源
kubectl get secret grafana-config -n monitoring -o jsonpath='{.data.loki-yaml}' | base64 -d
```

---

## 故障模式 7: 认证/权限问题

### 症状

- 用户无法登录 Console
- API 请求返回 401/403
- RBAC 权限不生效

### 排查步骤

```bash
# 1. 检查 Keycloak 状态
kubectl get statefulset keycloak -n kubedo-system
kubectl logs keycloak-0 -n kubedo-system

# 2. 检查 OIDC 配置
kubectl describe pod kube-apiserver-node31 -n kube-system | grep oidc

# 3. 检查 RBAC
kubectl get roles,clusterroles -A | grep kdo
kubectl get rolebindings,clusterrolebindings -A | grep kdo

# 4. 测试权限
kubectl auth can-i get pods -n my-namespace --as=developer1

# 5. 检查证书
kubectl get certificates -A
kubectl describe certificate -n cert-manager
```

---

## 故障模式 8: 存储问题

### 症状

- PVC 处于 Pending 状态
- Pod 无法挂载卷
- 存储空间不足

### 排查步骤

```bash
# 1. 检查 PVC 状态
kubectl get pvc -n my-namespace
kubectl describe pvc my-pvc -n my-namespace

# 2. 检查 PV
kubectl get pv
kubectl describe pv pvc-xxxxx

# 3. 检查 StorageClass
kubectl get storageclass
kubectl describe storageclass nfs-client

# 4. 检查 NFS Provisioner
kubectl get pods -n kubedo-system -l app=nfs-subdir-external-provisioner
kubectl logs -f deploy/nfs-subdir-external-provisioner -n kubedo-system

# 5. 检查 NFS 服务器连通性
kubectl run -it --rm nfs-test --image=busybox:1.36 -- mount <nfs-server-ip>:/exports/data /mnt
```

---

## 故障模式 9: Ingress 访问问题

### 症状

- 外部无法访问应用
- 502/504 错误
- SSL 证书错误

### 排查步骤

```bash
# 1. 检查 Ingress 状态
kubectl get ingress -n my-namespace
kubectl describe ingress my-app -n my-namespace

# 2. 检查 Ingress 控制器
kubectl get pods -n ingress-nginx
kubectl logs -f deploy/ingress-nginx-controller -n ingress-nginx

# 3. 检查 Service/Endpoints
kubectl get svc -n my-namespace
kubectl get endpoints -n my-namespace

# 4. 测试内部访问
kubectl run -it --rm test-svc --image=busybox:1.36 -- wget -qO- http:/my-service.my-namespace.svc.cluster.local

# 5. 检查证书
kubectl get secret my-app-tls -n my-namespace
kubectl describe certificate my-app-cert -n my-namespace
```

---

## 快速排查命令

```bash
# 集群状态
kubectl get nodes
kubectl get pods -A --field-selector=status.phase!=Running

# 资源使用
kubectl top nodes
kubectl top pods -A

# 事件
kubectl get events -A --sort-by='.lastTimestamp' | tail -20

# 组件状态
kubectl get componentstatuses

# 命名空间资源
kubectl get all -n my-namespace
```

---

## 升级矩阵

| 问题类型 | 第一响应 | 升级对象 |
|----------|----------|----------|
| Pod 启动失败 | Desk | Atlas |
| 流水线失败 | Flow | Atlas |
| 监控异常 | Pulse | Atlas |
| 认证失败 | Shield | @human |
| 存储问题 | Atlas | @human |
| 网络问题 | Atlas | @human |

---

## 相关页面

- [[wiki/troubleshooting/TROUBLESHOOTING]] — 故障排查知识库
- [[wiki/platform/kdo-cluster-architecture]] — 架构全景图
- [[wiki/platform/kdo-component-details]] — 组件详情
- [[wiki/kdo-official-docs]] — 官方文档索引
