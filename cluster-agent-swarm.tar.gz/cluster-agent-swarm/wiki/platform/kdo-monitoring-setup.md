---
title: KDO 监控栈配置
description: Prometheus/Grafana/Alertmanager 监控栈详细配置
created: 2026-07-17
author: pulse
tags: [kdo, 监控, prometheus, grafana, alertmanager]
---

# KDO 监控栈配置

## 监控栈概述

KDO 使用 kube-prometheus-stack 作为监控解决方案，包含 Prometheus、Grafana、Alertmanager 等组件。

## 组件架构

```
┌─────────────────────────────────────────────────────┐
│                  Grafana (可视化)                    │
│              端口: 3000 (HTTP)                      │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│              Prometheus (指标采集)                   │
│           版本: v3.5.0 / 存储: 200Gi               │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│             Alertmanager (告警处理)                  │
│          版本: v0.28.1 / 保留: 120h                │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│              Exporters (数据采集)                    │
│   Node Exporter │ Kube State Metrics │ Blackbox    │
└─────────────────────────────────────────────────────┘
```

## Prometheus 配置

### 部署配置

```yaml
apiVersion: monitoring.coreos.com/v1
kind: Prometheus
metadata:
  name: k8s
  namespace: monitoring
spec:
  version: v3.5.0
  image: registry.cn-shenzhen.aliyuncs.com/kubedo/prometheus:v3.5.0
  replicas: 1
  evaluationInterval: 30s
  enableRemoteWriteReceiver: true
  externalLabels:
    cluster: k8s-n31
  alerting:
    alertmanagers:
    - apiVersion: v2
      name: alertmanager-main
      namespace: monitoring
      port: web
  storage:
    volumeClaimTemplate:
      spec:
        accessModes: ["ReadWriteOnce"]
        resources:
          requests:
            storage: 200Gi
```

### ServiceMonitor 列表

| ServiceMonitor | 命名空间 | 用途 |
|----------------|----------|------|
| alertmanager-main | monitoring | Alertmanager 指标 |
| blackbox-exporter | monitoring | HTTP/TCP 探针 |
| coredns | monitoring | DNS 指标 |
| grafana | monitoring | Grafana 自身指标 |
| kube-apiserver | monitoring | API Server 指标 |
| kube-controller-manager | monitoring | Controller Manager |
| kube-scheduler | monitoring | Scheduler |
| kube-state-metrics | monitoring | K8s 资源状态 |
| kubelet | monitoring | Kubelet 指标 |
| node-exporter | monitoring | 节点指标 |
| prometheus-adapter | monitoring | Adapter 指标 |
| prometheus-k8s | monitoring | Prometheus 自身 |
| prometheus-operator | monitoring | Operator 指标 |
| cluster-logging-operator-metrics-monitor | openshift-logging | 日志 Operator |
| logging | openshift-logging | 日志采集 |
| tekton-pipelines-monitor | tekton-pipelines | Tekton 指标 |

### 常用 PromQL 查询

```promql
# 节点 CPU 使用率
100 - (avg by(instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)

# 节点内存使用率
(1 - node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes) * 100

# Pod CPU 使用率
sum(rate(container_cpu_usage_seconds_total{namespace="<ns>"}[5m])) by (pod)

# Pod 内存使用率
sum(container_memory_working_set_bytes{namespace="<ns>"}) by (pod) / 
sum(kube_pod_container_resource_limits{resource="memory", namespace="<ns>"}) by (pod) * 100

# Pod 网络流量
sum(rate(container_network_receive_bytes_total{namespace="<ns>"}[5m])) by (pod)

# Pod 重启次数
increase(kube_pod_container_status_restarts_total{namespace="<ns>"}[1h])

# 命名空间资源配额使用
kube_resourcequota{namespace="<ns>"}
```

```bash
# 访问 Prometheus UI
kubectl port-forward svc/prometheus-k8s 9090:9090 -n monitoring

# 查看 Prometheus 配置
kubectl get prometheus -n monitoring -o yaml

# 查看告警规则
kubectl get prometheusrule -n monitoring
```

---

## Grafana 配置

### 部署配置

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: grafana
  namespace: monitoring
spec:
  replicas: 1
  template:
    spec:
      containers:
      - name: grafana
        ports:
        - containerPort: 3000
```

### 数据源配置

Grafana 数据源通过 Secret 配置：

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: grafana-datasources
  namespace: monitoring
data:
  prometheus-yaml: <base64>
  loki-yaml: <base64>
```

### 预装仪表板

| 仪表板名称 | 用途 |
|-----------|------|
| Kubernetes Cluster Total | 集群整体概览 |
| K8s Resources Cluster | 集群资源使用 |
| K8s Resources Namespace | 命名空间资源使用 |
| K8s Resources Pod | Pod 资源使用 |
| K8s Resources Workload | 工作负载资源使用 |
| Node Exporter | 节点详细指标 |
| Prometheus | Prometheus 自身监控 |
| Persistent Volumes Usage | 存储使用情况 |
| Kubelet | Kubelet 指标 |
| API Server | API Server 指标 |
| Controller Manager | Controller Manager |
| Scheduler | Scheduler 指标 |

```bash
# 访问 Grafana UI
kubectl port-forward svc/grafana 3000:3000 -n monitoring

# 查看 Grafana 数据源
kubectl get secret grafana-config -n monitoring -o jsonpath='{.data.prometheus-yaml}' | base64 -d

# 查看仪表板配置
kubectl get cm grafana-dashboards -n monitoring -o yaml
```

---

## Alertmanager 配置

### 部署配置

```yaml
apiVersion: monitoring.coreos.com/v1
kind: Alertmanager
metadata:
  name: main
  namespace: monitoring
spec:
  replicas: 1
  version: v0.28.1
  image: registry.cn-shenzhen.aliyuncs.com/kubedo/alertmanager:v0.28.1
  retention: 120h
  resources:
    limits:
      cpu: 100m
      memory: 100Mi
    requests:
      cpu: 4m
      memory: 100Mi
```

### 告警路由配置

```yaml
# Alertmanager 配置 (来自 Secret: alertmanager-main-generated)
global:
  resolve_timeout: 5m

route:
  group_by: ['alertname', 'namespace', 'service']
  group_wait: 30s
  group_interval: 5m
  repeat_interval: 4h
  receiver: 'default'
  routes:
  - match:
      severity: critical
    receiver: 'critical'
  - match:
      severity: warning
    receiver: 'warning'

receivers:
- name: 'default'
  # 配置通知渠道 (webhook, email, etc.)

- name: 'critical'
  # 严重告警通知

- name: 'warning'
  # 警告告警通知
```

### 常用告警规则

```yaml
# Pod 重启频繁
- alert: PodCrashLooping
  expr: increase(kube_pod_container_status_restarts_total[1h]) > 5
  for: 5m
  labels:
    severity: warning

# Pod 内存使用过高
- alert: PodMemoryHigh
  expr: |
    container_memory_working_set_bytes / 
    kube_pod_container_resource_limits{resource="memory"} > 0.9
  for: 5m
  labels:
    severity: warning

# 节点 CPU 使用过高
- alert: NodeCpuHigh
  expr: 100 - (avg by(instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100) > 85
  for: 10m
  labels:
    severity: critical

# PVC 使用率高
- alert: PVCUsageHigh
  expr: kubelet_volume_stats_used_bytes / kubelet_volume_stats_capacity_bytes > 0.85
  for: 5m
  labels:
    severity: warning
```

```bash
# 访问 Alertmanager UI
kubectl port-forward svc/alertmanager-main 9093:9093 -n monitoring

# 查看告警配置
kubectl get secret alertmanager-main-generated -n monitoring -o jsonpath='{.data.alertmanager\.yaml}' | base64 -d

# 查看当前告警
kubectl port-forward svc/alertmanager-main 9093:9093 -n monitoring
# 访问 http:/localhost:9093/alerts
```

---

## Exporters 配置

### Node Exporter

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: node-exporter
  namespace: monitoring
spec:
  template:
    spec:
      containers:
      - name: node-exporter
        ports:
        - containerPort: 9100
          name: metrics
```

### Kube State Metrics

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: kube-state-metrics
  namespace: monitoring
spec:
  replicas: 1
  template:
    spec:
      containers:
      - name: kube-state-metrics
        ports:
        - containerPort: 8080
          name: http-metrics
        - containerPort: 8081
          name: telemetry
```

### Blackbox Exporter

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: blackbox-exporter
  namespace: monitoring
spec:
  replicas: 1
  template:
    spec:
      containers:
      - name: blackbox-exporter
        ports:
        - containerPort: 9115
          name: http
        - containerPort: 9116
          name: probe
```

```bash
# 查看 Exporters 状态
kubectl get pods -n monitoring -l app=node-exporter
kubectl get pods -n monitoring -l app=kube-state-metrics
kubectl get pods -n monitoring -l app=blackbox-exporter
```

---

## 监控最佳实践

### 1. 命名空间标签

确保命名空间有正确的监控标签：

```bash
kubectl label namespace my-namespace monitoring=enabled
```

### 2. ServiceMonitor 创建

为自定义应用创建 ServiceMonitor：

```yaml
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: my-app
  namespace: monitoring
  labels:
    release: prometheus
spec:
  namespaceSelector:
    matchNames:
    - my-namespace
  selector:
    matchLabels:
      app: my-app
  endpoints:
  - port: metrics
    interval: 30s
```

### 3. 告警规则创建

> 此处的 PrometheusRule 为**指标告警**（PromQL）。KDO 平台的**日志告警特指 Loki 日志告警，只能通过 Grafana 管理**（Grafana Unified Alerting + LogQL），不在此 PrometheusRule 范畴内，详见 [[wiki/platform/kdo-logging-setup]]。

为自定义应用创建指标告警规则：

```yaml
apiVersion: monitoring.coreos.com/v1
kind: PrometheusRule
metadata:
  name: my-app-rules
  namespace: monitoring
spec:
  groups:
  - name: my-app
    rules:
    - alert: MyAppDown
      expr: up{job="my-app"} == 0
      for: 5m
      labels:
        severity: critical
      annotations:
        summary: "My App is down"
```

---

## 排查命令

```bash
# 查看 Prometheus 状态
kubectl get prometheus -n monitoring
kubectl logs prometheus-k8s-0 -n monitoring

# 查看 Grafana 状态
kubectl get deploy grafana -n monitoring
kubectl logs deploy/grafana -n monitoring

# 查看 Alertmanager 状态
kubectl get alertmanager -n monitoring
kubectl logs alertmanager-main-0 -n monitoring

# 查看 ServiceMonitor
kubectl get servicemonitor -n monitoring

# 查看告警规则
kubectl get prometheusrule -n monitoring

# 查询 Prometheus 指标
kubectl port-forward svc/prometheus-k8s 9090:9090 -n monitoring
# 访问 http:/localhost:9090
```

## 相关页面

- [[wiki/topics/kdo-observability]] — 可观测性概述
- [[wiki/platform/kdo-component-details]] — 组件详情
- [[wiki/platform/kdo-logging-setup]] — 日志配置
- [[wiki/platform/kdo-troubleshooting-patterns]] — 故障排查
