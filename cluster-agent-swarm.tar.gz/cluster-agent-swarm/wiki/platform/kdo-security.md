---
title: KDO 安全配置
description: Keycloak/Cert-Manager/RBAC 安全配置详解
created: 2026-07-17
author: shield
tags: [kdo, 安全, keycloak, rbac, cert-manager]
---

# KDO 安全配置

## 安全概述

KDO 使用 Keycloak 作为身份认证中心，Cert-Manager 管理证书，结合 Kubernetes RBAC 实现完整的安全体系。

## 组件架构

```
┌─────────────────────────────────────────────────────┐
│                 用户认证 (Authentication)            │
│              Keycloak (OIDC)                        │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│                 权限控制 (Authorization)             │
│              Kubernetes RBAC                       │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│                 证书管理 (Certificates)             │
│              Cert-Manager                          │
└─────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────┐
│                 网络安全 (Network)                  │
│              NetworkPolicy + Ingress TLS           │
└─────────────────────────────────────────────────────┘
```

## Keycloak 配置

### 部署配置

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: keycloak
  namespace: kubedo-system
spec:
  replicas: 1
  serviceName: keycloak-headless
  template:
    spec:
      containers:
      - name: keycloak
        env:
        - name: KEYCLOAK_ADMIN_PASSWORD
          valueFrom:
            secretKeyRef:
              key: admin-password
              name: keycloak
        - name: KEYCLOAK_DATABASE_PASSWORD
          valueFrom:
            secretKeyRef:
              key: password
              name: keycloak-postgresql
        - name: KEYCLOAK_HTTP_RELATIVE_PATH
          value: /auth
        ports:
        - containerPort: 8080
          name: http
        - containerPort: 8443
          name: https
```

### Keycloak 服务

| 服务名 | 类型 | 端口 | 用途 |
|--------|------|------|------|
| keycloak | NodePort | 8080 | HTTP 访问 |
| keycloak-headless | ClusterIP | None | Headless 服务 |
| keycloak-postgresql | ClusterIP | 5432 | 数据库 |

### Keycloak 配置

```yaml
# ConfigMap: keycloak-env-vars
data:
  KEYCLOAK_ADMIN: admin
  KEYCLOAK_HTTP_RELATIVE_PATH: /auth
  KEYCLOAK_LOGLEVEL: INFO
  JAVA_OPTS_APPEND: "-Xms256m -Xmx512m"
```

```bash
# 查看 Keycloak 状态
kubectl get statefulset keycloak -n kubedo-system
kubectl logs keycloak-0 -n kubedo-system

# 获取管理员密码
kubectl get secret keycloak -n kubedo-system -o jsonpath='{.data.admin-password}' | base64 -d

# 访问 Keycloak 控制台
kubectl port-forward svc/keycloak 8080:80 -n kubedo-system
# 访问 http:/localhost:8080/auth/admin
```

### OIDC 配置

KDO 使用 Keycloak 作为统一 OIDC 身份提供者，以下三个组件的 OIDC 参数**必须完全一致**，否则用户无法登录:

| 参数 | kube-apiserver | Console | Grafana |
|------|---------------|---------|---------|
| **Issuer URL** | `--oidc-issuer-url` | `auth.issuerURL` | `auth_url`/`token_url`/`api_url` |
| **Client ID** | `--oidc-client-id` | `auth.clientID` | `client_id` |
| **Client Secret** | — | `auth.clientSecret` | `client_secret` |

#### 一致性校验命令

```bash
# 1. kube-apiserver OIDC 参数
kubectl get pod -n kube-system -l component=kube-apiserver -o yaml | grep oidc

# 2. Console OIDC 参数
kubectl get cm -n kubedo-system console -o json | jq '.data["config.yaml"]' | grep -E 'issuerURL|clientID|clientSecret'

# 3. Grafana OIDC 参数
kubectl exec -n monitoring deploy/grafana -- cat /etc/grafana/grafana.ini | grep -A 20 '\[auth.generic_oauth\]'

# 4. 验证三项的 issuerURL/oauth_url 指向同一 Keycloak realm
# 匹配规则: ${protocol}://${host}:${port}/realms/${realm} 必须完全相同
```

#### 值来源（动态获取，勿写死）

通过以下命令动态获取各组件实际值，验证一致性:

| 参数 | 获取命令 |
|------|---------|
| kube-apiserver Issuer URL | `kubectl get pod -n kube-system -l component=kube-apiserver -o json \| jq -r '.items[0].spec.containers[0].command[] \| select(startswith("--oidc-issuer-url"))' \| cut -d= -f2` |
| kube-apiserver Client ID | `kubectl get pod -n kube-system -l component=kube-apiserver -o json \| jq -r '.items[0].spec.containers[0].command[] \| select(startswith("--oidc-client-id"))' \| cut -d= -f2` |
| Console Issuer URL | `kubectl get cm -n kubedo-system console -o json \| jq -r '.data["config.yaml"]' \| grep issuerURL \| awk '{print $2}'` |
| Console Client ID | `kubectl get cm -n kubedo-system console -o json \| jq -r '.data["config.yaml"]' \| grep clientID \| awk '{print $2}'` |
| Console 访问地址 | `kubectl get cm -n kubedo-system console -o json \| jq -r '.data["config.yaml"]' \| grep consoleBaseAddress \| awk '{print $2}'`（无权限时回退: `kubectl get ingress -n kubedo-system console -o jsonpath='{.spec.rules[0].host}'`） |
| Grafana Keycloak URL | `kubectl exec -n monitoring deploy/grafana -- cat /etc/grafana/grafana.ini \| grep -A 20 '\[auth.generic_oauth\]' \| grep 'auth_url' \| cut -d= -f2 \| xargs` |
| Grafana Client ID | `kubectl exec -n monitoring deploy/grafana -- cat /etc/grafana/grafana.ini \| grep -A 20 '\[auth.generic_oauth\]' \| grep 'client_id' \| cut -d= -f2 \| xargs` |
| Grafana 访问地址 | `kubectl get ingress -n monitoring grafana -o jsonpath='{.spec.rules[0].host}'`（无 Ingress 时回退: `kubectl -n monitoring port-forward svc/grafana 3000:3000` → `http://localhost:3000`） |

#### 常见不一致问题

```bash
# 错误1: issuerURL 不匹配（域名 vs IP）
# Console: https://keycloak.kube-do.cc/realms/kdo
# API Server: https://<keycloak-host>:<keycloak-port>/realms/kdo
# → OIDC Token 验证失败，用户无法登录

# 错误2: Client ID 不匹配
# Console: clientID=kdo-console
# API Server: oidc-client-id=kdo
# → API Server 无法验证 Token 的 audience

# 修复: 三个组件的 oidc-issuer-url / issuerURL / auth_url 必须指向完全相同的 URL+realm
```

```yaml
# Kubernetes API Server OIDC 配置（参考）
# 实际地址从集群动态获取，勿硬编码
# /etc/kubernetes/kubeadm-config.yaml
apiVersion: kubeadm.k8s.io/v1beta3
kind: ClusterConfiguration
apiServer:
  extraArgs:
    oidc-issuer-url: https://<keycloak-host>:<port>/realms/kdo
    oidc-client-id: kdo
    oidc-username-claim: email
    oidc-groups-claim: groups
```

---

## RBAC 配置

### 角色定义

```yaml
# 开发者角色
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: kdo-developer
  namespace: my-namespace
rules:
- apiGroups: [""]
  resources: ["pods", "pods/log", "services", "configmaps"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["apps"]
  resources: ["deployments", "statefulsets"]
  verbs: ["get", "list", "watch", "update", "patch"]

# 运维角色
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: kdo-operator
rules:
- apiGroups: [""]
  resources: ["nodes", "namespaces", "persistentvolumes"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["apps"]
  resources: ["deployments", "statefulsets", "daemonsets"]
  verbs: ["*"]
```

### 角色绑定

```yaml
# 用户角色绑定
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: developer-binding
  namespace: my-namespace
subjects:
- kind: User
  name: developer1
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: Role
  name: kdo-developer
  apiGroup: rbac.authorization.k8s.io

# 组角色绑定
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: team-binding
  namespace: my-namespace
subjects:
- kind: Group
  name: dev-team
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: Role
  name: kdo-developer
  apiGroup: rbac.authorization.k8s.io
```

### KDO 预定义角色

| 角色名 | 权限 | 用途 |
|--------|------|------|
| kdo-developer | 应用管理、日志查看 | 开发人员 |
| kdo-operator | 完整运维权限 | 运维人员 |
| kdo-admin | 平台管理权限 | 管理员 |
| kdo-viewer | 只读权限 | 观察者 |

```bash
# 查看角色
kubectl get roles -A
kubectl get clusterroles | grep kdo

# 查看角色绑定
kubectl get rolebindings -A
kubectl get clusterrolebindings | grep kdo

# 测试权限
kubectl auth can-i get pods -n my-namespace --as=developer1
kubectl auth can-i create deployments -n my-namespace --as=developer1
```

---

## Cert-Manager 配置

### 部署配置

```yaml
# Cert-Manager
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cert-manager
  namespace: cert-manager

# CA Injector
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cert-manager-cainjector
  namespace: cert-manager

# Webhook
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cert-manager-webhook
  namespace: cert-manager
```

### ClusterIssuer 配置

```yaml
# Let's Encrypt 生产环境
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@example.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx

# Let's Encrypt 测试环境
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-staging
spec:
  acme:
    server: https://acme-staging-v02.api.letsencrypt.org/directory
    email: admin@example.com
    privateKeySecretRef:
      name: letsencrypt-staging
    solvers:
    - http01:
        ingress:
          class: nginx
```

### Certificate 配置

```yaml
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: my-app-cert
  namespace: my-namespace
spec:
  secretName: my-app-tls
  issuerRef:
    name: letsencrypt-prod
    kind: ClusterIssuer
  dnsNames:
  - my-app.example.com
  - www.my-app.example.com
  duration: 2160h # 90 days
  renewBefore: 360h # 15 days
```

```bash
# 查看 Cert-Manager 状态
kubectl get pods -n cert-manager

# 查看 ClusterIssuer
kubectl get clusterissuer

# 查看 Certificate
kubectl get certificates -A
kubectl describe certificate my-app-cert -n my-namespace

# 查看 Secret
kubectl get secret my-app-tls -n my-namespace
```

---

## Pod 安全

### Pod Security Standards

```yaml
# 命名空间级别
apiVersion: v1
kind: Namespace
metadata:
  name: my-namespace
  labels:
    pod-security.kubernetes.io/enforce: restricted
    pod-security.kubernetes.io/enforce-version: latest
    pod-security.kubernetes.io/audit: restricted
    pod-security.kubernetes.io/audit-version: latest
    pod-security.kubernetes.io/warn: restricted
    pod-security.kubernetes.io/warn-version: latest
```

### SecurityContext

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  template:
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        fsGroup: 1000
        seccompProfile:
          type: RuntimeDefault
      containers:
      - name: my-app
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop: ["ALL"]
```

---

## 网络安全

### NetworkPolicy

```yaml
# 默认拒绝所有入站
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-ingress
  namespace: my-namespace
spec:
  podSelector: {}
  policyTypes:
  - Ingress

# 允许前端访问后端
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-frontend
  namespace: my-namespace
spec:
  podSelector:
    matchLabels:
      app: backend
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: frontend
    ports:
    - port: 8080
```

### Ingress TLS

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-app
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
spec:
  tls:
  - hosts:
    - my-app.example.com
    secretName: my-app-tls
  rules:
  - host: my-app.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: my-app
            port:
              number: 80
```

---

## 安全审计

### 审计日志

```yaml
# Kubernetes API Server 审计配置
# /etc/kubernetes/audit-policy.yaml
apiVersion: audit.k8s.io/v1
kind: Policy
rules:
- level: RequestResponse
  resources:
  - group: ""
    resources: ["secrets", "configmaps"]
- level: Metadata
  resources:
  - group: ""
    resources: ["pods", "services"]
- level: None
  resources:
  - group: ""
    resources: ["events"]
```

### 安全扫描

```bash
# 镜像扫描
trivy image my-app:1.0

# 集群扫描
kube-bench run

# RBAC 审计
kubectl auth can-i --list --as=system:anonymous
```

---

## 排查命令

```bash
# 查看 Keycloak 状态
kubectl get statefulset keycloak -n kubedo-system
kubectl logs keycloak-0 -n kubedo-system

# 查看 RBAC
kubectl get roles,clusterroles -A | grep kdo
kubectl get rolebindings,clusterrolebindings -A | grep kdo

# 查看 Cert-Manager
kubectl get pods -n cert-manager
kubectl get certificates -A
kubectl get clusterissuer

# 测试认证
kubectl auth can-i get pods -n my-namespace --as=developer1

# 查看审计日志
kubectl logs -f kube-apiserver-node31 -n kube-system | grep audit
```

## 相关页面

- [[wiki/concepts/kdo-rbac-auth]] — RBAC/认证概念
- [[wiki/platform/kdo-component-details]] — 组件详情
- [[wiki/platform/kdo-cluster-architecture]] — 架构全景图
- [[wiki/platform/kdo-troubleshooting-patterns]] — 故障排查
