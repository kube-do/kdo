---
title: KDO 应用管理
tags: [kdo, applications, helm, docker, devfile]
---

# KDO 应用管理

KDO 支持 5 种创建应用的方式，覆盖从简单部署到完整 CI/CD 的不同场景。

---

## 5 种创建方式

| 方式 | 自动化程度 | 适用场景              |
|------|----------|-------------------|
| **应用(Git 仓库)** | ★★★★★ | 需要自动化 CI/CD 的代码项目 |
| **流水线(Tekton)** | ★★★★ | 自定义 CI/CD 流程      |
| **Helm 应用** | ★★★★ | 复杂应用、中间件          |
| **镜像构建** | ★★★ | 有源码需构建，无需完整流水线    |
| **手动镜像** | ★ | 快速部署、测试、一次性服务     |

---

## 手动镜像

前置条件: 镜像可用、仓库访问权限、端口声明、目标命名空间

### 表单字段

| 字段 | 说明 |
|------|------|
| 应用名称 | 应用标识 |
| 镜像地址 | 完整镜像路径 |
| 应用端口 | 容器监听端口 |
| 副本数 | 初始副本数 |
| 拉取策略 | Always / IfNotPresent / Never |
| 命令/参数 | 容器启动命令 |
| 环境变量 | 键值对 / ConfigMap / Secret 引用 |
| 资源限制 | CPU/内存 request + limit |
| 数据持久化 | 挂载 PVC |
| 健康检查 | 存活/就绪探针 |

平台自动生成 **Deployment + Service (ClusterIP)**。

---

## Git 仓库应用

基于 **Pipelines as Code** 方式创建，对接 GitHub/GitLab/Gitee/Gitea。

只需 **Git URL + Git Token** 即可自动生成多环境多分支流水线。

### 自动生成文件

| 文件 | 说明 |
|------|------|
| `devfile.yaml` | 应用定义 |
| `.tekton/` | 流水线定义 (`应用名-环境-分支.yaml`) |
| `docker/Dockerfile` | 镜像配置 |
| `kubernetes/` | 部署配置 |

### 分支流水线管理

- 图形化 + YAML 编辑
- 支持手动回滚

---

## Helm 应用

### Helm 三大核心概念

| 概念 | 说明 |
|------|------|
| **Chart** | 应用打包格式 |
| **Repository** | Chart 仓库 |
| **Release** | 部署实例 |

### KDO 默认集成仓库

- `kubedo`

### 安装向导

1. 基础信息: Release 名称、命名空间、Chart 版本
2. 参数配置: 图形化编辑 values.yaml
3. 审查与安装

### 值优先级

```
Chart 默认 values.yaml → UI 提交值 → --set 参数 → 自定义 YAML 文件
```

---

## 镜像构建

从源码自动构建容器镜像并部署:

- 源码管理、自动 docker build
- 推送到内置 Harbor
- 镜像地址格式: 由 Harbor 外部端点 + 项目名 + 应用名 + Tag 组成，格式为 `<harbor-endpoint>/<namespace>/<app-name>:<tag>`
- 支持多语言构建模板 (Java/Go/Python/Node.js)
- 自动生成 Deployment + Service

### 常见构建失败

| 原因 | 解决 |
|------|------|
| Git 克隆失败 | 检查仓库权限和 URL |
| Dockerfile 未找到 | 检查 Dockerfile 路径 |
| 端口冲突 | 检查端口占用 |
| 推送失败 | 检查 Harbor 凭证 |
| 超时 | 增加构建超时时间 |

---

## 应用生命周期

KDO 提供完整的应用管理:

- 详情页面 (指标、YAML、事件)
- 副本数编辑
- HPA 配置
- 健康检查编辑
- 存储添加
- 更新策略
- 资源限制编辑

---

## ConfigMap 和 Secret

### ConfigMap

- 键值对存储非敏感数据
- 作为环境变量、命令行参数或挂载卷
- 编辑: 图形界面 + YAML 双模式

### Secret

- 存储敏感信息 (密码、API 密钥、TLS 证书)
- 创建: UI 表单 / kubectl / YAML
- 使用: 环境变量 / 文件挂载 / 镜像拉取密钥
- 支持类型: Opaque、SA Token、TLS、dockerconfigjson、basic-auth、ssh-auth
- 安全性: Base64 仅编码非加密，建议配置 EncryptionConfiguration

### Secret 最佳实践

- 最小权限、定期轮转
- 命名规范: `<app>-<env>-<type>`
- 避免明文
- 使用外部 Secret Store (Vault)

---

## ImageChange 自动触发滚动更新

当应用的 ImageStream 中的 tag 被更新时，KDC ImageStreamController 自动触发 Deployment 滚动更新：

1. 扫描当前 Namespace 下所有 Deployment
2. 检查 Deployment 容器镜像地址是否引用该 ImageStream 的 tag
3. 匹配成功 → 添加 annotation `kdc.kube-do.cn/image-change.{is--tag}` = 时间戳
4. Deployment 控制器检测 annotation 变更 → 触发 Pod 滚动更新

详见 [[kdc-image-stream]]。

---

## 相关页面

- [[kdc-image-stream]]
- [[kdc-project-env-lifecycle]]
- [[kdo-pipelines]]
- [[kdo-platform-project-management]]
- [[kdo-workloads]]
- [[kdo-storage]]

---

_Last updated: 2026-07-17_
