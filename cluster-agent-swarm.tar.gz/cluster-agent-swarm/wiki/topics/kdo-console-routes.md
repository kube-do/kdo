---
title: KDO Console 路由清单
tags: [kdo, console, routes, url]
---

# KDO Console 路由清单

> 完整的前端路由映射，Agent 根据此表拼接 Console 页面 URL。
>
> **基础地址获取**: `kubectl get cm -n kubedo-system console -o json | jq -r '.data["config.yaml"]' | grep consoleBaseAddress | awk '{print $2}'`
>
> **回退方式**: `kubectl get ingress -n kubedo-system console -o jsonpath='{.spec.rules[0].host}'`
>
> **URL 模板**: `${CONSOLE_BASE}${path}`，其中 `${path}` 为下表中路径。

---

## URL 构成规则

| 作用域 | 模板 | 说明 |
|--------|------|------|
| 指定命名空间 | `/k8s/ns/${ns}/${plural}` | 命名空间范围内的资源 |
| 所有命名空间 | `/k8s/all-namespaces/${plural}` | 跨命名空间查看 |
| 集群范围 | `/k8s/cluster/${plural}` | 集群级别资源（Node、CRD、Project 等） |
| 创建资源 | `/k8s/ns/${ns}/${plural}/~new` | 通用创建 |
| **资源详情 ← 创建/更新后回传** | **`/k8s/ns/${ns}/${plural}/${name}`** | **Agent 创建/更新资源后必须回传此 URL** |
| 表单创建 | `/k8s/ns/${ns}/${plural}/~new/form` | 表单方式创建 |
| 表单编辑 | `/k8s/ns/${ns}/${plural}/${name}/form` | 表单方式编辑 |
| YAML 编辑 | `/k8s/ns/${ns}/${plural}/${name}/edit-yaml` | YAML 方式编辑 |

---

## 一、基础资源列表 (`plural` → 页面)

`/k8s/${scope}/${plural}` 中 `:plural` 解析到模型并查找对应列表页：

| 资源 (kind) | plural | 列表页组件 |
|------------|--------|-----------|
| ConfigMap | `configmaps` | ConfigMapsPage |
| DaemonSet | `daemonsets` | DaemonSetsPage |
| Deployment | `deployments` | DeploymentsPage |
| DeploymentConfig | `deploymentconfigs` | DeploymentConfigsPage |
| Build | `builds` | BuildsPage |
| BuildConfig | `buildconfigs` | BuildConfigsPage |
| ImageStream | `imagestreams` | ImageStreamsPage |
| Job | `jobs` | JobsPage |
| CronJob | `cronjobs` | CronJobsPage |
| Project | `projects` | ProjectsPage |
| Namespace | `namespaces` | NamespacesPage |
| Node | `nodes` | NodesPage |
| Pod | `pods` | PodsPage |
| ReplicaSet | `replicasets` | ReplicaSetsPage |
| ReplicationController | `replicationcontrollers` | ReplicationControllersPage |
| Secret | `secrets` | SecretsPage |
| ServiceAccount | `serviceaccounts` | ServiceAccountsPage |
| Service | `services` | ServicesPage |
| Role | `roles` | RolesPage |
| RoleBinding | `rolebindings` | RoleBindingsPage |
| User | `users` | UserPage |
| Group | `groups` | GroupPage |
| Prometheus | `prometheuses` | PrometheusInstancesPage |
| ServiceMonitor | `servicemonitors` | ServiceMonitorsPage |
| Alertmanager | `alertmanagers` | AlertManagersPage |
| StatefulSet | `statefulsets` | StatefulSetsPage |
| ResourceQuota | `resourcequotas` | ResourceQuotasPage |
| LimitRange | `limitranges` | LimitRangeListPage |
| HorizontalPodAutoscaler | `horizontalpodautoscalers` | HorizontalPodAutoscalersPage |
| PersistentVolume | `persistentvolumes` | PersistentVolumesPage |
| PersistentVolumeClaim | `persistentvolumeclaims` | PersistentVolumeClaimsPage |
| StorageClass | `storageclasses` | StorageClassPage |
| CustomResourceDefinition | `customresourcedefinitions` | CustomResourceDefinitionsPage |
| PodDisruptionBudget | `poddisruptionbudgets` | PodDisruptionBudgetsPage |
| VolumeSnapshot | `volumesnapshots` | VolumeSnapshotPage |
| VolumeSnapshotClass | `volumesnapshotclasses` | VolumeSnapshotClassPage |
| Ingress | `ingresses` | IngressesPage |
| AppProject | `appprojects` | AppProjectPage |
| AppEnv | `appenvs` | AppEnvPage |

---

## 二、KDO/PAC/Tekton API 资源 → URL plural

这些 CRD 使用 API 组限定格式: `<apiGroup>~<version>~<kind>`：

| CRD | plural | 示例路径 |
|-----|--------|---------|
| `Repository` | `pipelinesascode.tekton.dev~v1alpha1~Repository` | `/k8s/ns/${ns}/pipelinesascode.tekton.dev~v1alpha1~Repository` |
| `Pipeline` | `tekton.dev~v1~Pipeline` | `/k8s/ns/${ns}/tekton.dev~v1~Pipeline` |
| `PipelineRun` | `tekton.dev~v1~PipelineRun` | `/k8s/ns/${ns}/tekton.dev~v1~PipelineRun` |
| `Task` | `tekton.dev~v1~Task` | `/k8s/ns/${ns}/tekton.dev~v1~Task` |
| `TaskRun` | `tekton.dev~v1~TaskRun` | `/k8s/ns/${ns}/tekton.dev~v1~TaskRun` |
| `ClusterTriggerBinding` | `triggers.tekton.dev~v1beta1~ClusterTriggerBinding` | `/k8s/cluster/triggers.tekton.dev~v1beta1~ClusterTriggerBinding` |

---

## 三、重定向路由

| 访问路径 | 目标 |
|---------|------|
| `/all-namespaces/*` | → `/k8s/all-namespaces/*` |
| `/ns/:ns/*` | → `/k8s/ns/:ns/*` |
| `/cluster-status` | → `/dashboards` |
| `/status/all-namespaces` | → `/dashboards` |
| `/status/ns/:ns` | → `/k8s/cluster/projects/:ns` |
| `/overview/all-namespaces` | → `/dashboards` |
| `/overview/ns/:ns` | → `/k8s/cluster/projects/:ns/workloads` |
| `/operatorhub` | → NamespaceRedirect |

---

## 四、插件路由

### pipelines-plugin（13 条）

| 路径 | 功能 |
|------|------|
| `/pipelines-overview/ns/:ns` | 流水线总览 |
| `/tasks/ns/:ns` | Task 列表 |
| `/pac/ns/:ns` | PAC Repository 列表 |
| `/dev-pipelines/ns/:ns` | 开发流水线视图 |
| `/triggers/ns/:ns` | Trigger 列表 |
| `/pipelines/ns/:ns` | Pipeline 列表 |
| `/k8s/ns/:ns/tekton.dev~v1~PipelineRun/:plrName/logs/:taskName` | PipelineRun 日志 |
| `/k8s/ns/:ns/tekton.dev~v1~Pipeline/~new/builder` | Pipeline 构建器（可视化编排） |
| `/k8s/ns/:ns/tekton.dev~v1~Pipeline/:pipelineName/builder` | Pipeline 构建器（编辑） |
| `/k8s/ns/:ns/tekton.dev~v1~PipelineRun/~new/builder` | PipelineRun 构建器 |
| `/k8s/ns/:ns/tekton.dev~v1~PipelineRun/:pipelineRunName/builder` | PipelineRun 构建器（编辑） |
| `/k8s/ns/:ns/pipelinesascode.tekton.dev~v1alpha1~Repository/~new/form` | 创建 Repository（Git 应用） |
| `/k8s/ns/:ns/pipelinesascode.tekton.dev~v1alpha1~Repository/:name/form` | 编辑 Repository |

### monitoring-plugin（28 条）

| 路径 | 功能 |
|------|------|
| `/monitoring` | 告警列表 |
| `/monitoring/silences/~new` | 创建静默 |
| `/monitoring/silences/:id` | 静默详情 |
| `/monitoring/targets` | 监控目标 |
| `/monitoring/query-browser` | PromQL 查询 |
| `/monitoring/dashboards` | 仪表盘列表 |
| `/monitoring/alertrules/:id` | 告警规则详情 |
| `/monitoring/alerts/:ruleID` | 告警详情 |
| `/dev-monitoring/ns/:ns/alerts/:ruleID` | 开发视角告警重定向 |
| `/dev-monitoring/ns/:ns/rules/:id` | 开发视角规则重定向 |
| `/dev-monitoring/ns/:ns/silences/:id` | 开发视角静默重定向 |
| `/dev-monitoring/ns/:ns/metrics` | 开发视角指标 |
| `/k8s/ns/:ns/:plural/:name/edit` | 告警规则表单编辑 |

### dev-console（28 条）

| 路径 | 功能 |
|------|------|
| `/add/ns/:ns` | 添加页面（从源码/镜像/目录） |
| `/topology/ns/:name` | 拓扑视图 |
| `/builds/ns/:ns` | 构建列表 |
| `/catalog/ns/:ns` | 开发者目录 |
| `/deploy-image/ns/:ns` | 镜像部署 |
| `/import/ns/:ns` | 源码导入 |
| `/helm-releases/ns/:ns` | Helm Release |
| `/dev-monitoring/ns/:ns` | 开发监控 |
| `/project-access/ns/:ns` | 项目访问权限 |
| `/project-roles/ns/:ns` | 项目角色 |
| `/project-details/ns/:ns` | 项目详情 |
| `/appenv-details/ns/:ns` | 环境详情 |
| `/serverless-function/ns/:ns` | 函数列表 |
| `/k8s/ns/:ns/deployments/~new/form` | 创建 Deployment |
| `/k8s/ns/:ns/statefulsets/~new/form` | 创建 StatefulSet |
| `/k8s/ns/:ns/buildconfigs/~new/form` | 创建 BuildConfig |
| `/k8s/ns/:ns/:kind/:name/containers/:containerName/health-checks` | 健康检查配置 |
| `/workload-hpa/ns/:ns/:resourceRef/:name` | HPA 配置 |

### helm-plugin（8 条）

| 路径 | 功能 |
|------|------|
| `/helm/ns/:ns` | Helm Release 列表 |
| `/catalog/helm-install` | 安装 Helm Chart |
| `/helm-releases/ns/:ns/:releaseName/upgrade` | 升级 Helm Release |
| `/helm-releases/ns/:ns/:releaseName/rollback` | 回滚 Helm Release |
| `/helm-releases/ns/:ns/release/:name` | Helm Release 详情 |
| `/helm-repositories/ns/:ns/~new/form` | 创建 Helm 仓库 |
| `/helm-repositories/ns/:ns/:name/form` | 编辑 Helm 仓库 |
| `/helm/ns/:ns/url-chart` | 通过 URL 安装 Chart |

### knative-plugin（15 条）

| 路径 | 功能 |
|------|------|
| `/serving/ns/:ns` | Knative Service 列表 |
| `/eventing/ns/:ns` | Knative Eventing 列表 |
| `/functions/ns/:ns` | 函数列表 |
| `/functions/ns/:ns/:name` | 函数详情 |
| `/catalog/ns/:ns/eventsource` | 事件源目录 |
| `/catalog/ns/:ns/eventsink` | 事件接收器 |
| `/channel/ns/:ns` | Channel 列表 |
| `/broker/ns/:ns` | Broker 列表 |
| `/knatify/ns/:ns` | 创建 Knative 服务 |

### operator-lifecycle-manager（7 条）

| 路径 | 功能 |
|------|------|
| `/k8s/ns/:ns/operators.coreos.com~v1alpha1~ClusterServiceVersion/:csvName/:plural/~new` | 创建 Operand |
| `/k8s/ns/:ns/operators.coreos.com~v1alpha1~ClusterServiceVersion/:appName/:plural/:name` | Operand 详情 |
| `/k8s/ns/:ns/operators.coreos.com~v1alpha1~Subscription/~new` | 创建 Subscription |
| `/operatorhub/subscribe` | OperatorHub 订阅 |
| `/k8s/cluster/operators.coreos.com~v1alpha1~CatalogSource/~new` | 创建 CatalogSource |
| `/operatorhub` | OperatorHub 入口 |

### 其他插件

| 插件 | 路径 | 功能 |
|------|------|------|
| console-app | `/quickstart/` | 快速开始目录 |
| console-app | `/user-preferences` | 用户偏好设置 |
| console-app | `/cluster-configuration` | 集群配置 |
| logging-view-plugin | `/monitoring/logs` | 日志查看 |
| shipwright-plugin | `/k8s/ns/:ns/shipwright.io` | Shipwright 构建列表 |
| shipwright-plugin | `/k8s/ns/:ns/shipwright.io~v1beta1~Build/~new/form` | 创建 Build |
| metal3-plugin | `/k8s/ns/:ns/metal3.io~v1alpha1~BareMetalHost/~new/form` | 注册裸金属主机 |

---

## 五、独立页面（无主布局）

| 路径 | 功能 |
|------|------|
| `/terminal` | CloudShell 命令行终端 |

---

## 六、自定义表单页面

| 路径 | 功能 |
|------|------|
| `/k8s/ns/:ns/services/~new/form` | 创建 Service |
| `/k8s/ns/:ns/resourcequotas/~new/form` | 创建 ResourceQuota |
| `/k8s/ns/:ns/limitranges/~new/form` | 创建 LimitRange |
| `/k8s/ns/:ns/cronjobs/~new/form` | 创建 CronJob |
| `/k8s/ns/:ns/ingresses/~new/form` | 创建 Ingress |
| `/k8s/ns/:ns/secrets/~new/:type` | 创建 Secret |
| `/k8s/ns/:ns/secrets/:name/edit` | 编辑 Secret |
| `/k8s/ns/:ns/configmaps/~new/form` | 创建 ConfigMap |
| `/k8s/ns/:ns/persistentvolumeclaims/~new/form` | 创建 PVC |
| `/k8s/ns/:ns/:plural/:name/attach-storage` | 挂载存储 |
| `/k8s/cluster/rolebindings/~new` | 创建集群 RoleBinding |
| `/k8s/ns/:ns/rolebindings/~new` | 创建命名空间 RoleBinding |
| `/k8s/ns/:ns/rolebindings/:name/edit` | 编辑 RoleBinding |
| `/k8s/cluster/clusterrolebindings/:name/edit` | 编辑 ClusterRoleBinding |

---

## 七、Agent URL 拼接规则

```bash
# 获取基础地址
CONSOLE_BASE=$(kubectl get cm -n kubedo-system console -o json | \
  jq -r '.data["config.yaml"]' | grep consoleBaseAddress | awk '{print $2}')
if [ -z "$CONSOLE_BASE" ]; then
  CONSOLE_HOST=$(kubectl get ingress -n kubedo-system console -o jsonpath='{.spec.rules[0].host}')
  CONSOLE_BASE="http://${CONSOLE_HOST}"
fi

# 拼接完整 URL
echo "${CONSOLE_BASE}/k8s/ns/kdo/pipelinesascode.tekton.dev~v1alpha1~Repository"
echo "${CONSOLE_BASE}/k8s/ns/my-project/tekton.dev~v1~PipelineRun"
echo "${CONSOLE_BASE}/pac/ns/my-project"
echo "${CONSOLE_BASE}/dashboards"
```

> **规则**: 当需要引导用户前往 Console 页面时，必须拼接 `${CONSOLE_BASE}${path}` 完整 URL。

---

## 相关页面

- [[kdo-console]]
- [[kdo-repository-pac]]
- [[kdo-pipelines]]
- [[kdo-console-usage]]

---

_Last updated: 2026-07-27_
