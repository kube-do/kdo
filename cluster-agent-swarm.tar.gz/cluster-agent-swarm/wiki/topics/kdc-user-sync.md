---
title: KDC 用户身份同步
tags: [kdc, user, group, keycloak, dex, sync]
---

# KDC 用户身份同步

KDC 通过 **ClusterController**（定时 5 分钟）、**UserController** 和 **GroupController** 实现用户/组在 Kubernetes CRD 和 OIDC Provider 之间的双向同步。

---

## Provider 抽象

```go
type Provider interface {
    Name() string
    Initialize(ctx, ctrlClient)
    ListUsers(ctx) → []UserDTO
    ListGroups(ctx) → []GroupDTO
    CreateUser(ctx, user) → userID
    UpdateUser(ctx, userID, user)
    DeleteUser(ctx, userID)
    SetPassword(ctx, userID, password) → resolvedUserID
    CreateGroup(ctx, group) → groupID
    UpdateGroup(ctx, groupID, group)
    DeleteGroup(ctx, groupID)
}
```

两种实现：**KeycloakProvider**（主）和 **DexProvider**（密码用户备选）。

---

## Keycloak Provider

| 特性 | 说明 |
|------|------|
| 库 | `gocloak` (Keycloak Admin REST API) |
| 用户属性 | phone、wechatWorkId、dingtalkId、feishuId |
| 用户名 | 取 email 中 `@` 之前的部分 |
| 组名 | DNS 子域名合规化（非法字符 → `-`，小写化） |
| 同步方向 | 双向（KDC ↔ Keycloak） |

---

## Dex Provider

| 特性 | 说明 |
|------|------|
| 协议 | gRPC API (`ListPasswords`) |
| 前提 | `enablePasswordDB: true` |
| 传输 | 支持 TLS/mTLS |
| 组同步 | 跳过（Dex 无组管理 API） |

---

## 用户同步流程（Provider → KDC）

```
定时调度 (5 分钟)
    │
    ├─→ 1. ClusterController.Reconcile()
    │       └─→ user.SyncUsersFromOidcProvider()
    │
    ├─→ 2. 列出 Provider 所有用户
    │
    ├─→ 3. KDC 存在但 Provider 已无 → 删除 User CRD
    │       └─→ 清理在所有 AppProject 成员角色中的引用（含 View）
    │
    ├─→ 4. Provider 存在但 KDC 中无 → 创建 User CRD
    │       └─→ 添加 annotation: kube-do.cn/sync-source=keycloak
    │
    └─→ 5. 两者都存在 → 更新 User CRD 字段
            （Email/FullName/Phone/Enabled/Identities/IM IDs）
```

## 组同步流程（Provider → KDC）

与用户同步对称：
1. 列出 Provider 所有组
2. 删除不存在组
3. 创建新组（组名 sanitize 后）
4. 更新已有组

---

## User/Group Controller 双向同步

当 KDC Console 管理员在 KDO UI 上创建/修改/删除用户或组时：

```
管理员操作 User/Group CRD
    │
    ├─→ User/Group Controller 检测变更
    │   ├── sha256 hash 检测 spec 是否变化
    │   └── 若无变化 → 跳过
    │
    ├─→ 创建/更新 → Provider.CreateUser() / Provider.UpdateUser()
    ├─→ 删除 → finalizer 确保 Provider 端先清理
    │
    └─→ 密码变更 → 读取 kubedo-system/user-passwords Secret
                    → sha256 检测 → Provider.SetPassword()
```

### Finalizer 清理

- Finalizer 名称: `kube-do.cn/user-cleanup` / `kube-do.cn/group-cleanup`
- 删除流程: 添加 finalizer → 删除 Provider 端用户/组 → 删除 CRD

---

## 用户变更级联

当用户从 Provider 删除时，ClusterController 同步后会连带清理：
- 该用户在 **所有 AppProject** 成员列表中的引用
- 该用户在 **View 角色** 中的引用
- 相关的 RoleBinding 会被 Controller 重新调和更新

---

## 相关页面

- [[kdc-controller]]
- [[kdo-rbac-auth]]
- [[kdo-platform-project-management]]

---

_Last updated: 2026-07-17_
