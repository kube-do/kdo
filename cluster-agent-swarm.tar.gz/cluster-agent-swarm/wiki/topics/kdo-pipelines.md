---
title: KDO CI/CD 流水线
tags: [kdo, pipelines, tekton, pac, ci-cd]
---

# KDO CI/CD 流水线

KDO 的 CI/CD 基于 **Tekton Pipelines** + **Pipelines as Code (PAC)** 框架，流水线定义存储在 Git 仓库中。

---

## Tekton 核心资源

| CRD | 说明 |
|-----|------|
| **Task** | 基本工作单元（单个步骤集合） |
| **ClusterTask** | 集群级别的 Task（当前集群未安装；Task 存储在 `kubedo` 命名空间，通过 `resolver: cluster` 引用） |
| **TaskRun** | Task 的执行实例 |
| **Pipeline** | 多 Task 的执行流程 |
| **PipelineRun** | Pipeline 的执行实例 |
| **Condition** | 条件检查 |
| **Trigger** | 自动触发 (EventListener + TriggerTemplate) |
| **Params** | 参数化配置 |
| **Workspaces** | 共享存储 |

---

## Pipeline 类型

| 类型 | 说明 | 适用场景 |
|------|------|----------|
| **标准流水线** | 完整 Pipeline CR，参数和工作区需手动输入 | 复杂自定义流程 |
| **嵌入流水线** | PipelineRun CR + 模板参数，应用信息自动注入 | 快速创建 |

---

## Pipelines as Code 架构

```
Git Push/PR → Webhook → PAC Controller → 解析定义 → 创建 PipelineRun → 执行 → 结果反馈
└─Git Provider─────────────────────┘

┌─ 三大组件:
│  ├── Controller: 事件接收 + 创建 PipelineRun
│  ├── Watcher: 状态监视 + 报告反馈
│  └── Webhook: 准入验证
│
└─ CLI (tkn-pac): bootstrap / create / list / describe / logs / generate
```

### Repository CR — 核心自定义资源

Repository CR 将 Git 仓库与命名空间关联:

```yaml
apiVersion: pipelinesascode.tekton.dev/v1alpha1
kind: Repository
metadata:
  name: my-repo
  namespace: my-namespace
spec:
  url: https://github.com/org/my-repo
  branch: main
  git_provider:
    type: github
    secret:
      name: github-token
  concurrency_limit: 3
```

属性: URL 匹配、并发限制、自定义参数、CEL 过滤、pipelinerun_provenance

---

## 6 种 Git 提供商集成

| 提供商 | 集成方式 | 特性 |
|--------|---------|------|
| **GitHub App** | 应用安装 | 功能最完整: Checks API、ChatOps、自动配置 |
| **GitHub Webhook** | Webhook | 功能有限，不支持 Check Runs API |
| **GitLab** | Webhook | 支持 Merge Request 事件 |
| **Bitbucket Cloud** | Webhook | — |
| **Bitbucket Data Center** | Webhook | — |
| **Gitea** | Webhook | — |

---

## 事件匹配体系

通过 PipelineRun 注解控制触发条件:

| 注解 | 说明 |
|------|------|
| `on-event` | 事件类型 (push / pull_request) |
| `on-target-branch` | 目标分支 (`[main, release/*]`) |
| `on-comment` | 评论匹配 (`/retest`) |
| `on-cel-expression` | CEL 表达式高级匹配 |
| `on-path-change` | 文件路径过滤 |
| `on-label` | PR 标签匹配 |
| `cancel-in-progress` | 自动取消进行中的运行 |

### CEL 表达式示例

```yaml
annotations:
  pipelinesascode.tekton.dev/on-cel-expression: |
    event_type == "pull_request" && target_branch == "main" &&
    files.all(f, !f.startsWith("docs/"))
```

---

## 动态变量

PAC 提供 12+ 动态变量用于 PipelineRun:

| 变量 | 说明 |
|------|------|
| `{{ repo_url }}` | 仓库 URL |
| `{{ revision }}` | Git 修订版本 |
| `{{ source_branch }}` | 源分支 |
| `{{ target_branch }}` | 目标分支 |
| `{{ pull_request_number }}` | PR 编号 |
| `{{ git_auth_secret }}` | Git 认证 Secret 名称 |

---

## KDO 应用流水线自动生成

创建 Git 仓库应用时，KDO 自动创建:

| 文件 | 说明 |
|------|------|
| `devfile.yaml` | 应用定义 |
| `.tekton/` | 流水线定义 (命名: `应用名-环境-分支.yaml`) |
| `docker/Dockerfile` | 镜像配置 |
| `kubernetes/` | 部署配置 (Deployment/StatefulSet/Service) |

---

## 安全机制

- **Webhook 签名验证**: 验证 Git 事件的真实性
- **Secret 保护**: 日志自动脱敏
- **OWNERS 文件 ACL**: PR 触发权限控制
- **认证链**: Webhook 签名 → Git Token → 认证客户端
- **授权链**: Policy 检查 (OkToTest) → OWNERS 文件回退

---

## Console 流水线 UI

详细页面参考 [[kdo-console-usage]]、[[kdo-pipeline-builder]]、[[kdo-repository-pac]]。

### PipelineRun DAG 可视化

Console 的 PipelineRun 详情页提供实时 DAG 可视化：

- **PipelineRunVisualization**：基于 `@patternfly/react-topology` + dagre 布局（LR 方向）
- **状态着色**：通过 `appendPipelineRunStatus` 将 TaskRun 状态合并到 Pipeline 任务
- **节点类型**：`TASK_NODE`（普通）/ `CUSTOM_TASK_NODE`（自定义）/ `APPROVAL_TASK_NODE`（审批）
- **日志查看**：`MultiStreamLogs` 多流日志查看器，支持 ANSI 颜色
- **状态确定**：`pipelineRunFilterReducer` 处理所有状态（Succeeded/Failed/Running/Cancelled/Pending/Skipped 等）
- **条件标签页**：TaskRuns / ApprovalTasks / Output（按条件显示）

### ApprovalTask 审批系统

KDO 特有 CRD `openshift-pipelines.org/v1alpha1`：

| 组件 | 功能 |
|------|------|
| `ApprovalTasksListPage` | 审批任务列表 |
| `ApprovalTaskActionDropdown` | Approve/Reject 操作 |
| `Approval` 模态框 | 审批/拒绝确认对话框 |
| `PipelineApprovalContext` | Toast 通知上下文 |
| `ApprovalTaskNode` | DAG 中审批节点渲染 |

### Triggers 管理 UI

Console 提供完整的 Tekton Triggers CRD 管理：

| 页面 | CRD |
|------|-----|
| EventListenersListPage | `triggers.tekton.dev/v1beta1/EventListener` |
| TriggerBindingsListPage | `triggers.tekton.dev/v1beta1/TriggerBinding` |
| TriggerTemplatesListPage | `triggers.tekton.dev/v1beta1/TriggerTemplate` |
| ClusterTriggerBindingsListPage | `triggers.tekton.dev/v1beta1/ClusterTriggerBinding` |

### KDO 特有改动

| 改动 | 说明 |
|------|------|
| `PIPELINERUN_TEMPLATE_NAMESPACE = 'kubedo'` | PipelineRun 模板存储在 `kubedo` 命名空间 |
| feature flag 强制启用 | `useFlagHookProvider` 无条件启用所有 `HIDE_STATIC_*` 标志 |
| ApprovalTask | 完整的审批任务 CRD 支持 |
| CustomRun | `tekton.dev/v1beta1/CustomRun` 支持 |
| Kueue 多集群 | `PIPELINE_RUN_MANAGED_BY_KUEUE_LABEL` 标签支持 |
| 中文翻译 | `locales/zh/pipelines-plugin.json` 完整翻译 |

---

## 相关页面

- [[kdo-pipeline-builder]]
- [[kdo-repository-pac]]
- [[kdo-console]]
- [[kdo-applications]]
- [[kdo-platform-project-management]]
- [[kdo-architecture]]

---

_Last updated: 2026-07-17_
