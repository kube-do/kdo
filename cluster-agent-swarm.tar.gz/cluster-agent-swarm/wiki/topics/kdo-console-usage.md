---
title: KDO 控制台使用指南
tags: [kdo, console, usage, navigation]
---

# KDO 控制台使用指南

---

## 导航布局

```
┌──────────────────────────────────────────────────┐
│ Masthead（顶部栏）：Logo / 项目选择 / 搜索 / 用户菜单  │
├──────────┬───────────────────────────────────────┤
│ Sidebar  │  AppContents（页面内容区）                │
│（导航侧栏）│                                         │
│          │                                         │
│ Home     │                                         │
│ 工作负载  │                                         │
│ 网络     │                                         │
│ 存储     │                                         │
│ 监控     │                                         │
│ 搜索     │                                         │
│ API Explorer│                                       │
│ Pipelines│                                         │
│ Helm     │                                         │
│ OperatorHub│                                       │
│ 用户管理  │                                         │
├──────────┴───────────────────────────────────────┤
│ NotificationDrawer（通知抽屉，右侧滑出）              │
└──────────────────────────────────────────────────┘
```

### Masthead

- Logo + 平台名称（KDO）
- 项目/命名空间切换（下拉选择）
- 全局搜索（快速查找资源）
- 用户菜单（登录信息 / 复制登录命令 / 修改密码 / 退出）
- 告警图标（未读告警数量）

### Sidebar

两级导航结构：
- **一级分类**：工作负载、网络、存储、监控等
- **二级页面**：各类资源列表

支持两种视角（Perspectives）：
- **Admin 视角**：完整平台管理功能（默认）
- **Developer 视角**：精简的开发者体验，聚焦应用

---

## 页面清单

### 核心页面

| 页面 | 路径 | 功能 |
|------|------|------|
| **Dashboard** | `/dashboards` | 集群概览：节点状态、资源用量、告警 |
| **搜索** | `/search` | 跨命名空间/跨类型全文搜索 |
| **API Explorer** | `/api-explorer` | 浏览所有 K8s API 资源和操作 |
| **命令行工具** | `/command-line-tools` | 下载 kubectl/oc CLI 二进制文件 |
| **快速创建** | `/catalog` | 从模板/目录创建资源 |

### 工作负载

| 页面 | 功能 |
|------|------|
| Pods | Pod 列表、详情、日志、终端、YAML |
| Deployments | 部署管理、扩缩容、回滚 |
| StatefulSets | 有状态应用管理 |
| DaemonSets | 节点守护进程管理 |
| CronJobs | 定时任务管理 |
| HPAs | 自动伸缩策略 |

### 网络

| 页面 | 功能 |
|------|------|
| Services | 服务列表、详情、YAML |
| Routes | OpenShift Route（入口）管理 |
| Ingresses | K8s Ingress 管理 |
| NetworkPolicies | 网络策略管理 |

### 存储

| 页面 | 功能 |
|------|------|
| PersistentVolumeClaims | PVC 管理、扩缩容 |
| PersistentVolumes | PV 查看 |
| StorageClasses | 存储类查看 |

### 监控

| 页面 | 功能 |
|------|------|
| 指标仪表盘 | Prometheus/Thanos 预定义仪表盘 |
| 告警 | Alertmanager 告警管理、静默规则 |
| 日志 | Loki/Elasticsearch 日志查看（KDO 扩展） |

### Pipelines

参考 [[kdo-pipelines]]、[[kdo-pipeline-builder]]、[[kdo-repository-pac]]。

### 其他

| 页面 | 功能 |
|------|------|
| Helm | Chart 仓库管理、Release 安装/升级/回滚 |
| OperatorHub | OLM 操作目录、安装/管理 Operator |
| 拓扑 | 应用拓扑可视化（Knative + K8s 资源） |
| 用户管理 | KDO 用户 CRUD（管理员功能） |
| AI 助手 | Lightspeed AI 对话窗口（右下角） |
| Web 终端 | 浏览器内终端（CloudShell） |

---

## 常见操作

### 快速创建资源

1. 点击右上角 "+" 按钮
2. 选择资源类型（Pod、Deployment、Service 等）
3. 选择创建方式：表单 / YAML 编辑器
4. 填写配置并提交

### 查看 Pod 日志

1. 导航到 "工作负载 → Pods"
2. 点击目标 Pod
3. 切换到 "日志" 选项卡
4. 可选择容器（多容器 Pod）和日志时间范围

### 进入容器终端

1. Pod 详情页 → "终端" 选项卡
2. 选择容器
3. 自动启动 WebSocket 终端会话

### 修改密码

1. 点击右上角用户头像
2. 选择 "修改密码"
3. 输入旧密码 + 新密码

---

## 相关页面

- [[kdo-console]]
- [[kdo-pipelines]]
- [[kdo-terminal]]
- [[kdo-aiops]]
- [[kdo-observability]]

---

_Last updated: 2026-07-17_
