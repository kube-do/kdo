---
title: KDO Pipeline 可视化构建器
tags: [kdo, pipelines, builder, dag, tekton]
---

# KDO Pipeline 可视化构建器

Console pipelines-plugin 提供的可视化 DAG 编辑器，让用户通过拖拽/点击的交互方式创建 Tekton Pipeline，支持表单和 YAML 双向同步。

---

## 架构

```
PipelineBuilderPage（Formik 包装）
  └── PipelineBuilderForm（SyncedEditor：表单↔YAML 切换）
       ├── PipelineBuilderFormEditor（表单视图）
       │    ├── PipelineBuilderVisualization（交互式 DAG）
       │    ├── PipelineParameters（参数区）
       │    └── PipelineWorkspaces（工作区）
       ├── CodeEditorField（Monaco YAML 编辑器）
       └── TaskSidebar（抽屉：编辑任务属性）
            ├── 参数（params）
            ├── 资源（resources）
            ├── 工作区（workspaces）
            └── When 表达式（when）
```

### 表单状态类型

```typescript
PipelineBuilderFormValues = {
  name: string;
  params: TektonParam[];
  tasks: PipelineTask[];                  / 常规任务
  listTasks: PipelineBuilderListTask[];   / 占位列表节点
  loadingTasks: PipelineBuilderLoadingTask[]; / 安装中的任务
  finallyTasks: PipelineTask[];           / Finally 任务
  finallyListTasks: PipelineBuilderListTask[];
  workspaces: TektonWorkspace[];
  when?: WhenExpression[];
}
```

---

## DAG 节点类型

| 节点类型 | 常量名 | 说明 |
|----------|--------|------|
| `TASK_NODE` | 查看器 | 只读 DAG 中的任务节点 |
| `BUILDER_NODE` | 构建器 | 可编辑任务节点（带添加前/后/并行装饰器） |
| `TASK_LIST_NODE` | 占位列表 | 占位符，点击后从 Task 目录选择 |
| `LOADING_NODE` | 安装中 | 正在从目录安装的任务 |
| `INVALID_TASK_LIST_NODE` | 无效 | 引用了不存在的 Task 资源 |
| `FINALLY_NODE` / `FINALLY_GROUP` | Finally | 最终任务区 |
| `CUSTOM_TASK_NODE` | 自定义 | 非 Task 类型的自定义任务 |
| `APPROVAL_TASK_NODE` | 审批 | ApprovalTask 节点 |

---

## 布局引擎

基于 **dagre**（通过 `@patternfly/react-topology` PipelineDagreLayout）：
- 布局方向：`LR`（从左到右）
- 等级算法：`longest-path`
- 4 种布局变体：

| 变体 | 用途 |
|------|------|
| `dagre-viewer` | 只读 DAG 查看 |
| `dagre-viewer-spaced` | 查看 + When 表达式指示器间距 |
| `dagre-builder` | 交互式构建 |
| `dagre-builder-spaced` | 构建 + When 表达式间距 |

---

## 交互模型

### 添加任务

1. 点击已有任务节点的 "+" 装饰器
2. 选择添加位置：
   - **Before**：在当前任务前执行（设置 `runAfter`）
   - **After**：在当前任务后执行
   - **Parallel**：与当前任务并行
3. 创建 `TASK_LIST_NODE` 占位符（带正确的 `runAfter` 关系）
4. 点击占位符 → 打开 `PipelineQuickSearch` 目录
5. 从目录选择 Task → 转换为 `BUILDER_NODE`

### 删除/重命名任务

- 删除：右键菜单 → Remove Task，级联清理依赖关系
- 重命名：任务节点内直接编辑名称

### 任务属性编辑

点击 `BUILDER_NODE` → 右侧滑出 `TaskSidebar` 抽屉：

| 编辑项 | 功能 |
|--------|------|
| 参数（Params） | 添加/编辑/删除 Task 参数值 |
| 资源（Resources） | 配置 Task 输入/输出资源 |
| 工作区（Workspaces） | 配置 Task 工作区挂载 |
| When 表达式 | 配置 When 条件（`(input == '') || (input == '')`） |

### Finally 任务

支持添加 Finally 任务区（`finallyTasks`），在常规任务完成后执行。

---

## 表单 ↔ YAML 双向同步

`SyncedEditorField` 组件实现：

```
YAML 编辑器（Monaco） ── sanitizeToForm ──→ 表单视图
表单视图（Formik）    ── sanitizeToYaml ──→ YAML 编辑器
```

| 转换函数 | 方向 | 功能 |
|----------|------|------|
| `convertBuilderFormToPipeline` | 表单→Pipeline CRD | Formik 状态 → K8s Pipeline 对象 |
| `convertPipelineToBuilderForm` | Pipeline CRD→表单 | K8s Pipeline 对象 → Formik 状态 |
| `applyChange` | 图操作 | DAG 增删改操作应用到任务列表 |

切换时自动执行校验（Yup validation schema），确保两边数据一致。

---

## Task 目录搜索

`PipelineQuickSearch` 组件提供一个搜索覆盖层：

- 从 Tekton Hub / Artifact Hub / 集群已有 Task 数据源获取（平台预置 Task 存于 `kubedo` 命名空间）
- 支持搜索过滤
- 选择后自动安装到集群（Create Task CRD）
- 安装期间节点显示为 `LOADING_NODE`
- 安装失败自动回退（`useCleanupOnFailure`）

---

## 数据加载钩子

| 钩子 | 功能 |
|------|------|
| `useFormikFetchAndSaveTasks` | 监听集群 Task CRD 并填充 Formik 状态 |
| `useNodes` | 将任务列表转换为拓扑图节点 |
| `useExplicitPipelineTaskTouch` | 父工作区/资源变化时自动标记子任务 |
| `useLoadingTaskCleanup` | 加载中任务自动转换为真实任务 |
| `useCleanupOnFailure` | 处理任务安装失败 |

---

## 相关页面

- [[kdo-pipelines]]
- [[kdo-repository-pac]]
- [[kdo-console]]
- [[kdo-applications]]

---

_Last updated: 2026-07-17_
