---
title: KDC 镜像流系统
tags: [kdc, imagestream, image, skopeo, deployment]
---

# KDC 镜像流系统

KDC 的镜像流系统兼容 **OpenShift ImageStream API**，提供镜像导入、仓库同步和自动部署触发能力。通过 **ImageStreamController** 实现声明式镜像管理。

---

## ImageStream CRD

```yaml
apiVersion: kube-do.cn/v1
kind: ImageStream
metadata:
  name: my-app
  namespace: my-project-dev
spec:
  tags:
    - name: latest
      from:
        kind: DockerImage
        name: registry.example.com/my-app:v1.0.0
      importPolicy:
        scheduled: true
        importMode: Legacy
      referencePolicy:
        type: Source
    - name: stable
      from:
        kind: ImageStreamTag
        name: my-other-is:stable
    - name: ref-only
      from:
        kind: DockerImage
        name: registry.example.com/my-app:ref
      reference: true  # 仅记录地址，不导入
```

---

## 3 种 Tag 导入模式

| from.kind | 说明 | 导入方式 |
|-----------|------|----------|
| **DockerImage** | 外部镜像地址 | Harbor API / HEAD + Skopeo Job |
| **ImageStreamTag** | 同 Namespace 的 IST CRD | 直接读取 CRD 数据 |
| **ImageStreamImage** | 同 Namespace 的 ISI CRD | 通过 digest 获取 |
| **Reference** | 仅记录引用地址 | `reference: true`，不导入 |

---

## 导入流程

```
ImageStream spec.tags 变更
    │
    ├─→ 第一轮：处理 DockerImage（外部镜像）
    │   ├── Harbor 内部 → Harbor API 获取 artifact 元数据
    │   └── 外部 Registry → HEAD 获取 digest + Skopeo Job 同步
    │
    ├─→ 第二轮：处理 IST/ISI（同 IS 内部引用）
    │   ├── ImageStreamTag → 从同 NS 的 IST CRD 读取
    │   └── ImageStreamImage → 从同 NS 的 ISI CRD 读取
    │
    ├─→ 创建 Image CRD（digest 命名，OwnerRef → ImageStream）
    ├─→ 创建/更新 ImageStreamTag CRD
    ├─→ 创建/更新 ImageStreamImage CRD
    ├─→ 更新 ImageStream status（tag 事件历史，最多 20 条）
    │
    └─→ ImageChange 触发：扫描 Deployment
         └─→ 添加 annotation（kdc.kube-do.cn/image-change.{is--tag} = 时间戳）
              └─→ Deployment 控制器检测变更 → 滚动更新
```

---

## 镜像同步机制

### Harbor Replication

```
Harbor 复制策略 (Replication Policy)
    ├─→ 注册外部 Registry 为 Harbor endpoint
    ├─→ 创建 replication policy
    ├─→ 触发手动执行
    └─→ 轮询等待完成
```

### Skopeo Job

当 Harbor Replication 不可用时：

```yaml
# KDC 自动创建的 Kubernetes Job
apiVersion: batch/v1
kind: Job
metadata:
  annotations:
    kdc.kube-do.cn/skopeo-src-ref: "docker:/registry.example.com/my-app:v1.0.0"
spec:
  template:
    spec:
      containers:
        - name: skopeo
          image: registry.cn-shenzhen.aliyuncs.com/kubedo/skopeo:latest
          command:
            - skopeo
            - copy
            - "docker:/registry.example.com/my-app:v1.0.0"
            - "docker:/harbor.kube-do.cn/my-project-dev/my-app:v1.0.0"
          imagePullSecrets:
            - name: registry
      restartPolicy: Never
      ttlSecondsAfterFinished: 3600
```

- 超时限制: 600 秒
- 自动清理: 1 小时后（TTL）
- 源变更检测: annotation `kdc.kube-do.cn/skopeo-src-ref`

---

## Image CRD — 不可变镜像快照

```
Image (cluster-scoped)
    ├── name: sha256:xxxxx                    # digest 名
    ├── dockerImageReference                  # 完整镜像地址
    ├── metadata:
    │   ├── created, size, digest
    │   └── annotations (兼容 OCI 标注)
    ├── dockerImageManifest                   # manifest JSON
    ├── dockerImageLayers:                     # 层列表
    │   └── {name: sha256:xxx, size: xxx, mediaType: xxx}
    └── dockerImageConfig                     # config JSON
```

---

## ImageChange 触发机制

当 ImageStream 的 tag 被更新时，ImageStreamController 自动：

1. 扫描当前 Namespace 下所有 **Deployment**
2. 检查 Deployment 的容器镜像地址是否引用了该 ImageStream 的 tag
3. 匹配成功 → 添加 annotation `kdc.kube-do.cn/image-change.{is--tag}` = 当前时间戳
4. Deployment 控制器检测到 annotation 变更 → 触发 Pod 滚动更新

---

## 相关页面

- [[kdc-controller]]
- [[kdo-applications]]
- [[kdo-platform-project-management]]

---

_Last updated: 2026-07-17_
