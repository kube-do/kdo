---
title: KDO 分支流水线编辑（GitOps）
tags: [kdo, pipelines, tekton, pac, gitops, editing]
---

# KDO 分支流水线编辑（GitOps）

Agent 无 UI，编辑分支流水线的唯一规范路径 = **克隆仓库 → 改 `.tekton/*.yaml` → push → PAC 自动触发**。
与 Console `PipelineRunBuilderPage` 的 `gitService.updateRepositoryFiles()` 行为一致，保证流水线定义可溯源、符合 GitOps 规范。

> ⚠️ 禁止直接 `kubectl apply` 修改/创建 PipelineRun CR 来"编辑"流水线——那会绕过 PAC 的 git 溯源。`kubectl` 仅用于查看状态和触发运行。

---

## 7 步工作流

### ① 定位 Repository

```bash
kubectl get repository <name> -n <ns> -o yaml
```

读取字段：

| 字段 | 用途 |
|------|------|
| `spec.url` | 仓库地址，克隆用 |
| `spec.git_provider.secret.name` | Git Token 所在 Secret |
| `spec.git_provider.type` | 提供商（github/gitlab/gitee/bitbucket） |
| `spec.branchEnvs[]` | 分支→环境映射，含 `branchName/appEnv/cluster/prName/prTemplate/onEvent/manualTrigger` |
| `spec.devInfo.devLanguage` | 开发语言（决定模板与 Task 选择） |

### ② 获取 Git 认证（安全）

```bash
TOKEN=$(kubectl get secret <secret.name> -n <ns> -o jsonpath='{.data.provider\.token}' | base64 -d)
```

> 🚨 **安全规则**：
> - Token **绝不可**回显到输出、写入日志或提交进仓库
> - 在命令中使用环境变量，避免出现在进程参数里（`git clone "https://oauth2:${TOKEN}@..."`）

### ③ 克隆仓库

```bash
git clone "https://oauth2:${TOKEN}@<git-host>/<owner>/<repo>.git"
cd <repo>
git fetch origin --prune && git checkout -b <branch> origin/<branch>
```

> 建议在工作区命名空间用 Che Git 凭据注入（见 [[kdo-terminal]]）代替手工 Token，减少暴露面。

### ④ 定位目标文件

文件命名规则（与前端 `buildPrName` 一致）：

```
.tekton/{appName}-{appEnv}-{sanitize(branchName)}.yaml
```

`sanitize()` 规则（`repositories/utils.ts sanitizeString`）：
小写 → 去首尾空白 → 去非字母数字字符 → 空格/下划线/连字符合并为单个连字符 → 去首尾连字符 → **截断为 9 字符**。

```bash
# 示例：app=my-app, env=dev, branch=develop
# 文件 = .tekton/my-app-dev-develop.yaml
ls .tekton/
```

可直接用 `branchEnvs[].prName` 精确匹配；若不一致，按上述规则推导。

### ⑤ 编辑 PipelineRun YAML

`.tekton/` 下的文件是 `kind: PipelineRun`，支持编辑的内容：

#### 参数（params）

```yaml
spec:
  params:
    - name: image_tag
      value: "20260722-v1.0-abc1234"
    - name: registry
      value: "harbor.kdo.local/kubedo"
```

#### 任务（可选 Task 列表 = `kubedo` 命名空间内的 Task）

> 🎯 **重要**：可选 Task 来自 **`kubedo` 命名空间**。列出方式：
>
> ```bash
> kubectl get tasks -n kubedo
> ```
>
> 引用格式（cluster resolver，**namespace 必须为 `kubedo`**）：

```yaml
spec:
  tasks:
    - name: build
      taskRef:
        resolver: cluster
        params:
          - name: kind
            value: task
          - name: name
            value: <task-name-in-kubedo>
          - name: namespace
            value: kubedo
      runAfter:
        - clone
```

支持 `runAfter` 排序、`when` 表达式、`workspaces` 挂载、`finallyTasks`。

#### Workspaces

```yaml
spec:
  workspaces:
    - name: source
      volumeClaimTemplate:
        spec:
          accessModes: ["ReadWriteOnce"]
          resources:
            requests:
              storage: 1Gi
```

#### PAC 触发注解（metadata.annotations）

| 注解 | 示例 | 说明 |
|------|------|------|
| `pipelinesascode.tekton.dev/on-event` | `[push]` | 触发事件 |
| `pipelinesascode.tekton.dev/on-target-branch` | `[main, release-*]` | 目标分支匹配 |
| `pipelinesascode.tekton.dev/on-cel-expression` | `event_type == "push" && target_branch == "main"` | CEL 高级匹配 |
| `pipelinesascode.tekton.dev/on-path-change` | `[src/**, *.go]` | 文件路径过滤 |
| `pipelinesascode.tekton.dev/max-keep-runs` | `5` | 保留运行数 |

#### 模板变量

PAC 创建运行时替换 `{{ var }}`：`{{ repo_url }}`、`{{ revision }}`、`{{ target_branch }}`、`{{ target_namespace }}`、`{{ image_tag }}`、`{{ git_auth_secret }}` 等。完整表见 [[kdo-pipelines]]。

### ⑥ 校验

```bash
# 1. YAML 语法
python3 -c "import yaml,sys; yaml.safe_load(open('.tekton/xxx.yaml')); print('OK')"

# 2. 结构校验（客户端 dry-run）
kubectl apply --dry-run=client -f .tekton/xxx.yaml

# 3. 可用 Task 引用核对
kubectl get task <task-name> -n kubedo
```

### ⑦ 提交并推送（需审批）

> 🎯 **关键**：commit message **必须**使用 `PacCommitMessage`，否则会再次触发流水线运行：
>
> ```
> Added or updated files for tekton pipeline.
> ```
>
> （与 Console `PipelineRunBuilderPage.tsx` 的 `PacCommitMessage` 常量一致；PAC 识别该消息的提交为工具生成的流水线变更，跳过触发。）

```bash
git add .tekton/xxx.yaml
git commit -m "Added or updated files for tekton pipeline."
git push origin <branch>
```

> **审批要求**：push 前必须经用户确认。若目标环境为生产（prod/stage），需额外执行影响评估。

---

## 新增分支环境

> 为已有 Repository 增加一个新的「分支→环境」映射（BranchEnv），PAC 据此自动生成初始 `.tekton/{prName}.yaml`。
> 与 Console `BranchConfigSection` 行为一致。

### ① 交互式引导：让用户选择三要素

| 要素 | 列出选项 | 命令 |
|------|---------|------|
| **Git 分支** | 克隆后列未配置分支 | `git clone <url> && git branch -r` |
| **部署环境** | 平台已注册环境 | `kubectl get appenv -n <ns> -o name` |
| **流水线模板** | kubedo 中与开发语言匹配的模板 | `kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang> -o name` |

> `prTemplate` 取 kubedo 命名空间中的 ConfigMap 名；`onEvent` 默认 `['push']`；**`manualTrigger` 默认 `true`（手动触发）**。

### ② 构建 BranchEnv 并更新 Repository CR

```bash
# BranchEnv 字段: branchName / appEnv / cluster / prName / prTemplate / onEvent / manualTrigger
# prName = {app}-{env}-{sanitize(branch)}.yaml

kubectl patch repository <name> -n <ns> --type=merge -p \
  '{"spec":{"branchEnvs":[{"branchName":"feature-x","appEnv":"dev","cluster":"dev-cluster","prName":"my-app-dev-feature-x.yaml","prTemplate":"maven-build","onEvent":["push"],"manualTrigger":true}]}}'
```

### ③ 触发初始化（生成模板文件）

```bash
# 取 webhook.secret（不回显）
WS=$(kubectl get secret <secret.name> -n <ns> -o jsonpath='{.data.webhook\.secret}' | base64 -d)

curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?init=yes&cluster=<cluster>&namespace=<ns>&repository=<repo>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

PAC 从 `prTemplate` 模板生成 `.tekton/{prName}.yaml` 并推送到对应分支。

> ⚠️ **会立即触发一次流水线运行**（预期行为）；生产环境（prod/stage）需审批。

### 方式 B：纯 GitOps（init 端点不可达时）

```bash
git clone <url> && git checkout -b <branch> origin/<branch>
# 从模板生成文件：kubectl get cm <prTemplate> -n kubedo -o jsonpath='{.data.template}' > .tekton/{prName}.yaml
git add .tekton/{prName}.yaml
git commit -m "Added or updated files for tekton pipeline."
git push origin <branch>
```

### ④ 验证

- `kubectl get repository <name> -n <ns> -o jsonpath='{.spec.branchEnvs}'` 含新条目
- git 分支上 `.tekton/{prName}.yaml` 已生成
- PipelineRun 首次运行正常

---

## 删除分支环境

> 与 Console `DeleteBranchEnvModal` 一致：**只从 Repository CR 移除条目，git 文件需手动删除**。

### ① 确认目标

```bash
kubectl get repository <name> -n <ns> -o jsonpath='{.spec.branchEnvs}' | yq -P
# 用户指定要删除的 branchName
```

### ② 更新 Repository CR

```bash
kubectl patch repository <name> -n <ns> --type=json -p \
  '[{"op":"remove","path":"/spec/branchEnvs/<index>"}]'
```

> 删除后 `spec.branchEnvs` 为空数组时，注意保留字段（`[]` 而非 `null`）。

### ③ 删除 git 主分支上的流水线文件（需审批）

> Console 明确提示：删除分支流水线后，**需手动删除代码仓库主分支（main/master）上的 `{{prName}}` 文件才生效**。

```bash
git clone <url> && git checkout main
git rm .tekton/{prName}.yaml
git commit -m "Added or updated files for tekton pipeline."
git push origin main
```

### ④ 验证

- Repository CR 无该 branchEnv 条目
- git 主分支无 `.tekton/{prName}.yaml`
- 该分支不再触发流水线

---

## 手动触发运行

编辑完成 push 后通常由 PAC 自动触发；如需手动触发（对应 Console `ManualRunPipelineModal`）：

```bash
# 从 Secret 取 webhook.secret
WS=$(kubectl get secret <secret.name> -n <ns> -o jsonpath='{.data.webhook\.secret}' | base64 -d)

curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<ns>&repository=<repo>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

仅当 `branchEnvs[].manualTrigger=true` 时该分支支持手动触发。

---

## 安全规则

- Token 绝不回显/进日志/入库
- push 前必须用户审批；生产变更额外影响评估
- 不删除 `.tekton/` 文件；改前先 `git log` 记录原 SHA 以便回滚
- 每次操作记录到 `logs/LOGS.md`
- 修改注解时保持 `on-target-branch` 与目标分支一致，防止误触发

---

## 失败排查

| 现象 | 排查方向 |
|------|---------|
| 文件改了但没触发 | commit message 不是 `PacCommitMessage`？→ 检查是否被跳过；或注解 `on-event`/`on-target-branch` 不匹配 |
| Task 引用失败 | `kubectl get task <name> -n kubedo` 是否存在；resolver namespace 是否为 `kubedo` |
| push 401/403 | Token 过期 → 提示用户重新登录 KDO 平台刷新 CloudShell Token |
| 触发了但运行失败 | TaskRun Pod 日志：`kubectl logs -n <ns> <pipelinerun-pod> -c step-*` |
| 想预览影响 | push 前用 `kubectl apply --dry-run=server -f`（需权限） |

---

## 相关页面

- [[kdo-pipelines]] — Tekton/PAC 全貌、注解体系、模板变量
- [[kdo-repository-pac]] — Repository CRD、branchEnvs、PAC 数据流
- [[kdo-pipeline-builder]] — Console DAG 编辑器（对应用 UI 的等价能力）
- [[kdo-terminal]] — CloudShell 与 Git 凭据注入

---

_Last updated: 2026-08-11_
