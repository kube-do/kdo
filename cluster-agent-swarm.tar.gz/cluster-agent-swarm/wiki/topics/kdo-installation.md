---
title: KDO 安装与配置
tags: [kdo, installation, setup, configuration]
---

# KDO 安装与配置

---

## 系统要求

| 项目 | 要求 |
|------|------|
| 操作系统 | RHEL 9 / AlmaLinux 9 / Rocky 9 / Ubuntu 22.04+ |
| 节点数 | 生产建议 5+ 节点 |
| Kubernetes | v1.28+ |
| 浏览器 | Chrome/Firefox 最新版 |

---

## 安装路径

### 路径 A: 全新部署（含 Kubernetes）

1. 先部署 Kubernetes 集群
2. 再安装 KDO 平台

### 路径 B: 接入现有集群

1. 配置 OIDC 认证 (对接 Keycloak)
2. 安装 KDO 平台

---

## 安装步骤

### 1. 下载安装包

```bash
# 下载安装包
# install.zip / install.tar.gz
```

### 2. 安装前检查

```bash
# 运行安装前检查脚本
./kdo-install.sh --check
```

### 3. 运行安装脚本

```bash
./kdo-install.sh <NODE_IP> <DEFAULT_DOMAIN>
```

### 验证安装

```bash
kubectl get pod -n kubedo-system
```

确认 console Pod 启动后，访问 Console（地址通过 `kubectl get cm -n kubedo-system console -o json | jq -r '.data["config.yaml"]' | grep consoleBaseAddress | awk '{print $2}'` 获取）

---

## 定制化参数

通过环境变量定制:

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `KC_PASS` | 管理员密码 | Kdo@Pass#2025 |
| `OIDC_CLIENT_ID` | OIDC 客户端 ID | — |
| `OIDC_CLIENT_SECRET` | OIDC 客户端密钥 | — |
| `OIDC_ISSUER_URL` | OIDC 颁发者 URL | — |

---

## 默认账号

| 账号 | 密码 | 角色 |
|------|------|------|
| `admin` | Kdo@Pass#2025 | 集群管理员 |
| `pa1` | Kdo#2025 | 项目管理员 |
| `dev1` | Kdo#2025 | 开发人员 |
| `qa1` | Kdo#2025 | 测试人员 |
| `ops1` | Kdo#2025 | 运维人员 |

---

## 访问地址

- 控制台: 通过 `kubectl get cm -n kubedo-system console -o json | jq -r '.data["config.yaml"]' | grep consoleBaseAddress | awk '{print $2}'` 获取
- Grafana: 通过 `kubectl get ingress -n monitoring grafana -o jsonpath='{.spec.rules[0].host}'` 获取地址 (admin/<grafana-admin-password>) — ⚠️ 默认密码，登录后立即修改

---

## Keycloak 集成

KDO 基于 Keycloak 做身份认证:

- Keycloak 管理控制台: 参考安装文档获取地址
- 导航菜单: Users / Groups / Roles / Clients / Events
- 支持对接外部 LDAP

---

## 相关页面

- [[kdo-architecture]]
- [[kdo-rbac-auth]]
- [[kdo-platform-project-management]]

---

_Last updated: 2026-07-17_
