---
title: KDO 平台项目管理
tags: [kdo, platform, project-management, environments, permissions]
---

# KDO 平台项目管理

KDO 平台的**项目（Project）**、**环境（Environment）** 和 **应用（Application）** 三者关联，共同构成资源管理体系。所有智能体需理解此模型以正确操作。

---

## 核心概念

### 项目（Project）
- 为实现一个或多个目标而协调的一系列活动
- 有明确的开始/结束时间、预定目标和范围
- 可包含多个应用
- 创建项目时自动创建同名 Kubernetes 命名空间
- 仅**集群管理员**可创建项目
- 底层由 **KDC AppProject Controller** 自动调和（详见 [[kdc-project-env-lifecycle]]）

### 环境（Environment）
- 对应 Kubernetes 的一个命名空间，命名规则：`{project}-{env}`
  - 如项目 `abc` 的开发环境命名空间为 `abc-dev`
- 默认四种环境：

| 环境 | 标识 | 用途 |
|------|------|------|
| 开发环境 | `dev` | 开发者编写和调试代码 |
| 测试环境 | `test` | QA 进行功能/性能测试 |
| 预发环境 | `stage` | 模拟生产环境做最终验证 |
| 生产环境 | `prod` | 最终用户使用的运行环境 |

### 应用（Application）
- 为用户提供特定功能和服务的软件程序
- 可以是移动应用、桌面应用、Web 应用等形式
- 在同一项目中可开发多个应用
- 在不同环境中经历从开发、测试到上线的生命周期

---

## 项目成员与权限

KDC Controller 定义了 5 种预定义角色，由 AppEnv Controller 按环境类型自动分配 RBAC：

| 角色 | dev | test | stage | prod |
|------|-----|------|-------|------|
| **project-admin** | R+W | R+W | R+W | R+W |
| **developer** | R+W | R | R | R |
| **qa** | R | R+W | R | R |
| **ops** | R | R | R+W | R+W |
| **view** | R | R | R | R |

所有环境额外有 `default-sa` RoleBinding（default SA → developer 角色，用于跨环境部署）。

### KDC 自动创建资源

创建项目 (AppProject CR) 时，KDC AppProject Controller 自动调和:

| 资源 | 说明 |
|------|------|
| Namespace | 同名项目命名空间 |
| PVC `repo-cache` | 20Gi RWX，代码仓库缓存 |
| ClusterRole + ClusterRoleBinding | 项目管理员 CRD 操作权限 |
| 5 个 RoleBinding | project-admin/developer/ops/qa/view |
| registry Secret | dockerconfigjson 类型，Harbor 认证 |
| Harbor Robot 账号 | 系统级，所有 project 完全权限 |

创建环境 (AppEnv CR) 时，自动调和:

| 资源 | 说明 |
|------|------|
| Namespace | `{project}-{env}` |
| RoleBinding | 按环境类型分配角色 |
| registry Secret | 环境级别 Harbor 认证 |
| Harbor Project | `{project}-{env}` 公开项目 |

删除时自动级联清理 Namespace 和 Harbor 资源。

---

## 环境复制（快速复制）

支持基于已部署应用快速复制到其他环境，适用于：

- 多分支并行迭代（不同分支需要独立部署）
- 多开发者各自需要的独立开发环境
- 从开发→测试→预发的快速推进
- 生产灰度发布

### 原理

KDO 基于**应用模型**抽象管理各类型软件，复制实质是模型属性的复制，保障组件属性与源组件一致。

### 依赖关系处理

| 场景 | 处理方式 |
|------|----------|
| 组件及其依赖组件同时被复制 | 保持依赖关系，在新组件之间建立 |
| 仅依赖方被复制，目标在当前团队 | 新组件依然依赖源组件 |
| 仅依赖方被复制，目标在不同团队 | 复制时解除依赖关系 |

---

## 相关 Agent 操作指南

### Developer Experience (Desk)
- 开发者入职时解释项目/环境/应用模型
- 协助创建命名空间并关联项目环境
- 指导开发者理解各环境权限边界
- 使用 [[kdo-platform-project-management]] 知识回答开发者问题

### Cluster Ops (Atlas)
- 理解项目→命名空间的映射关系
- 管理项目环境对应的命名空间资源配额
- 为项目环境配置正确的资源限制

### GitOps (Flow)
- 理解各环境在部署流水线中的角色
- 根据目标环境选择合适的部署策略
- 确保应用在不同环境间正确流转

### Orchestrator (Jarvis)
- 路由任务时考虑项目/环境上下文
- 理解成员角色权限以正确分配操作权限
- 协调跨环境的复制操作

---

## 相关页面

- [[kdc-controller]]
- [[kdc-project-env-lifecycle]]
- [[kdc-user-sync]]
- [[kdo-architecture]]
- [[kdo-rbac-auth]]

---

_Last updated: 2026-07-17_
