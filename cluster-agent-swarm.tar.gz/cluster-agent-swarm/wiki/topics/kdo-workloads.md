---
title: KDO 工作负载
tags: [kdo, workloads, deployment, statefulset, hpa]
---

# KDO 工作负载

KDO 管理 Kubernetes 各类工作负载资源，支持完整的生命周期操作。

---

## 工作负载类型

| 类型 | 适用场景 | 关键特性 |
|------|---------|---------|
| **Deployment** | 无状态应用 (Web/微服务) | 滚动更新、回滚、副本管理 |
| **StatefulSet** | 有状态应用 (DB/缓存) | 稳定网络标识 `<name>-0`、持久存储、有序部署 |
| **DaemonSet** | 节点级服务 (日志/监控) | 每个节点运行一个 Pod |
| **CronJob** | 定时任务 | 基于 Cron 表达式调度 |
| **Job** | 一次性任务 | 运行到完成 |

---

## Deployment

| 操作 | 说明 |
|------|------|
| 启动/重启/停止/删除 | 批量操作 |
| 编辑副本数 | 手动扩缩 |
| HPA | 自动扩缩 |
| PDB | 中断预算 |
| 健康检查 | 存活/就绪探针 |
| 添加存储 | 挂载 PVC |
| 更新策略 | 滚动更新参数 |
| 资源限制 | CPU/内存 edit |

### 详情页

- 详情、指标、YAML、副本集、容器组、环境变量、事件

---

## StatefulSet

为每个 Pod 提供稳定唯一的网络标识。

### 关键特性

- 稳定的网络身份 (`<name>-0`, `<name>-1`, ...)
- 持久存储 (每个 Pod 独立 PVC)
- 有序部署和扩展
- 有序滚动更新
- 需要 Headless Service

### 适用场景

- 数据库 (MySQL/PostgreSQL)
- 缓存 (Redis)
- 需要持久存储和稳定网络标识的应用

---

## CronJob

```
┌───────────── 分钟 (0-59)
│ ┌───────────── 小时 (0-23)
│ │ ┌───────────── 日 (1-31)
│ │ │ ┌───────────── 月 (1-12)
│ │ │ │ ┌───────────── 星期 (0-6)
│ │ │ │ │
* * * * *
```

### KDO 操作

- 创建/编辑/删除
- 暂停/恢复
- 手动触发
- 查看历史运行记录

---

## HPA (水平自动扩缩)

基于 CPU/内存 利用率自动调整副本数。

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
spec:
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
```

---

## PDB (Pod 中断预算)

保证最小可用 Pod 数量，防止滚动更新/节点维护时服务中断。

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
spec:
  minAvailable: 2  # 或 maxUnavailable: 1
  selector:
    matchLabels:
      app: my-app
```

---

## 相关页面

- [[kdo-applications]]
- [[kdo-platform-project-management]]
- [[kdo-storage]]
- [[kdo-networking]]

---

_Last updated: 2026-07-17_
