---
title: Eclipse Che 云开发平台
tags: [che, eclipse-che, cde, devfile, workspace, ide]
---

# Eclipse Che 云开发平台

Eclipse Che 是一个 Kubernetes 原生的云开发环境（CDE）平台，提供按需容器化开发环境，支持浏览器 IDE 和桌面 IDE 接入。

---

## 架构概览

Che 由三大组件群组成：

```
用户 → Che Gateway (认证/路由)
         ├── Che Dashboard (UI)
         ├── Che Server (工作区生命周期)
         └── DevWorkspace Operator
                  └── 工作区 Pod (编辑器 + Language Server + 运行时)
```

| 组件 | 职责 |
|------|------|
| **Che Operator** | 管理 CheCluster CR，生成 ConfigMap 驱动各子组件 |
| **DevWorkspace Operator** | 将 DevWorkspace CR 转为实际 K8s 资源 |
| **Che Gateway** | 路由 + OIDC 认证，控制工作区访问 |
| **Che Dashboard** | 用户工作区管理界面 |
| **Che Server** | 多租户、工作区生命周期管理 |
| **Devfile Registry** | devfile 示例模板仓库 |
| **Plugin Registry** | IDE 插件分发（可对接 Open VSX） |

---

## 安装与部署

### 前置条件

- Kubernetes >= 1.21 或 OpenShift >= 4.18
- 集群需要 `cert-manager` 或自行管理 TLS 证书
- 可选 Keycloak / 外部 OIDC 提供者

### 安装方式

| 方式 | 适用平台 |
|------|---------|
| **chectl** CLI | K8s / OpenShift / minikube / CRC |
| **Helm** | 任意 K8s |
| **Operator Hub** | OpenShift Web Console |
| **Che Operator** | K8s (通过 OLM 安装) |

### 部署检查命令

```bash
# 查看 Che 命名空间状态
kubectl get ns <che-namespace>   # 通常为 eclipse-che

# 查看 CheCluster CR
kubectl get checluster -n <che-namespace> -o yaml

# 查看所有 Che 组件 Pod
kubectl get all -n <che-namespace>

# 查看 DevWorkspace Operator
kubectl get all -n devworkspace-controller

# 查看 Che 访问地址
kubectl get checluster -n <che-namespace> \
  -o jsonpath='{.items[0].status.cheURL}'
```

---

## CheCluster CR 核心配置

CheCluster 是 Che Operator 管理的自定义资源，通过编辑 CR 配置所有组件:

```yaml
apiVersion: org.eclipse.che/v2
kind: CheCluster
metadata:
  name: eclipse-che
  namespace: <che-namespace>
spec:
  devEnvironments:
    defaultNamespace:
      autoProvision: true           # 自动为用户创建命名空间
      template: <username>-che      # 命名空间命名模板
    disableContainerBuildCapabilities: false
    maxNumberOfWorkspacesPerUser: -1   # -1 为无限制
    persistUserHome:
      enabled: true                 # 持久化用户 $HOME 目录
    secondsOfInactivityBeforeIdling: 1800  # 空闲超时（秒）
    startTimeoutSeconds: 1200       # 工作区启动超时
    storage:
      pvcStrategy: per-user         # per-user / per-workspace / ephemeral
    defaultComponents: []           # 默认工作区组件
    defaultEditor: che-incubator/che-code/latest
  networking:
    domain: <ingress-domain>        # 工作区路由域名
    hostname: che.<domain>          # Che 外部访问地址
    tlsSecretName: <tls-secret>     # TLS 证书 Secret
    auth:
      identityProviderURL: <oidc-issuer-url>
      oAuthClientName: <client-id>
      oAuthSecret: <client-secret>
      gateway:
        configLabels:
          app: che
          component: che-gateway-config
  components:
    cheServer:
      logLevel: INFO
    dashboard:
      logLevel: ERROR
    devfileRegistry: {}
    pluginRegistry:
      openVSXURL: https://open-vsx.org  # Open VSX 外部市场
    metrics:
      enable: false
    imagePuller:
      enable: false
```

### 关键配置项说明

| 字段 | 说明 |
|------|------|
| `devEnvironments.defaultNamespace` | 用户工作区命名空间策略 |
| `devEnvironments.storage.pvcStrategy` | 存储策略: `per-user` 共享 PVC / `per-workspace` 独立 / `ephemeral` 不持久化 |
| `devEnvironments.disableContainerBuildCapabilities` | 禁用容器构建（安全加固） |
| `devEnvironments.secondsOfInactivityBeforeIdling` | 无活动自动停止，-1 为禁止自动停止 |
| `networking.auth` | OIDC 认证配置，对接外部身份提供者 |
| `networking.tlsSecretName` | TLS 证书 Secret（需提前创建） |
| `components.pluginRegistry.openVSXURL` | VS Code 扩展市场地址 |

---

## DevWorkspace Operator

DevWorkspace Operator 是 Che 的底层基础设施，独立于 Che Server，将 DevWorkspace CR 转换为实际工作区资源。

### 核心资源

- **DevWorkspace** — 工作区定义（devfile → CR）
- **DevWorkspaceTemplate** — devfile 组件模板

### 诊断命令

```bash
# 查看所有工作区
kubectl get devworkspaces --all-namespaces

# 查看特定工作区详情
kubectl describe devworkspace <name> -n <user-namespace>

# 查看工作区 Pod
kubectl get pods -n <user-namespace>

# 查看工作区事件
kubectl get events -n <user-namespace> --sort-by='.lastTimestamp'
```

---

## 用户与命名空间

### 命名空间自动创建

当用户首次登录 Dashboard 创建/启动工作区时，Che 自动创建用户命名空间。

命名策略由 `devEnvironments.defaultNamespace.template` 控制:
- `<username>-che` — 默认模板
- 支持 Go template 语法，可用变量: `username`、`userID`

### 用户命名空间标签

自动创建的命名空间带有以下标签:
```yaml
app.kubernetes.io/component: workspaces-namespace
app.kubernetes.io/part-of: che.eclipse.org
```

---

## 工作区

### 工作区生命周期

```
Pending → Starting → Running → Stopping → Stopped
```

### 工作区组件

每个工作区为 K8s Deployment，包含:
- IDE 容器（Code - OSS / JetBrains）
- Language Servers
- 调试工具
- 应用运行时

自动创建的 K8s 资源:
- Deployment / Pod
- Service + Endpoints
- Ingress / Route
- PersistentVolumeClaim
- ConfigMap / Secret

### Devfile 示例

```yaml
schemaVersion: 2.2.0
metadata:
  name: my-workspace
components:
  - name: dev
    container:
      image: quay.io/devfile/universal-developer-image:latest
      sourceMapping: /projects
      memoryLimit: 4Gi
projects:
  - name: my-project
    git:
      remotes:
        origin: https://github.com/user/my-project.git
```

### 通用开发镜像要求

Code - OSS 编辑器要求镜像包含以下工具:
- `openssl`
- `libbrotli`

推荐基础镜像:
- `quay.io/devfile/universal-developer-image:latest`（UDI）
- `registry.access.redhat.com/ubi9/ubi`（UBI 基础）

---

## Git 认证

Che 中 Git 仓库的认证有两种方式：

### 方式一：平台级 OAuth（Che OAuth）

在 CheCluster CR 的 `gitServices` 中配置，为所有用户提供统一的 Git 认证。支持:

| Git 服务 | 认证方式 |
|----------|---------|
| **GitHub** | OAuth 2.0 |
| **GitLab** | OAuth 2.0 |
| **Bitbucket Server** | OAuth 2.0 / OAuth 1.0 |
| **Bitbucket Cloud** | OAuth 2.0 |
| **Azure DevOps Services** | OAuth 2.0 |

配置示例:

```yaml
spec:
  components:
    cheServer:
      extraProperties:
        CHE_FORCE_REFRESH_PERSONAL_ACCESS_TOKEN: "true"  # 可选: 强制刷新 PAT
```

各服务具体 OAuth 配置需在 Git 提供商创建 OAuth App，将回调 URL 指向 Che Gateway。

### 方式二：Git Credentials Secret（推荐，无需 OAuth）

创建 Kubernetes Secret 并打上特定标签，DevWorkspace Operator 自动挂载到工作区:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: <git-credentials>
  namespace: <user-namespace>
  labels:
    controller.devfile.io/git-credential: "true"
    controller.devfile.io/watch-secret: "true"
  annotations:
    controller.devfile.io/mount-path: "/.git-credentials"
    controller.devfile.io/mount-as: "file"
    che.eclipse.org/automount-workspace-secret: "true"
    che.eclipse.org/git-credential: "true"
    che.eclipse.org/scm-url: "https://<git-server>"
type: Opaque
data:
  credentials: <base64("https://oauth2:<PAT>@<git-server>")>
```

**认证格式（data.credentials 的明文内容）**:

| Git 服务 | credentials 值 |
|----------|---------------|
| **GitHub** | `https://<USER>:<PAT>@github.com` |
| **GitLab** | `https://oauth2:<PAT>@gitlab.com` |
| **Gitee** | `https://oauth2:<PAT>@gitee.com` |
| **Bitbucket** | `https://x-token-auth:<PAT>@bitbucket.org` |

**关键点**:
- 创建后即时生效，无需重启工作区
- 所有 git 操作（包括 init 容器的 clone）自动使用该凭据
- 支持 `che.eclipse.org/scm-url` 限定特定 Git 服务
- Secret 更新后自动重新挂载
- 适用于**任何 HTTP(S) Git 服务**，包括自建 GitLab/Gitea

> 💡 **如果所用 Git 服务不在方式一 OAuth 支持列表中（如 Gitee、AWS CodeCommit 等），直接使用本方式即可。** 无需平台管理员配置 OAuth，用户在自己的工作区命名空间创建 Secret 即可使用。

### 方式三：工作区内手动配置

在 IDE 终端中执行:

```bash
git config --global credential.helper store
git config --global user.name "<name>"
git config --global user.email "<email>"
```

或挂载 ConfigMap/Secret 到 `~/.gitconfig`（参见 [[wiki/topics/eclipse-che]] 官方文档）。

---

## 网络与路由

### 工作区访问路径

```
https://<che-hostname>/<username>/<workspace-name>/<port>/
```

Gateway (Traefik) 负责将路径按用户名 + 工作区名路由到对应 Pod。

### TLS 证书

- 支持 Ingress TLS 或 OpenShift Route 边缘终止
- CheCluster CR 中 `networking.tlsSecretName` 指定证书 Secret
- 证书需要覆盖域名: `*.<ingress-domain>`

---

## 认证与授权

### 认证流程

```
用户 → Che Gateway → OIDC Provider (Keycloak/ Dex / 其他) → Token → Che Server
```

### RBAC

Che Operator 创建两个 ClusterRole:

| ClusterRole | 用途 |
|-------------|------|
| `<ns>-cheworkspaces-clusterrole` | 工作区命名空间基础操作 |
| `<ns>-cheworkspaces-devworkspace-clusterrole` | DevWorkspace CR 管理 |

用户在工作区命名空间的操作权限:

| 资源 | 权限 |
|------|------|
| pods | CRUD |
| pods/exec | get, create |
| pods/log | get, list, watch |
| pods/portforward | get, list, create |
| configmaps | CRUD |
| secrets | CRUD |
| services | CRUD |
| persistentvolumeclaims | CRUD |
| apps/deployments | CRUD |
| devworkspace | 完全控制 |

### 高级授权

```yaml
networking:
  auth:
    advancedAuthorization:
      allowUsers: [<user-a>]
      denyUsers: [<user-b>]
      allowGroups: [<group-a>]
      denyGroups: [<group-b>]
```

---

## 存储

### PVC 策略

| 策略 | 行为 | 适用场景 |
|------|------|---------|
| `per-user` | 用户共享一个 PVC | 节省存储，用户工作区之间共享数据 |
| `per-workspace` | 每个工作区独立 PVC | 工作区隔离 |
| `ephemeral` | 无持久化，临时存储 | 测试/CI |

### 查看存储使用

```bash
# 查看用户命名空间 PVC
kubectl get pvc -n <user-namespace>

# 查看所有 Che 相关 PVC
kubectl get pvc --all-namespaces \
  -l app.kubernetes.io/part-of=che.eclipse.org
```

---

## 安全

### 安全上下文

- 默认不启用特权容器
- 容器构建默认需要 `SETGID` + `SETUID` capabilities
- 可通过 `disableContainerBuildCapabilities: true` 关闭

### 资源隔离

- 建议在工作区命名空间设置 ResourceQuota + LimitRange
- NetworkPolicy 可限制工作区 Pod 的网络访问
- 支持 air-gapped 环境部署

---

## 常见诊断命令

```bash
# 1. 检查 Che 部署状态
kubectl get checluster -n <che-namespace> \
  -o jsonpath='{.items[0].status.chePhase}'

# 2. 查看所有用户工作区
kubectl get devworkspaces --all-namespaces

# 3. 列出所有用户命名空间
kubectl get ns \
  -l app.kubernetes.io/part-of=che.eclipse.org

# 4. 查看工作区启动日志
kubectl logs -n <che-namespace> deployment/che

# 5. 检查 Gateway 日志
kubectl logs -n <che-namespace> deployment/che-gateway

# 6. 查看 DevWorkspace Operator 日志
kubectl logs -n devworkspace-controller \
  deployment/devworkspace-controller-manager

# 7. 查看 Webhook 日志
kubectl logs -n devworkspace-controller \
  deployment/devworkspace-webhook-server

# 8. 检查工作区事件
kubectl get events -n <user-namespace> --sort-by='.lastTimestamp'

# 9. 查看 Che 版本
kubectl get checluster -n <che-namespace> \
  -o jsonpath='{.items[0].status.cheVersion}'

# 10. 查看 Che URL
kubectl get checluster -n <che-namespace> \
  -o jsonpath='{.items[0].status.cheURL}'
```

---

## 故障排查

### 工作区无法启动

| 可能原因 | 检查方法 |
|----------|---------|
| PVC 未就绪 | `kubectl get pvc -n <user-ns>` |
| 镜像拉取失败 | `kubectl describe pod -n <user-ns>` |
| ResourceQuota 不足 | `kubectl describe quota -n <user-ns>` |
| Ingress 未就绪 | `kubectl get ingress -n <che-ns>` |
| OIDC 配置错误 | 检查 Che Server 日志 |
| TLS 证书问题 | 检查 Gateway 日志 |

### 工作区自动停止

- 检查 `secondsOfInactivityBeforeIdling` 配置（默认 1800 秒）
- 检查 `secondsOfRunBeforeIdling` 配置（-1 为永不过期）

### Gateway 503 错误

- 检查工作区 Pod 是否 Running
- 检查 `che-gateway` Pod 日志中的路由信息
- 确认域名配置正确

---

## 常用操作

### 管理工作区

```bash
# 手动停止工作区
kubectl patch devworkspace <name> -n <ns> \
  --type=merge -p '{"spec":{"started":false}}'

# 手动启动工作区
kubectl patch devworkspace <name> -n <ns> \
  --type=merge -p '{"spec":{"started":true}}'

# 删除工作区
kubectl delete devworkspace <name> -n <ns>
```

### 查看所有用户命名空间及工作区

```bash
for ns in $(kubectl get ns -l app.kubernetes.io/part-of=che.eclipse.org -o name); do
  ns_name=${ns#namespace/}
  count=$(kubectl get dw -n "$ns_name" 2>/dev/null | tail -n +2 | wc -l)
  echo "$ns_name: $count workspace(s)"
done
```

---

## 术语表

| 术语 | 含义 |
|------|------|
| **Eclipse Che** | 云 IDE 平台 — 基于 K8s 的浏览器内开发环境 |
| **CDE** | Cloud Development Environment |
| **Code - OSS** | Che 定制版的 VS Code（默认编辑器） |
| **Workspace** | 容器化开发环境，由 devfile 定义 |
| **Devfile** | YAML 格式的工作区定义文件 |
| **Plugin** | 容器化 VS Code 扩展 |
| **Factory** | 自动化工作区创建模板 |
| **Open VSX** | VS Code 扩展的开放市场 |
| **UDI** | Universal Developer Image — 通用开发镜像 |

---

## 参考链接

- 官方文档: https://www.eclipse.org/che/docs/stable/
- 源码: https://github.com/eclipse/che
- Devfile 规范: https://devfile.io/docs/
- Open VSX 扩展市场: https://open-vsx.org
- DevWorkspace Operator: https://github.com/devfile/devworkspace-operator
- 社区支持: StackOverflow `eclipse-che` 标签
