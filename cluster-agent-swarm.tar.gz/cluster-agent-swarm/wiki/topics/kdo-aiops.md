---
title: KDO AIOps 智能助手
tags: [kdo, aiops, lightspeed, llm, mcp]
---

# KDO AIOps 智能助手

KDO 集成 **Lightspeed** AI 智能助手，基于生成式 AI 提供自然语言交互的集群运维能力。

---

## Lightspeed 架构

六层架构模型:

```
┌─ 入口层 ──────────────────────────────┐
│  FastAPI REST API (16 个端点)           │
├─ API 层 ───────────────────────────────┤
│  认证: k8s(TokenReview+SAR)/noop/noop-with-token │
├─ 业务逻辑层 ───────────────────────────┤
│  12 子系统:                              │
│  ├── QueryPipeline (DocsSummarizer)     │
│  ├── ToolsRAG (工具检索+执行)            │
│  ├── SkillsRAG (技能检索)               │
│  ├── TokenBudget (四级预算)             │
│  └── OffloadManager (大输出卸载)        │
├─ 模型层 ───────────────────────────────┤
│  8 种 LLM 提供商 + RAG 双模式           │
├─ 配置层 ───────────────────────────────┤
│  Pydantic 层次模型 + YAML 驱动          │
└─ 工具层 ───────────────────────────────┤
│  MCP 工具系统 (审批门控+并行+大输出)     │
```

### 查询管线

```
用户输入 → 历史压缩 → RAG 检索 → 技能检索 → 工具解析 → LLM 多轮循环 → 输出
```

### LLM 提供商

| 提供商 | 类型 |
|--------|------|
| OpenAI | 商业 |
| Azure OpenAI | 商业 |
| Watsonx | IBM |
| Bedrock | AWS |
| Vertex AI | GCP |
| RHOAI | Red Hat |
| RHEL AI | Red Hat |
| Fake | 测试 |

### 注册机制

使用装饰器 `@register_llm_provider_as` 注册新提供商。

---

## RAG 知识检索

| 模式 | 技术 | 说明 |
|------|------|------|
| **稠密检索** | FAISS 向量索引 | 语义相似度搜索 |
| **混合检索** | Qdrant 稠密 + BM25 稀疏 | 线性融合评分 |
| **Solr 搜索** | edismax + KNN rerank | 企业级搜索引擎 |

---

## MCP 工具系统

```
配置 → 收集工具 → 过滤(ToolsRAG 混合检索) → 执行(审批门控+并行+大输出卸载)
```

| 特性 | 说明 |
|------|------|
| 工具发现 | 配置驱动，自动收集 |
| 工具过滤 | ToolsRAG 混合检索，语义匹配 |
| 审批门控 | 敏感操作需要审批 |
| 并行执行 | 多个工具同时执行 |
| 大输出卸载 | OffloadManager 处理超长输出 |

---

## OLS ↔ Hermes MCP 互通

| 方向 | 传输 | 功能 | 安全 |
|------|------|------|------|
| OLS → Hermes | stdio | web_search/browser/memory/skills/delegate/image | tools_approval 审批 |
| Hermes → OLS | SSE | ols_query/ols_troubleshoot/ols_get_conversation | bearer token |

实施分 3 阶段:
1. OLS MCP Server 实现
2. Stdio 传输支持
3. 高级集成 (上下文共享、技能互通)

---

## Token 预算管理

四级预算控制:

| 级别 | 说明 |
|------|------|
| **Prompt 预算** | 输入 Token 限制 |
| **Tool 预算** | 工具调用 Token 限制 |
| **Round 预算** | 多轮对话 Token 限制 |
| **Execution 预算** | 执行总 Token 限制 |

---

## 配置管理

- 配置存储于 `kubedo-system` 命名空间的 `olsconfig` ConfigMap
- Pydantic 层次模型，YAML 驱动
- `AppConfig` 单例模式，支持热重载

### 配置项

| 配置 | 说明 |
|------|------|
| `llm_providers` | LLM 提供商 (url + credentials_path + models) |
| `ols_config` | RAG 知识库、对话缓存、日志级别、TLS |
| `mcp_servers` | MCP 服务器配置 |

---

## 可观测性

| 维度 | 方式 |
|------|------|
| 指标 | 7 个 Prometheus 指标 |
| 追踪 | OpenTelemetry |
| 审计 | 结构化日志 (6 种事件类型) |
| 反馈 | 用户反馈收集 (可配置禁用) |

---

## Console 集成

Lightspeed AI 助手通过动态插件加载到 Console：

| 位置 | 说明 |
|------|------|
| 插件包 | `lightspeed-console-plugin`（Yarn workspace 包） |
| 后端代理 | `/api/console/ols/*` → Bridge 服务器反向代理到 OLS 服务 |
| UI 入口 | 右下角图标 → 对话窗口 |
| 加载方式 | 运行时通过 `/api/plugins/lightspeed-console-plugin/plugin-manifest.json` |

## 使用方式

1. 点击右下角图标打开对话窗口
2. 提交问题 (自然语言)
3. 可附加资源对象 (Pod YAML/Event 等)
4. 支持关联追问 (上下文感知)

### 典型场景

- 通用 K8s 问题解答
- 关联追问 (问题链)
- 附加资源分析 (如 CrashLoopBackOff 诊断)
- 告警排查 (结合监控数据)

---

## 数据隐私

- 发送前经过脱敏层 (redaction layer)
- 可配置禁用数据收集:
  - `userDataCollection.feedbackDisabled=true`
  - `transcriptsDisabled=true`

---

## 相关页面

- [[kdo-console]]
- [[kdo-architecture]]
- [[kdo-rbac-auth]]
- [[kdo-observability]]

---

_Last updated: 2026-07-17_
