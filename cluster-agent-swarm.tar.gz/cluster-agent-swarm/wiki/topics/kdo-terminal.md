---
title: KDO 终端与 CLI
tags: [kdo, terminal, cloudshell, localshell, cli]
---

# KDO 终端与 CLI

KDO 提供两种终端模式: **CloudShell** (浏览器内终端) 和 **LocalShell** (本地 CLI 工具)。

---

## CloudShell

基于 Pod 运行在 Kubernetes 中。

### 预装工具

| 工具 | 版本/说明 |
|------|----------|
| kubectl | Kubernetes CLI |
| oc | OpenShift CLI (v4.19.9+) |
| helm | Helm v3.17.1+ |
| tkn | Tekton CLI |
| kn | Knative CLI |
| istioctl | Istio CLI |
| kustomize | Kustomize |
| jq / yq | JSON/YAML 处理器 |
| curl / git | 网络/版本控制 |

### 资源限制

| 资源 | 限制 |
|------|------|
| CPU | 1 核 |
| 内存 | 1 Gi |
| 临时存储 | 1 Gi |
| 持久化存储 | 5 Gi |

### 环境配置

- 默认创建 `kubernetes-terminal` 命名空间
- 支持自定义环境 (持久化 `.bashrc` 到 `/data`)
- 进程管理: `supervisord` 管理后台服务

---

## LocalShell

通过 `oc` CLI 工具连接。

| 平台 | 支持 |
|------|------|
| Windows | ✅ |
| Linux | ✅ |
| Mac | ✅ |

### 登录方式

1. 用户菜单 → 复制登录命令
2. Token 登录: `oc login --token=<token> --server=<server>`
3. 支持多集群管理 (context 切换)

### oc CLI 特性

`oc` 是 `kubectl` 的超集，额外支持:

- `oc login` — 交互式登录
- `oc project` — 切换项目
- `oc expose` — 暴露服务
- `oc new-app` — 创建应用

---

## Hermes AI Agent 集成

CloudShell 内置 Hermes AI Agent:

| 端口 | 服务 |
|------|------|
| 8642 | Hermes Gateway (OpenAI 兼容 API) |

### 进程管理

- `supervisord` 管理 hermes-gateway (autorestart)
- fallback bash 保活循环
- 日志输出: `hermes logs --follow` → 容器 stdout

### 持久化

- `~/.hermes/` 通过 PVC 持久化
- 5 Gi ephemeral volume

---

## IDE 集成

| IDE | 插件 |
|-----|------|
| **VS Code** | Kubernetes 插件 |
| **JetBrains** | Kubernetes 插件 |

---

## 常用命令速查

### kubectl

| 命令 | 说明 |
|------|------|
| `kubectl get pods -n <ns>` | 查看 Pod |
| `kubectl logs -f <pod> -n <ns>` | 查看日志 |
| `kubectl describe pod <pod> -n <ns>` | Pod 详情 |
| `kubectl exec -it <pod> -n <ns> -- sh` | 进入容器 |

### helm

| 命令 | 说明 |
|------|------|
| `helm list -A` | 查看 Release |
| `helm install <name> <chart>` | 安装 Chart |
| `helm upgrade <name> <chart>` | 升级 Release |
| `helm rollback <name> <revision>` | 回滚 Release |

---

## 相关页面

- [[kdo-console]]
- [[kdo-console-usage]]
- [[kdo-architecture]]
- [[kdo-applications]]

---

_Last updated: 2026-07-17_
