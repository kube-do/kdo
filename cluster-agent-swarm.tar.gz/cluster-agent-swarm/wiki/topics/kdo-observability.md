---
title: KDO 观测平台
tags: [kdo, observability, monitoring, logging, alerting]
---

# KDO 观测平台

KDO 观测平台三大模块: **监控(Monitoring)** + **日志(Logging)** + **事件(Event)**。

技术栈: Prometheus + Grafana + Loki + Alertmanager。

---

## 数据流

```
应用/基础设施
    ↓ 采集 (Vector)
    ├──→ Prometheus TSDB → Grafana (可视化 + Unified Alerting)
    ├──→ Loki (日志)     → Grafana (可视化 + 日志告警)
    └──→ Alertmanager    → 通知渠道 (企微/邮件/Slack/钉钉/PagerDuty)
```

---

## 监控

### 架构

| 组件 | 功能 |
|------|------|
| **Prometheus Server** | 数据获取、存储、查询 (PromQL) |
| **Exporter** | 业务数据源 (node-exporter, kube-state-metrics 等) |
| **AlertManager** | 告警处理、分组、抑制、路由 |
| **Grafana** | 可视化仪表盘 |

默认访问: 通过 `kubectl get ingress -n monitoring grafana -o jsonpath='{.spec.rules[0].host}'` 获取地址 (账号: admin / `<grafana-admin-password>`)  

> ⚠️ **安全警告**: 默认密码仅用于初始登录，**必须立即修改**。修改方式: Grafana 页面 → 用户菜单 → 修改密码，或通过 Grafana API 修改。

### 预置仪表盘

| 仪表盘 | 内容 |
|--------|------|
| 集群总览 | CPU/内存/磁盘总量、流量分布 |
| 集群详情 | 健康指标、组件健康数、资源占比、网络带宽、节点状况 |
| 流量分布链路 | 域名 → 应用 → 团队 → 集群 |
| 系统大屏 | 集群巡检结果 |

### 集群巡检项

- K8s 集群巡检
- KDO 服务巡检
- 运行巡检
- 配置巡检
- 安全巡检

---

## 日志

基于 **Grafana Loki**，标签索引日志流，压缩块存储。

### Loki 架构

```
Vector(采集) → Distributor(分发) → Ingester(存储)
    ↓
Querier / Query Frontend(查询) → Grafana(可视化)
    ↓
Grafana Unified Alerting → Alertmanager(通知)
```

| 对比 | Loki | EFK Stack |
|------|------|-----------|
| 引擎 | 标签索引 | Elasticsearch 全文索引 |
| 资源占用 | 更低 | 较高 |
| 扩展性 | 水平扩展 | 需分片管理 |

### 日志源

- 容器 stdout
- 容器内文件
- Kubernetes 审计日志
- 系统 journald

### 日志保留

LokiStack 全局保留策略 `limits.global.retention.days: 15`（全部租户统一 15 天），存储走 MinIO S3（bucket `loki-k8s`）。调整保留天数：patch `lokistack-dev`（openshift-logging ns）的 `spec.limits.global.retention.days`，详见 [[kdo-logging-setup]]。

### 查询语言

使用 **LogQL**（类 PromQL 语法），通过标签过滤和流选择器查询。标签体系为 **viaq**（默认）：`kubernetes_namespace_name` / `kubernetes_pod_name` / `kubernetes_container_name` / `level` / `log_type`。

### KDO 日志代理

KDO 使用 **Vector** 作为日志代理（DaemonSet `logging`，镜像 `registry.cn-shenzhen.aliyuncs.com/kubedo/vector:6.0`），直连 LokiStack。

- 存储路径: `/var/lib/loki/chunks` 和 `/var/lib/loki/index`（MinIO S3，nfs-client 存储类）
- 访问入口: 容器组页面（当前 Pod 日志 + 聚合日志）/ 观测平台（全命名空间搜索）/ **Grafana Loki 数据源**

---

## 告警

> **KDO 平台日志告警 = Loki 日志告警，只能通过 Grafana 管理**（Grafana Unified Alerting，LogQL），不经 Ruler/PrometheusRule 承载。以下分级/渠道/Alertmanager 为告警通用配置；日志告警创建见文末「Loki 日志告警」。

### 告警分级

日志严重级别（Grafana/Loki 统一标准，插件 `severity` 枚举）：

| 级别 | 颜色 | 说明 |
|------|------|------|
| **critical** | 紫 | 严重故障（emerg/fatal/alert/crit） |
| **error** | 红 | 错误（err/eror） |
| **warning** | 黄 | 警告（warn/warning） |
| **info** | 绿 | 常规信息（inf/notice） |
| **debug** | 蓝 | 调试（dbug） |
| **trace** | 青 | 跟踪 |
| **unknown** | 灰 | 未知级别 |
| **other** | 灰 | 其他/空 |

> 另有 **响应时效分级**（P1-P4: 5 分钟/15 分钟/1 小时/24 小时）用于告警处理 SLA，与日志严重级别用途不同，二者并存不冲突。

### 通知渠道

| 渠道 | 方式 |
|------|------|
| 企业微信 | 企微应用推送（默认接收器） |
| 邮件 | SMTP |
| Slack | Webhook |
| 钉钉 | Webhook 映射 |
| PagerDuty | 事件驱动 |

### Alertmanager 配置（外部 Prometheus 指标告警）

> 以下为集群**外部 Alertmanager**（monitoring ns `alertmanager-main`），服务 Prometheus **指标告警**。**日志告警不走它**——Grafana 日志告警使用 **Grafana 内置 Alertmanager**（见下文）。

- 配置文件存储于 `monitoring` 命名空间的 `alertmanager-main` Secret，读取:
  `kubectl get secret alertmanager-main -n monitoring -o jsonpath='{.data.alertmanager\.yaml}' | base64 -d`
- 支持: 告警路由、全局配置、抑制规则、接收器管理
- 默认路由接收器为**企业微信**（`wechat-k8s`），企微应用参数（corp_id/agent_id/secret/to_user）均为平台私有配置，**不得硬编码写入文档**，需按上述命令从 Secret 读取
- 抑制规则: `severity=critical` 抑制 `warning|info`（equal: namespace, alertname）

### Loki 日志告警（只能通过 Grafana 管理）

**Loki 日志及日志告警的管理入口是 Grafana**（Unified Alerting），不经 Ruler 直接配置。

```
Loki 数据源 (application-log/infrastructure-log/audit-log)
    → Grafana 告警规则 (LogQL, 按租户选择数据源)
    → Grafana 内置 Alertmanager → 企微推送
```

- Grafana 中按日志租户预置三个 Loki 数据源（X-Scope-OrgID 头区分租户）
- 创建告警: Alerting → Alert rules → New alert rule → 选 Loki 数据源 → 写 LogQL 表达式
- 通知: 在 Grafana Alerting → Contact points / Notification policies 配置（Grafana 内置 Alertmanager，非集群 alertmanager-main）
- 完整步骤与 LogQL 示例见 [[kdo-logging-setup]]

### 数据模型

```
AlertmanagerConfig:
  ├── global: 全局配置
  ├── route: 路由(支持嵌套)
  │   ├── receiver + groupBy + groupWait/Interval + repeatInterval + matchers
  │   └── routes: 子路由(递归)
  ├── receivers: 接收器列表
  ├── inhibit_rules: 抑制规则
  │   ├── source_match + target_match + equal
  └── templates: 模板
```

---

## 事件

- Kubernetes Event 资源类型，记录集群活动和状态变化
- 主要属性: 对象相关性、来源、类型(Normal/Warning)、原因、消息、时间、计数
- KDO 资源对象 (Pod/Deployment/StatefulSet/Node) 均已集成事件菜单
- 支持关键字过滤和快速查找

---

## 黄金指标

| 指标 | 说明 |
|------|------|
| **Latency** | 延迟 |
| **Traffic** | 流量 |
| **Errors** | 错误率 |
| **Saturation** | 饱和度 |

---

## 相关页面

- [[kdo-architecture]]
- [[kdo-platform-project-management]]
- [[kdo-logging-setup]]

---

_Last updated: 2026-08-11_
