---
title: KDO Repository Pipelines-as-Code
tags: [kdo, repository, pac, pipelines, gitops]
---

# KDO Repository Pipelines-as-Code

Repository CRD 是 KDO 平台应用与 Git 仓库的声明式关联，是平台 CI/CD 的核心入口。通过 PAC（Pipelines-as-Code），开发者将 `.tekton/` 目录下的 PipelineRun YAML 放在 Git 仓库中，提交代码即可自动触发流水线。

## PAC 组件架构

PAC 由三个 Deployment 组成，各自独立运行：

| 组件 | K8s 资源 | 职责 | 监听端口 |
|------|---------|------|---------|
| **Controller** | Deployment `pipelines-as-code-controller` | 接收 Git Webhook → 匹配 Repository CR → 解析 `.tekton/` 模板 → 创建 PipelineRun | HTTP :8080 |
| **Watcher** | Deployment `pipelines-as-code-watcher` | 监视 PipelineRun 状态 → 报告结果到 Git Provider → 清理旧运行 | — |
| **Webhook** | Deployment `pipelines-as-code-webhook` | Kubernetes 准入验证，校验 Repository CR 创建/更新 | — |
| **CLI** | 二进制 `tkn-pac` | 本地 CLI 工具（bootstrap、创建仓库、日志、生成模板） | — |

### 技术栈

| 类别 | 技术 |
|------|------|
| 语言 | Go 1.25+ |
| CI/CD | Tekton Pipelines v1 (tektoncd/pipeline) |
| 控制器框架 | Knative Eventing (adapter/v2) + Knative sharedmain |
| Git SDK | go-github, gitlab-client, go-bitbucket, forgejo-sdk, go-gitee |
| CLI | Cobra + Survey (交互式提示) |
| 表达式 | CEL (google/cel-go) |
| 构建 | ko (容器镜像), GoReleaser (发布) |
| 可观测性 | OpenTelemetry, Prometheus 指标 |

---

## 核心数据流

Git 事件触发到 PipelineRun 完成的完整链路：

```
┌─────────────────────────────────────────────────────────────────────────┐
│ ① Webhook 接收 (adapter.listener.handleEvent)                         │
│ HTTP 请求到达 Controller :8080                                          │
│ ├─ detectProvider() → 识别 Git 提供商 (GitHub→GitLab→Gitee→Bitbucket)  │
│ ├─ Provider.Validate() → 验证 Webhook 签名                              │
│ └─ sinker.processEvent() → 异步派发                                     │
├─────────────────────────────────────────────────────────────────────────┤
│ ② 事件处理 (sinker.processEvent → PacRun.Run)                         │
│ ├─ 解析 Webhook Payload → info.Event 对象                               │
│ ├─ 匹配 Repository CR（按 URL 遍历）                                     │
│ ├─ SecretFromRepository.Get() → 读取 Git Token                          │
│ ├─ gitclient.SetupAuthenticatedClient() → 设置认证客户端                 │
│ └─ 检查 skip CI（commit message 含 [skip ci] 则跳过）                    │
├─────────────────────────────────────────────────────────────────────────┤
│ ③ 流水线匹配 (pipelineascode/match.go)                                 │
│ ├─ GetTektonDir() → 从仓库获取 .tekton/ 目录内容                        │
│ ├─ makeTemplate() → 替换 {{ var }} 模板变量                              │
│ ├─ resolve.ReadTektonTypes() → 解析 YAML → Tekton 对象                  │
│ ├─ 剪枝未使用文件 (BranchEnvs 引用检查)                                  │
│ ├─ resolve.Resolve() → 解析元数据 + 远程任务                              │
│ ├─ MatchPipelinerunByAnnotation() → 注解匹配                            │
│ │   ├─ on-cel-expression → celEvaluate()                               │
│ │   ├─ on-comment → 正则匹配                                           │
│ │   ├─ on-event + on-target-branch → matchOnAnnotation()               │
│ │   ├─ on-path-change / on-path-change-ignore → glob 匹配              │
│ │   └─ on-label → PR 标签匹配                                          │
│ ├─ 注解 ACL 检查 (ChatOps 权限)                                         │
│ ├─ 远程任务解析 (RemoteTasks.getRemote())                                │
│ └─ changePipelineRun() → 替换 git-auth Secret 引用                      │
├─────────────────────────────────────────────────────────────────────────┤
│ ④ 创建 PipelineRun + 状态报告                                           │
│ ├─ kubeinteraction.Create() → 创建 PipelineRun                         │
│ ├─ kubeinteraction.CreateSecret() → 创建 git-auth Secret               │
│ └─ Provider.CreateStatus() → 向 Git 报告 pending 状态                   │
├─────────────────────────────────────────────────────────────────────────┤
│ ⑤ Watcher 状态监视 (reconciler.ReconcileKind)                          │
│ ├─ Running → 报告 in_progress                                          │
│ ├─ Completed → postFinalStatus()                                       │
│ │   ├─ 获取 TaskRun 状态                                                │
│ │   ├─ 模板化状态消息                                                   │
│ │   ├─ createStatusWithRetry() → 报告结果到 Git                          │
│ │   └─ performLLMAnalysis() → 可选 LLM 分析                             │
│ ├─ updateRepoRunStatus() → 更新 Repository Status                       │
│ ├─ emitMetrics() → Prometheus 指标                                      │
│ ├─ emitTimingSpans() → OTel 追踪                                        │
│ └─ cleanupPipelineRuns() → 清理旧运行                                   │
└─────────────────────────────────────────────────────────────────────────┘
```

### 失败卡点速查

| 现象 | 卡在 | 排查位置 |
|------|------|---------|
| Webhook 到达但无任何反应 | ①② | Controller 日志 `adapter`/`sinker` |
| 有事件但没创建 PipelineRun | ③ | `match.go` 日志，检查注解匹配 |
| PipelineRun 创建了但没运行 | ③ | 模板解析错误、远程任务拉取失败 |
| PipelineRun 运行中失败 | ④ | TaskRun Pod 日志 |
| PipelineRun 完成但 Git 没状态 | ⑤ | Watcher 日志，检查 Token 写权限 |

---

## Repository CRD 完整定义

> `pipelinesascode.tekton.dev/v1alpha1` — 用户唯一需要创建的 CRD。

```go
type RepositorySpec struct {
    ConcurrencyLimit *int              // 最大并发流水线数
    URL              string            // 仓库 URL
    GitProvider      *GitProvider      // Git 提供商认证配置
    Incomings        *[]Incoming       // 传入 Webhook 配置
    Params           *[]Params         // 自定义参数
    Settings         *Settings         // 策略/权限/LLM 设置
    BranchEnvs       []BranchEnv       // KDO 扩展: 分支→环境映射
    DevInfo          *DevInfo          // KDO 扩展: 应用元数据
}

type GitProvider struct {
    URL           string              // Git 提供商 URL
    Type          string              // github/gitlab/gitee/bitbucket
    Secret        SecretRef           // provider.token 引用
    WebhookSecret SecretRef           // webhook.secret 引用
    User          string              // Bitbucket 用户名
}

type BranchEnv struct {
    BranchName    string              // Git 分支名
    AppEnv        string              // 部署环境
    Cluster       string              // 目标集群
    PRName        string              // .tekton/ 文件名
    PRTemplate    string              // 模板 ConfigMap 名称
    OnEvent       []string            // 触发事件
    ManualTrigger bool                // 手动触发模式
}

type DevInfo struct {
    DevLanguage string              // 开发语言 (go/java/nodejs/...)
    DevFramework string             // 开发框架 (gin/spring-boot/vue/...)
    DevTemplate string              // ConfigMap 模板名
    Port        string              // 应用端口
    GitProvider string              // ★ 必须与 spec.git_provider.type 一致
}
```

### Status

```go
type RepositoryRunStatus struct {
    PipelineRunName string
    SHA             *string           // 提交 SHA
    SHAURL          *string
    Title           *string           // 提交标题
    LogURL          *string           // 控制台日志 URL
    CompletionTime  *metav1.Time
    TargetBranch    *string
    EventType       *string
    Conditions      []Condition       // 运行状态
}
```

---

## .tekton 文件注解体系

> `.tekton/` 目录下的 PipelineRun YAML 通过头部注解控制触发条件。

| 注解 | 格式 | 说明 |
|------|------|------|
| `on-event` | `[pull_request, push]` | 匹配 Git 事件类型 |
| `on-target-branch` | `[main, release-*]` | 匹配目标分支（支持 glob） |
| `on-comment` | `^/test all$` | 匹配 PR 评论（正则） |
| `on-path-change` | `[src/**, *.go]` | 仅当这些文件变更时触发 |
| `on-path-change-ignore` | `[docs/**, *.md]` | 忽略这些文件变更 |
| `on-label` | `[ok-to-test, safe]` | 匹配 PR 标签 |
| `on-cel-expression` | `event_type == "push"` | CEL 自定义表达式 |
| `max-keep-runs` | `5` | 最大保留运行数 |
| `cancel-in-progress` | `true` | 新推送时取消进行中运行 |
| `task` / `task-N` | `[git-clone, buildah]` | 从 Hub 自动嵌入远程 Task |

### CEL 表达式变量

| 变量 | 类型 | 说明 |
|------|------|------|
| `event` / `event_type` | string | Git 事件类型 |
| `body` | map | Webhook JSON 负载 |
| `headers` | map | HTTP 请求头（小写 key） |
| `target_branch` / `source_branch` | string | 目标/源分支 |
| `target_url` / `source_url` | string | 仓库 URL |
| `files` | map | 变更文件列表（懒加载） |
| `sender` | string | 事件发送者 |
| `pull_request_labels` | string | PR 标签逗号分隔 |
| `pull_request_number` | int | PR 编号 |

---

## 模板变量

> PAC 在创建 PipelineRun 时替换 `{{ var }}`，变量值来自 Webhook Payload 和运行时信息。

| 变量 | 来源 | 示例 |
|------|------|------|
| `{{ repo_url }}` | Event | `https://gitlab.com/org/app` |
| `{{ revision }}` | Event (commit SHA) | `abc1234...` |
| `{{target_namespace}}` | BranchEnv | `my-project-dev` |
| `{{target_branch}}` | Event | `main`, `develop` |
| `{{source_branch}}` | Event (PR) | `feature/xxx` |
| `{{image_tag}}` | Console 生成 | `20260722-v1.0-abc1234` |
| `{{ git_auth_secret }}` | PAC 自动创建 | `pac-gitauth-xxxxx` |
| `{{ pull_request_number }}` | Event | `42` |
| `{{ sender }}` | Event | `jzy99` |
| `{{ repo_owner }}` | URL | `kube-do` |
| `{{ repo_name }}` | URL | `my-app` |
| `{{ body.* }}` | Webhook payload | `body.pull_request.html_url` |
| `{{ headers.* }}` | HTTP headers | `headers.x-github-event` |
| `{{cel: ...}}` | CEL 表达式 | `{{cel: body.action == 'opened' ? 'run' : 'skip'}}` |

---

## Provider 接口

所有 Git 提供商实现统一接口：

```go
type Interface interface {
    Detect(req, payload) (isProvider, isACL, event, config, error)
    Validate(ctx, event) error
    SetClient(ctx, event) error
    GetCommitInfo(ctx, event) error
    GetFileInsideRepo(ctx, event, path, branch) (string, error)
    GetTektonDir(ctx, event, path, provenance) (string, error)
    CreateStatus(ctx, event, statusOpts) error
    GetExistingCommitStatus(ctx, event, statusOpts) ([]Status, error)
    CreateToken(ctx, url, event) (string, error)
    CheckPolicyAllowing(ctx, event, policy) (bool, string, error)
    IsAllowedOwnersFile(ctx, event) (bool, string, error)
    GetTaskURI(ctx, event, uri) (bool, string, error)
    GetFiles(ctx, event) ([]string, error)
    GetPullRequest(ctx, event) (*Event, error)
    IsWayneInvalid(ctx, event) (bool, error)
}
```

### Provider 探测顺序

```
adapter.listener.detectProvider():
  GitHub → Gitea/Forgejo → Bitbucket Cloud → GitLab → Gitee
```

| Provider | 探测 Header | 认证方式 |
|----------|------------|---------|
| GitHub | `X-GitHub-Event` | GitHub App (JWT+Installation) / PAT |
| GitLab | `X-Gitlab-Event` | Personal Access Token |
| Gitea/Forgejo | `X-Gitea-Event` / `X-Forgejo-Event` | Token |
| Bitbucket Cloud | `X-Event-Key` | 用户名 + 应用密码 |
| Bitbucket DC | `X-Event-Key` + URL | Token |
| Gitee | `X-Gitee-Token` | Token |

---

## 安全机制

### 认证链

```
Webhook 到达
  ├─ Provider.Detect() → 识别 Provider
  ├─ Provider.Validate() → 验证 Webhook 签名
  ├─ SecretFromRepository.Get() → 读取 Git Token
  ├─ gitclient.SetupAuthenticatedClient() → 设置认证客户端
  │   ├─ GitHub App: JWT + Installation Token
  │   └─ 其他: PAT / Basic Auth
  └─ Event.Provider.Token → 令牌就绪
```

### 授权链

```
policy.IsAllowed():
  ├─ 1. 策略检查 (Settings.Policy.OkToTest / PullRequest)
  │   └─ Provider.CheckPolicyAllowing() (团队/组成员检查)
  └─ 2. OWNERS 文件回退
      └─ Provider.IsAllowedOwnersFile() (OWNERS approvers/reviewers)
```

### Secret 保护

- git-auth Secret: 自动为 PipelineRun 创建，用于 `git-clone` task
- 日志清理: `GetSecretsAttachedToPipelineRun()` → `ReplaceSecretsInText()` → `*****`
- GitHub App Token: 可选作用域限定 (`secret-github-app-token-scoped`)

---

## 并发控制

```
仓库 A (ConcurrencyLimit=3)
  ├─ [R] PipelineRun-1  ← 正在运行
  ├─ [R] PipelineRun-2  ← 正在运行
  ├─ [R] PipelineRun-3  ← 正在运行
  ├─ [Q] PipelineRun-4  ← 排队中
  └─ [Q] PipelineRun-5  ← 排队中

PipelineRun-1 完成 → PipelineRun-4 出队运行
```

实现: `pkg/queue/` — 每个 Repository 一个 `prioritySemaphore` + 优先级队列（最小堆 FIFO）。

---

## 可观测性

### Prometheus 指标

| 指标名 | 类型 | 标签 |
|--------|------|------|
| `pipelines_as_code_pipelinerun_count` | Counter | provider, event, namespace, repository |
| `pipelines_as_code_pipelinerun_duration_seconds_sum` | Counter | namespace, repository, status, reason |
| `pipelines_as_code_running_pipelineruns_count` | Gauge | namespace, repository |
| `pipelines_as_code_git_provider_api_request_count` | Counter | provider, client |

### Kubernetes 事件

PAC 在每个关键操作向 Repository 资源发出 K8s Event：

| 事件类型 | 说明 |
|---------|------|
| `PacNewRepoMatch` | 匹配到仓库 |
| `PacNewEventFromRepo` | 正在处理事件 |
| `PacPolicyDeny` | 策略拒绝 |
| `PacValidationError` | 验证错误 |
| `PacPipelineRunCreation` | PipelineRun 创建成功 |

### OpenTelemetry 追踪

- `SpanWaitDuration` — PipelineRun 创建到开始执行
- `SpanExecuteDuration` — PipelineRun 开始到完成

---

## 创建流程（Console）

```
RepositoryFormPage
  ├─ 表单编辑器 → RepositoryFormSection
  │   ├─ Git URL（自动检测提供商 + 语言 + 可达性）
  │   ├─ DevInfoSection（语言/模板/端口）
  │   └─ AdvancedConfigurations
  │       ├─ ConfigTypeSection（GitHub App / Webhook 选择）
  │       └─ BranchConfigSection（分支→环境映射表）
  └─ YAML 编辑器 → CodeEditorField

提交后执行:
  1. createTokenSecret() → 创建 Opaque Secret
     └─ provider.token + webhook.secret
  2. convertEditFormToRepository() → 构建 Repository CR
  3. k8sCreate(RepositoryModel) → 创建 CR
  4. createRemoteWebhook() → 调用 Git 提供商 API
     ├─ GitHub: POST /repos/{owner}/{repo}/hooks
     ├─ GitLab: POST /projects/{id}/hooks
     └─ Gitee: POST repos/{owner}/{repo}/hooks
  5. initRepositoryFile() → POST PAC Controller
     └─ /manual?init=yes 参数: cluster, namespace, repository, branch, appEnv, webhookSecret
```

### KDO 扩展字段说明

| 字段 | 说明 |
|------|------|
| `spec.branchEnvs[]` | 多分支→多环境映射 |
| `spec.devInfo` | 开发语言/框架/模板/端口 |
| `spec.git_provider` | Git 提供商认证（token + webhook secret） |

### 开发语言自动检测

URL 输入后 Console 检测仓库文件：

| 文件 | 语言 |
|------|------|
| `pom.xml` | java |
| `go.mod` | golang |
| `package.json` | nodejs |
| `requirements.txt` | python |
| `*.csproj` | dotnet |
| `Gemfile` | ruby |
| `composer.json` | php |

---

## Repository 详情页

| 标签页 | 内容 |
|--------|------|
| **详情** | Git URL、Token Secret、Webhook URL/Secret、分支状态表 |
| **YAML** | Repository CRD 只读查看 |
| **PipelineRuns** | 按 label `pipelinesascode.tekton.dev/repository={name}` 过滤 |
| **指标** | 分支级运行统计（成功率、平均耗时、失败数） |

### 路由

| 用途 | 路径 |
|------|------|
| 创建 | `/k8s/ns/{ns}/pipelinesascode.tekton.dev~v1alpha1~Repository/~new/form` |
| 编辑 | `/k8s/ns/{ns}/pipelinesascode.tekton.dev~v1alpha1~Repository/{name}/form` |
| 列表 | `/k8s/ns/{ns}/pipelinesascode.tekton.dev~v1alpha1~Repository` |

---

## KDO 特有改动

| 改动 | 说明 |
|------|------|
| `branchEnvs` | 多分支→多环境映射扩展字段 |
| `devInfo` | 开发语言/框架/模板/端口自动检测 |
| Gitee 支持 | 额外 Git 提供商支持 |
| `kubedo` 模板命名空间 | 模板 ConfigMap 存储在 `kubedo` |
| `initRepositoryFile` | 创建后调用 PAC Controller 初始化 |

---

## 相关页面

- [[kdo-pipelines]]
- [[kdo-pipeline-builder]]
- [[kdo-console]]
- [[kdo-platform-project-management]]
- [[kdo-applications]]

---

_Last updated: 2026-07-22_
