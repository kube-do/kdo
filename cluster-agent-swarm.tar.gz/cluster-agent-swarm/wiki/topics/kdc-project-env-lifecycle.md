---
title: KDC 项目与环境生命周期
tags: [kdc, appproject, appenv, lifecycle, namespace]
---

# KDC 项目与环境生命周期

KDC 通过 **AppProjectController** 和 **AppEnvController** 实现项目和环境的声明式生命周期管理。当用户通过 KDO Console 创建/修改/删除项目或环境时，KDC Controller 自动调和底层 Kubernetes 资源和 Harbor 配置。

---

## AppProject Controller 调和逻辑

```
用户创建 AppProject CR
    │
    ├─→ 1. 创建 Namespace（同名，label: namespace.kube-do.cn/app-project）
    ├─→ 2. 创建 PVC repo-cache（20Gi, RWX，代码仓库缓存）
    ├─→ 3. 创建 ClusterRole + ClusterRoleBinding
    │      （appproject-{name}，赋予项目管理员 CRD 操作权限）
    ├─→ 4. 在项目 Namespace 中创建 5 个 RoleBinding
    │      （project-admin/developer/ops/qa/view → 引用同名 ClusterRole）
    ├─→ 5. 同步 Harbor：创建系统级 Robot 账号
    │      （name: registry，永久有效，所有 project 完全权限）
    ├─→ 6. 创建 Namespace 级 registry Secret
    │      （kubernetes.io/dockerconfigjson，镜像拉取/推送）
    └─→ 7. 级联同步所有子 AppEnv 的 RBAC
```

### 删除流程

```
删除 AppProject CR
    ├─→ Webhook 校验：所有 AppEnv 必须已删除
    └─→ 自动删除项目 Namespace（及其下所有资源）
```

### 命名空间规划

| 命名空间 | 用途 |
|----------|------|
| `kubedo-system` | 系统组件（Console、KDC、Keycloak、Harbor） |
| `{project}` | 项目 Namespace（PVC、RoleBinding、registry Secret） |
| `{project}-{env}` | 环境 Namespace（RoleBinding、Deployment、ImageStream） |

---

## AppEnv Controller 调和逻辑

```
用户创建 AppEnv CR
    │
    ├─→ 1. 创建环境 Namespace（{project}-{env}，OwnerReference → AppProject）
    ├─→ 2. 按环境类型同步 RBAC（在环境 Namespace 中）
    ├─→ 3. 确保 default ServiceAccount 有 developer 权限
    ├─→ 4. 同步 Harbor：创建 Harbor project（{project}-{env}）
    └─→ 5. 创建环境级 registry Secret
```

### 环境类型 → RBAC 映射

| 环境类型 | 拥有权限的角色 |
|---------|---------------|
| **dev** | project-admin + developer + ops + view |
| **test** | project-admin + qa + ops + view |
| **stage** | project-admin + ops + view |
| **prod** | project-admin + ops + view |

所有环境额外创建 `default-sa` RoleBinding（项目 Namespace 的 `default` SA → developer ClusterRole，支持跨环境部署）。

### 删除流程

```
删除 AppEnv CR
    ├─→ 自动删除环境 Namespace
    └─→ 清理 Harbor project（含所有 repository 和 artifact）
```

---

## Harbor 资源映射

| KDC 概念 | Harbor 概念 |
|----------|-------------|
| AppProject | 包含 `registry` Secret |
| AppEnv `{project}-{env}` | Harbor Project（公开） |
| ImageStream | Harbor Repository |
| tag | Harbor Tag / Artifact |

### Robot 账号

- 系统级 Robot 账号 `registry`（密码 `Robot@Registry2022`）
- 对所有 project 有 repository/artifact/tag 完全权限（通配符 `*`）
- 永不过期（Duration: -1）

---

## 5 种预定义角色

| 角色 | 说明 |
|------|------|
| `project-admin` | 项目管理员，管理项目和成员 |
| `developer` | 开发者，拥有 dev 环境读写权限 |
| `ops` | 运维，拥有 stage/prod 环境读写权限 |
| `qa` | 测试，拥有 test 环境读写权限 |
| `view` | 只读，所有环境可见 |

---

## 相关页面

- [[kdc-controller]]
- [[kdo-platform-project-management]]
- [[kdo-rbac-auth]]

---

_Last updated: 2026-07-17_
