---
title: KDO 多集群访问与切换
tags: [kdo, multicluster, kubeconfig, kdo-cluster, cluster]
---

# KDO 多集群访问与切换

KDO 支持多 Kubernetes 集群统一管理。托管集群的权威清单是 KDC 的 `Cluster` CRD（`clusters.kube-do.cn`，集群作用域，API 组 `kube-do.cn/v1`），记录每集群的 API 地址及各组件 URL。

**认证前提**：跨集群访问复用当前 kubeconfig 的凭据，依赖 KDO 统一 OIDC 认证——各集群 apiserver 共享同一 `oidc-issuer-url`，同一 token 在多个集群有效。

---

## 工具：kdo-cluster

`kdo-cluster` 复用默认 kubeconfig（`${KUBECONFIG:-~/.kube/config}`）当前 context 的凭据，仅将 API server 替换为 Cluster CRD 记录的目标集群地址，生成临时 kubeconfig 供访问。脚本位于 `/wto/bin/kdo-cluster`（容器 PATH 已含）。

```bash
kdo-cluster list                      # 列出全部托管集群与 API URL（Cluster CRD 为权威清单）
kdo-cluster use <cluster> [命令...]   # 复用当前凭据 + 目标集群 API URL（insecure）
kdo-cluster reset                     # 清理全部临时 kubeconfig
```

`kdo-cluster` 通过替换 `KUBECONFIG` 生效，适用于**所有读取 KUBECONFIG 的 CLI**（kubectl / oc / helm / tkn / kn / kustomize / argocd / velero 等）；不适用自带独立认证的 CLI（不走 kubeconfig）。

---

## 切换集群流程

### 1. 发现目标集群

```bash
kdo-cluster list
```

输出托管集群与 API URL。目标集群不在列表内时，检查 `kubectl get clusters.kube-do.cn -o yaml`（主集群无 `apiServerURL` 字段属正常，主集群用默认 kubeconfig 访问）。

### 2a. 单次访问（推荐，带命令）

```bash
kdo-cluster use <cluster> kubectl get nodes
kdo-cluster use <cluster> helm ls -A
```

直接在当前 shell 执行，不污染环境。

### 2b. 多次复用（生成临时 kubeconfig）

```bash
kdo-cluster use <cluster>
export KUBECONFIG=/tmp/kdo-cluster/kubeconfig   # 提示中会打印实际路径
kubectl cluster-info
helm ls -A
tkn pipelinerun list -n <ns>
unset KUBECONFIG                                 # 恢复默认
kdo-cluster reset                                # 操作完清理临时文件
```

### 2c. 手工 fallback（kubectl config 直接切 context）

```bash
kubectl config get-contexts
kubectl config use-context <cluster-context>   # 记录原 context，操作后恢复
kubectl config current-context
```

### 3. 记录

将切换的集群、context、操作目的记入 `working/SESSION.md`（Agent 操作原则：多集群先识别目标集群）。

---

## 管理面 API 例外

切换集群只影响**业务资源**访问。以下**平台管理面 API 始终由主集群处理**，只能用默认 `~/.kube/config` 访问，**不能**使用切换后的目标集群 API URL（Console Bridge 网关即按此路由）：

| API | 说明 |
|-----|------|
| `apis/kube-do.cn` | KDC 全部 CRD（`Cluster` / `AppProject` / `AppEnv` / `User` / `Group` / `ImageStream` 等），控制面仅部署在主集群 |
| `apis/helm.openshift.io/v1beta1/helmchartrepositories` | HelmChartRepository（Helm 仓库，集群作用域） |
| `apis/workspace.devfile.io` | Devfile 工作区管理 |

对应 Console `pkg/cluster/cluster.go` 的 `GetClusterProxy`：带目标集群标识的请求默认转发到该集群 proxy，以上路径直接返回主集群 proxy 不转发。

切换集群后如需查询这些资源，显式指定默认 kubeconfig（临时 kubeconfig `/tmp/kdo-cluster/kubeconfig` 指向的是目标集群，不能用于此处）：

```bash
kubectl --kubeconfig ~/.kube/config get clusters.kube-do.cn
kubectl --kubeconfig ~/.kube/config get helmchartrepositories.helm.openshift.io -A
kubectl --kubeconfig ~/.kube/config get devworkspaces.workspace.devfile.io -A
# 或先恢复默认环境
unset KUBECONFIG
kubectl get clusters.kube-do.cn
```

> 判断依据：目标集群（如 k8s1）未部署 KDC 控制面，直接以目标集群 API URL 查询管理面资源会失败/无意义。

---

## 注意事项

- **token 有效前提**：统一 OIDC 认证。若凭据为 X.509 客户端证书，证书受原集群 CA 绑定，目标集群可能拒绝——kdo-cluster 会提示改用 KDO 签发的 token。
- **TLS**：kdo-cluster 对目标集群使用 `--insecure-skip-tls-verify=true`（目标集群证书不在默认 CA 链内）。
- **操作后恢复**：`export KUBECONFIG` 后记得 `unset KUBECONFIG`，并 `kdo-cluster reset` 清理 `/tmp/kdo-cluster`。
- **helm 语义**：`helm ls` 查询的是集群内 release 记录，切到目标集群即查该集群的 release，符合预期。

---

## 相关

- `[[wiki/concepts/kdc-controller]]` — Cluster CRD 定义与字段
- `[[wiki/concepts/kdo-console]]` — Console 多集群代理机制
- `[[wiki/concepts/kdo-rbac-auth]]` — 认证与授权
