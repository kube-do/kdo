---
title: KDO 仓库全生命周期管理（GitOps）
tags: [kdo, pipelines, repository, pac, gitops, webhook, lifecycle]
---

# KDO 仓库全生命周期管理（GitOps）

管理应用的 **Git Repository**（`pipelinesascode.tekton.dev/v1alpha1`）从创建到删除的全生命周期：创建、编辑、Webhook、手动触发、诊断。对应 Console `repositories/` 模块的能力，Agent 通过 `kubectl` 与 Git 操作落地。

> ⚠️ 安全规则：所有 Git Token / webhook secret 绝不回显、不进日志、不入库；创建/删除/生产变更需用户审批。
> 相关页面：[[kdo-pipeline-editing]]（分支流水线文件编辑）、[[kdo-repository-pac]]（Repository CRD 概念与 PAC 数据流）。

---

## ① 定位仓库

```bash
kubectl get repository <name> -n <ns> -o yaml
```

读取：`spec.url`（仓库地址）、`spec.git_provider`（secret/webhook 引用）、`spec.branchEnvs[]`（分支→环境映射）、`spec.devInfo`（语言/框架/模板/端口）。

```bash
# 最新 PipelineRun 名称
kubectl get repository <name> -n <ns> -o jsonpath='{.pipelinerun_status}'
```

---

## ② 创建仓库（6 步）

### 2.1 检测 Git 提供商

按 URL 域名识别（`detectGitType`）：

| 域名 | 提供商 |
|------|--------|
| `github.com` | GitHub |
| `bitbucket.org` | Bitbucket |
| `gitlab.com` | GitLab |
| `gitee.com` | Gitee |
| 其他 | 未知默认 GitLab |

### 2.2 检测开发语言（识别语言→文件映射）

克隆后检查以下文件，首命中即语言（`LANGUAGE_FILE_MAP`）：

| 文件 | 语言 | 文件 | 语言 |
|------|------|------|------|
| `pom.xml` | java | `Gemfile` | ruby |
| `go.mod` | golang | `*.csproj` | dotnet |
| `requirements.txt` | python | `package.json` | nodejs |
| `composer.json` | php | 均无 | java（默认） |

> 切换开发语言后需**删除所有代码分支 `docker/` 与 `kubernetes/` 目录下的文件**才能生效（DevInfoSection 提示）。

### 2.3 创建 Git Token Secret

```bash
kubectl create secret generic <name>-token-<rand> -n <ns> --type=Opaque \
  --from-literal=provider.token=<TOKEN> \
  --from-literal=webhook.secret=<WS> \
  # Bitbucket 另加:
  # --from-literal=webhook.auth=$(echo -n "user:token" | base64)
```

Secret 字段（`createTokenSecret`）：`provider.token`、`webhook.secret`，Bitbucket 额外 `webhook.auth`（`user:token` base64）。

> Token 要求：GitHub=classic token 需 `repo`+`admin:repo_hook` scope；GitLab=`api` scope 且角色 Maintainer/Owner；Bitbucket=App password 需 Read+Write。
> 若已有 Secret：`webhook.secret` 不同时需 patch 更新 `/data/webhook.secret`。

### 2.4 构建 Repository CR

```bash
kubectl apply -f - <<EOF
apiVersion: pipelinesascode.tekton.dev/v1alpha1
kind: Repository
metadata:
  name: <name>
  namespace: <ns>
spec:
  url: <git-url>
  devInfo:
    devLanguage: <java|golang|nodejs|python|...>
    devTemplate: <应用模板>
    gitProvider: <github|gitlab|gitee|bitbucket>
    port: "8080"
  branchEnvs:
    - branchName: develop
      appEnv: dev
      cluster: <cluster>
      prName: <name>-dev-develop.yaml
      prTemplate: <模板名>
      onEvent: ["push"]
      manualTrigger: true
  git_provider:
    url: <https://git-host>
    secret: { name: <secret-name>, key: "provider.token" }
    webhook_secret: { name: <secret-name>, key: "webhook.secret" }
    user: <可选>
    type: <gitProvider>
EOF
```

### 2.5 创建远端 Webhook（git 提供商侧）

webhook URL = PAC Controller 地址（`pac.data['controller-url']`）。各提供商端点：

| 提供商 | 端点 |
|--------|------|
| GitHub | `/api/dev-console/webhooks/github` |
| GitLab | `/api/dev-console/webhooks/gitlab` |
| Bitbucket | `/api/dev-console/webhooks/bitbucket` |
| Gitee | 类似（gitee-service） |

**GitHub App 分支**：若 PAC ConfigMap 有 `app-link` 且提供商为 GitHub，优先走 GitHub App 安装链接，无需 Webhook。

触发事件（Webhook 需订阅）：
- GitHub：Commit comments / Issue comments / Pull request / Pushes
- GitLab & Gitee：Merge request Events + Push Events
- Bitbucket：Repository Push / PR Created / PR Updated / PR Comment Created

### 2.6 初始化流水线文件（可选）

```bash
WS=$(kubectl get secret <secret-name> -n <ns> -o jsonpath='{.data.webhook\.secret}' | base64 -d)
curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?init=yes&cluster=<cluster>&namespace=<ns>&repository=<name>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

> PAC 从 `prTemplate` 模板生成 `.tekton/{prName}.yaml`。仓库添加成功后 Console 指引：建 `.tekton/` 目录 → 建 `push.yaml`（粘贴模板 `yamlData`）→ commit + push → 配置 webhook（若未 autoAttach）。

---

## ③ 编辑仓库

```bash
kubectl edit repository <name> -n <ns>
```

- 修改 `spec.url` / `spec.devInfo` / `spec.git_provider` / `spec.branchEnvs`
- **新增 branchEnv**：patch 后需对新分支调 `/manual?init=yes`（详见 [[kdo-pipeline-editing]] 新增分支环境）
- **删除 branchEnv**：仅移除 CR 条目，git 主分支上的 `.tekton/{prName}.yaml` 需手动删除

---

## ④ 删除仓库

```bash
kubectl delete repository <name> -n <ns>
```

> Console 需输入名称二次确认（`DeleteRepositoryModal`）。删除后 PAC 停止监听该仓库，**git 侧 webhook 与 .tekton 文件需另行清理**（未自动删除）。需用户审批。

---

## ⑤ 手动触发流水线

对应 Console `ManualRunPipelineModal`，**无 `init` 参数**，需 `branchEnvs[].manualTrigger=true`：

```bash
WS=$(kubectl get secret <secret-name> -n <ns> -o jsonpath='{.data.webhook\.secret}' | base64 -d)
curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<ns>&repository=<name>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

成功返回 `status` 与 `message`；PipelineRun 详情查看流水线运行页面。

---

## ⑥ 仓库诊断

| 目标 | 操作 | 说明 |
|------|------|------|
| 可达性 | 匿名 clone / `git ls-remote` | 私有仓库需 Token |
| 分支列表 | `git ls-remote --heads <url>` | 需认证 |
| 文件读取 | `git show HEAD:<path>` / clone 后查看 | 含 `.tekton/` 是否存在 |
| 语言检测 | 见 2.2 文件映射 | |
| 构建类型 | 检测 build 文件（S2I 匹配 builderImages） | `kubedo` ns ImageStream |
| .tekton 存在性 | `git ls-tree -r HEAD --name-only \| grep .tekton` | |

常见 RepoStatus 错误：RateLimitExceeded（限流）/ GitTypeNotDetected（无法识别 git 类型）/ PrivateRepo（需 Token）/ ResourceNotFound（仓库不存在）/ InvalidGitTypeSelected（类型或私有问题）/ AccessTokenError（Secret 无 access token）。

---

## ⑦ 模板与构建镜像查询

| 查询 | 命令 |
|------|------|
| 流水线模板（按语言） | `kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang>` |
| 应用模板（按语言） | `kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devTemplate=<lang>` |
| 运行时模板（回退） | `kubectl get cm -n kubedo -l pipelinesascode.openshift.io/runtime=<java\|go\|nodejs\|python>` |
| 默认模板 | `kubectl get cm <PAC_TEMPLATE_DEFAULT> -n kubedo -o jsonpath='{.data.template}'` |
| 构建镜像 | `kubectl get imagestream -n kubedo`（带 `builder` tag 且非 `hidden`） |

模板 ConfigMap 的 `data.template` 即 PipelineRun YAML（含 `{{ repo_url }}{{ revision }}{{ git_auth_secret }}` 等 PAC 变量）。回退链：runtime 模板 → 默认模板 → 内置 fallback 模板（git-clone + noop-task，含 on-event/on-target-branch/max-keep-runs 注解）。

---

## 速查表

| 项 | 值 |
|----|----|
| PAC Controller | `pipelines-as-code-controller.pipelines-as-code.svc:8080` |
| 初始化端点 | `/manual?init=yes&cluster=&namespace=&repository=&branch=&appEnv=&webhookSecret=` |
| 手动触发端点 | `/manual?cluster=&namespace=&repository=&branch=&appEnv=&webhookSecret=`（无 init） |
| Token Secret | Opaque：`provider.token` + `webhook.secret`（Bitbucket + `webhook.auth`） |
| 模板命名空间 | `kubedo`（PIPELINERUN_TEMPLATE_NAMESPACE） |
| 提交防触发消息 | `Added or updated files for tekton pipeline.`（PacCommitMessage） |
| 可选 Task | `kubedo` 命名空间内 Task（cluster resolver, namespace=kubedo） |

---

_Last updated: 2026-08-11_
