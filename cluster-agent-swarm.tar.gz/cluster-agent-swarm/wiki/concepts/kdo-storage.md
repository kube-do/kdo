---
title: KDO 存储体系
tags: [kdo, storage, pv, pvc, storageclass]
---

# KDO 存储体系

Kubernetes 存储的两级抽象模型: **PV**(集群资源) ↔ **PVC**(用户请求)。

---

## 核心概念

```
StorageClass(存储类) → 动态/静态 → PV(持久卷) → PVC(持久卷声明) → Pod(使用)
                                    ↑
                              VolumeSnapshot(快照)
```

| 概念 | 说明 |
|------|------|
| **PV (PersistentVolume)** | 集群管理员管理的存储资源 |
| **PVC (PersistentVolumeClaim)** | 用户的存储请求 |
| **StorageClass** | 存储类别，定义动态供应参数 |

### StorageClass 参数

| 参数 | 说明 |
|------|------|
| `provisioner` | 存储后端驱动 (如 nfs.csi.k8s.io) |
| `parameters` | 存储后端特定配置 |
| `reclaimPolicy` | Delete(自动删除) / Retain(保留) |
| `volumeBindingMode` | Immediate / WaitForFirstConsumer |
| `allowVolumeExpansion` | 是否允许扩容 |

### KDO 默认 StorageClass

| 名称 | 用途 | 说明 |
|------|------|------|
| `nfs-client` | 开发测试 | 内置 NFS CSI 驱动，开箱即用 |
| `managed-csi` | 生产环境 | 对接云存储后端 |

---

## 供应模式

| 模式 | 说明 |
|------|------|
| **静态供应** | 管理员预先创建 PV，等待 PVC 匹配绑定 |
| **动态供应** | 通过 StorageClass 自动创建 PV，无需手动干预 |

## 访问模式

| 模式 | 说明 |
|------|------|
| **RWO** (ReadWriteOnce) | 单节点读写 |
| **ROX** (ReadOnlyMany) | 多节点只读 |
| **RWX** (ReadWriteMany) | 多节点读写 |

## 回收策略

| 策略 | 说明 |
|------|------|
| **Retain** | 保留数据，需管理员手动回收 |
| **Delete** | PVC 删除后自动删除 PV 和数据 |

---

## 卷快照

```
VolumeSnapshotClass → VolumeSnapshotContent → VolumeSnapshot
```

- 快照独立于 PVC 生命周期
- 支持从快照恢复新 PVC
- 注意事项: 应用一致性、成本与性能、保留策略、跨区域复制

## 存储管理操作

- **创建 PVC**: 指定名称、StorageClass、访问模式、容量
- **扩容 PVC**: 需 StorageClass 开启 `allowVolumeExpansion`，扩容后在 Pod 内执行文件系统扩容
- **卸载/删除 PVC**: 删除 PVC 后数据根据 `reclaimPolicy` 处理
- **创建/恢复快照**: 通过 VolumeSnapshot 创建，从快照恢复新 PVC

## KDC 自动创建 PVC

AppProject Controller 在创建项目时自动创建 **repo-cache** PVC：

| 属性 | 值 |
|------|-----|
| 名称 | `repo-cache` |
| 容量 | 20 Gi |
| 访问模式 | RWX (ReadWriteMany) |
| 位置 | 项目 Namespace |
| 用途 | 代码仓库缓存（Git 克隆/构建缓存） |

---

## 最佳实践

- **多级存储**: 按性能/成本分层 (SSD/HDD/NFS)
- **环境隔离**: 不同环境使用不同 StorageClass
- **配额控制**: 通过 ResourceQuota 限制 PVC 数量和总容量
- **快照策略**: 定期快照，设置保留窗口
- **CSI 驱动升级**: 关注 CSI 驱动版本和兼容性

---

## 相关页面

- [[kdc-controller]]
- [[kdc-project-env-lifecycle]]
- [[kdo-architecture]]
- [[kdo-platform-project-management]]

---

_Last updated: 2026-07-17_
