---
title: KDO 认证与授权
tags: [kdo, rbac, auth, keycloak, oidc]
---

# KDO 认证与授权

KDO 使用 **Keycloak** 作为身份认证中心，基于 **OIDC** 协议，RBAC 进行授权管理。

---

## 访问控制三环节

```
用户请求 → 认证(Authentication) → 授权(Authorization) → 准入控制(Admission)
```

### 认证方式

| 方式 | 说明 |
|------|------|
| **Token** | Bearer Token / ServiceAccount Token |
| **X.509 证书** | kubeconfig 客户端证书 |
| **OIDC** | **KDO 使用** — Keycloak 作为身份提供者 |
| **Webhook** | 外部认证服务 |

### 授权模块

| 模块 | 说明 |
|------|------|
| **Node** | 节点授权 |
| **ABAC** | 基于属性的访问控制 |
| **RBAC** | **主要** — 基于角色的访问控制 |
| **Webhook** | 外部授权服务 |

---

## RBAC 四要素

```
Subject(谁) + API Resource(什么) + Verb(操作) = 权限
```

| 组件 | 作用域 | 说明 |
|------|--------|------|
| **Role** | 命名空间级 | 定义命名空间内资源的权限集合 |
| **ClusterRole** | 集群级 | 定义集群范围资源的权限 |
| **RoleBinding** | 命名空间级 | 将 Role/ClusterRole 绑定到 Subject |
| **ClusterRoleBinding** | 集群级 | 将 ClusterRole 绑定到 Subject |

### Subject 类型

- **User** — 自然人，从 Keycloak 同步
- **Group** — 用户组，从 Keycloak 同步
- **ServiceAccount** — 命名空间限定、轻量级、可移植

---

## KDO 用户管理

- 用户/组信息从 **Keycloak** 同步，KDO 平台只读展示
- 管理员菜单包含: User、Group、ServiceAccount、Role/ClusterRole、RoleBinding/ClusterRoleBinding
- Keycloak 管理功能:
  - **用户管理**: 创建/编辑/删除、密码管理、角色分配、会话管理
  - **组管理**: 创建/编辑/删除、用户与组关联、组角色自动继承
  - **密码策略**: 长度/复杂度/有效期/历史记录/防暴力破解

## KDO 项目角色权限

| 角色 | dev | test | stage | prod |
|------|-----|------|-------|------|
| **项目管理员** | 查看+修改 | 查看+修改 | 查看+修改 | 查看+修改 |
| **开发人员** | 查看+修改 | 查看 | 查看 | 查看 |
| **测试人员** | 查看 | 查看+修改 | 查看 | 查看 |
| **运维人员** | 查看 | 查看 | 查看+修改 | 查看+修改 |

---

## KDC 预定义角色

KDC Controller 定义了 5 种预定义 ClusterRole（`pkg/constants/constants.go`）：

| 角色常量 | 角色名 | 说明 |
|----------|--------|------|
| `project-admin` | project-admin | 项目管理员，管理项目和成员 |
| `developer` | developer | 开发者，dev 环境读写 |
| `ops` | ops | 运维，stage/prod 环境读写 |
| `qa` | qa | 测试，test 环境读写 |
| `view` | view | 只读，所有环境可见 |

### 环境类型 → 角色分配（由 AppEnv Controller 自动调和）

| 环境类型 | 分配的角色 |
|---------|-----------|
| **dev** | project-admin + developer + ops + view |
| **test** | project-admin + qa + ops + view |
| **stage** | project-admin + ops + view |
| **prod** | project-admin + ops + view |

每个环境额外创建 `default-sa` RoleBinding（项目 `default` SA → developer 角色，支持跨环境部署）。

---

## KDC 用户同步

Refer to [[kdc-user-sync]] for:
- **Provider 抽象接口**: Keycloak (gocloak) / Dex (gRPC)
- **双向同步**: KDC CRD ↔ OIDC Provider
- **定时调度**: ClusterController 每 5 分钟同步
- **密码管理**: 通过 `kubedo-system/user-passwords` Secret 管理
- **用户删除级联**: 自动清理 AppProject 成员角色引用

---

## 相关页面

- [[kdc-user-sync]]
- [[kdc-project-env-lifecycle]]
- [[kdo-platform-project-management]]
- [[kdo-architecture]]

---

_Last updated: 2026-07-17_
