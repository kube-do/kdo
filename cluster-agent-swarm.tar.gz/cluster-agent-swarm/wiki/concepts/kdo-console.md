---
title: KDO Console（Bridge）平台架构
tags: [kdo, console, bridge, architecture, frontend]
---

# KDO Console（Bridge）平台架构

> **⚠️ Agent 规则：所有需要用户前往控制台操作的指令，必须拼接完整可点击 URL（`${CONSOLE_BASE}${path}`），不得只说"在控制台操作"。**
> 路由清单见 [[wiki/topics/kdo-console-routes]]，拼接方法见下方 Console URL 拼接章节。

KDO Console 是基于 OpenShift Console（Bridge）改造的 Web 控制台，提供比 `kubectl` 更友好的单页应用管理界面。

---

## 整体架构

```
┌──────────────────────────────────────────────────────┐
│                  前端 SPA（TypeScript + React 18）       │
│  PatternFly 6 / Redux / React Router 6 / i18next      │
│  Webpack 5 + Module Federation（动态插件加载）           │
├──────────────────────────────────────────────────────┤
│              Bridge 服务器（Go HTTP Server）             │
│  认证 → 代理 K8s API → 代理 Thanos/Alertmanager → 插件   │
├──────────────────────────────────────────────────────┤
│              KDC Controller / ks-apiserver              │
├──────────────────────────────────────────────────────┤
│              Kubernetes + 外部服务                        │
└──────────────────────────────────────────────────────┘
```

### Bridge 服务器（Go）

| 层 | 说明 |
|----|------|
| **认证层** | OIDC / OpenShift OAuth / disabled 三种模式，加密 Session Cookie（gorilla/sessions） |
| **代理层** | 反向代理 K8s API（`/api/kubernetes/*`）、Thanos（`/api/prometheus/*`）、Alertmanager（`/api/alertmanager/*`） |
| **API 层** | GraphQL（`/api/graphql`）、Helm（`/api/helm/*`）、OLM（`/api/olm/*`）、插件资产（`/api/plugins/*`） |
| **静态层** | 前端 SPA 静态文件（`/static/*`）、index.html 注入 `window.SERVER_FLAGS` |
| **KDO 扩展** | 用户管理（`/api/console/user`）、密码（`/api/console/password`）、搜索（`/api/console/search`）、Pod 文件（`/api/podfile`）、Logging（`/api/console/logging/*`）、AI 助手（`/api/console/ols/*`） |

### 前端 SPA

| 技术 | 版本/说明 |
|------|----------|
| React | 18+ |
| UI 库 | PatternFly v6（`@patternfly/react-core`） |
| 状态管理 | Redux + redux-thunk，core reducers: observe/UI/features/dashboards |
| 路由 | React Router v6，命名空间感知路由（`/k8s/ns/:ns/:plural`） |
| 国际化 | react-i18next，多语言支持 |
| 构建 | Webpack 5 + Module Federation + SWC |
| 编辑器 | Monaco Editor（YAML 编辑） |

---

## 插件系统

Console 支持动态插件运行时加载，基于 Webpack Module Federation。

### 插件加载流程

```
启动 → PluginStore 初始化 → 加载插件 manifest.json
  → 验证插件名（DNS 子域名格式）→ 注册扩展
  → 注入共享模块（SharedScope）→ 动态渲染
```

### 扩展类型

| 扩展类型 | 数量 | 示例 |
|----------|------|------|
| perspective（视角） | — | Admin / Developer |
| navigation（导航） | 5 种 | href / section / separator 等 |
| page（页面） | 4 种 | route / resource/list 等 |
| action（操作） | 4 种 | resource-provider 等 |
| dashboards（仪表盘） | 14 种 | card / tab / variable 等 |
| topology（拓扑） | 6 种 | data / factory / decorator 等 |
| feature-flags（特性开关） | 3 种 | model / hookProvider 等 |
| model-metadata（CRD 元数据） | — | 颜色/缩写 |
| yaml-template（YAML 模板） | — | 创建资源模板 |
| catalog（目录） | item-type / item-provider | 任务目录 |

### 插件包结构

27 个 Yarn workspace 包，核心 SDK：

| 包 | 用途 |
|----|------|
| `console-dynamic-plugin-sdk` | 外部插件 SDK（类型/工具/钩子/共享模块） |
| `console-plugin-sdk` | 静态插件 SDK（插件解析/代码生成） |
| `console-app` | 核心应用框架（布局/导航/Perspectives/特性标记） |
| `console-shared` | 共享组件、钩子、常量 |

### 后端插件代理

- `PluginsHandler` 反向代理插件服务资产（`/api/plugins/<name>/`）
- 支持 i18n 资源（`/locales/resource.json`）
- 插件代理服务可选授权（`--plugin-proxy` 标志）

---

## 多集群管理

KDO 特有功能，`pkg/cluster/` 包实现：

- 读取 KDC 的 `Cluster` CRD（`kube-do.cn/v1`，集群作用域）发现托管集群，记录每集群 API 地址及各组件 URL
- 每个集群独立 K8s 代理配置、Thanos/Alertmanager 端点、认证
- 多集群 HTTP 客户端管理，基于请求头/参数路由（`/api/kubernetes/*` 按目标集群路由）

---

## 关键 KDO 扩展端点

| 端点 | 方法 | 功能 |
|------|------|------|
| `/api/console/search` | POST | 跨命名空间跨资源全文搜索 |
| `/api/podfile` | GET/POST | Pod 文件上传/下载 |
| `/api/console/logging/` | GET | Logging 服务代理（Loki/Elasticsearch） |
| `/api/console/ols/` | GET | AI 助手代理（Lightspeed/OLS） |
| `/api/console/user` | POST | 用户 CRUD |
| `/api/console/password` | POST | 密码修改 |
| `/api/console/knative-enabled` | GET | Knative Operator 状态 |
| `/api/console/tekton-enabled` | GET | Tekton Operator 状态 |
| `/cli-files/*` | GET | CLI 二进制文件下载 |

---

## Console URL 拼接

详见完整路由清单: [[wiki/topics/kdo-console-routes]]

> **快速获取基础地址**:
> ```bash
> CONSOLE_BASE=$(kubectl get cm -n kubedo-system console -o json | \
>   jq -r '.data["config.yaml"]' | grep consoleBaseAddress | awk '{print $2}')
> # 回退: kubectl get ingress -n kubedo-system console -o jsonpath='{.spec.rules[0].host}'
> ```

---

## 相关页面

- [[kdo-console-usage]]
- [[kdo-console-routes]]
- [[kdo-architecture]]

---

_Last updated: 2026-07-17_
