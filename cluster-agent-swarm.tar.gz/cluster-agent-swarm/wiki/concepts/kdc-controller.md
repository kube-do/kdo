---
title: KDC Controller 架构
tags: [kdc, controller, operator, kubebuilder]
---

# KDC Controller 架构

KDC (Kube-Do Controller) 是 KDO 平台的核心 **Kubernetes Operator**，基于 **Kubebuilder v4** 构建（API 组 `kube-do.cn/v1`），负责自动管理项目、环境、镜像流和用户身份。

---

## 整体架构

```
KDC Controller Manager (Go 1.21 + controller-runtime v0.16.3)
│
├── AppProject Controller  →  Namespace / RBAC / Harbor Project
├── AppEnv Controller      →  环境 Namespace / RBAC / Harbor Project
├── Cluster Controller     →  定时同步 OIDC 用户和组 (5min)
├── User Controller        →  双向同步用户到 Keycloak/Dex
├── Group Controller       →  双向同步组到 Keycloak/Dex
├── ImageStream Controller →  镜像导入 / Skopeo Job / Deployment 触发
├── ImageTag Controller    →  ImageStream → ImageTag 投影
├── ImageStreamLayers      →  层信息轻量索引
│
├── Virtual Resources:
│   ├── ImageStreamImport   →  一次性的镜像导入请求
│   └── ImageStreamMapping  →  一次性的 tag → Image 映射
│
├── Webhooks:
│   ├── AppProject (create/update/delete)
│   ├── AppEnv (create)
│   └── ImageStream (create/update/delete)
│
└── 外部依赖:
    ├── Harbor (REST API via goharbor-client)
    ├── Keycloak (Admin API via gocloak)
    ├── Dex (gRPC API)
    └── Skopeo (Kubernetes Job)
```

## CRD 清单

### 业务资源

| CRD | 作用域 | 说明 |
|-----|--------|------|
| **AppProject** | Cluster | 项目定义（名称、5种角色成员列表） |
| **AppEnv** | Namespaced | 环境定义（类型 dev/test/stage/prod、所属项目） |
| **Cluster** | Cluster | K8s 集群元数据（API地址、各组件 URL） |
| **User** | Cluster | 用户（Email、IM ID、身份提供者标识） |
| **Group** | Cluster | 用户组（用户列表） |

### 镜像资源

| CRD | 作用域 | 说明 |
|-----|--------|------|
| **ImageStream** | Namespaced | 镜像流，映射 tag → 镜像，兼容 OpenShift |
| **Image** | Cluster | 不可变镜像快照（digest、manifest、layers） |
| **ImageStreamTag** | Namespaced | 镜像流标签 `{is}:{tag}` |
| **ImageStreamImage** | Namespaced | 镜像流镜像 `{is}@{digest}` |
| **ImageTag** | Namespaced | ImageStreamTag 完整视图（spec+status+image） |
| **ImageStreamLayers** | Namespaced | 镜像层信息轻量索引 |
| **ImageSignature** | Cluster | 镜像签名 |

### 虚拟资源（仅处理 Create 事件，不持久调和）

| CRD | 说明 |
|-----|------|
| **ImageStreamImport** | 请求导入外部镜像到 ImageStream |
| **ImageStreamMapping** | 直接将 tag 映射到 Image |

---

## 配置源

配置存储于 `kubedo-system` 命名空间的 `console` ConfigMap（key: `config.yaml`），定义 Harbor/Keycloak/Dex 等外部服务连接参数。

## 构建与部署

| 命令 | 说明 |
|------|------|
| `make manifests` | 生成 CRD/RBAC/Webhook 配置 |
| `make build` | 构建二进制 `bin/manager` |
| `make docker-build IMG=...` | 构建镜像 |
| `make deploy IMG=...` | 部署到集群 |

镜像地址: `registry.cn-shenzhen.aliyuncs.com/kubedo/kdc-controller:v202607`

---

## 设计模式

- **延迟初始化**: HarborClient/Provider 在首次 Reconcile 时从 ConfigMap 读取配置
- **Hash 变更检测**: User/Group spec 变更通过 sha256 hash 比对避免不必要的 API 调用
- **OwnerReference 级联**: AppEnv → AppProject（NS 级联）；IST/Image/ISI → ImageStream
- **Finalizer 清理**: User/Group 使用 finalizer 确保 Provider 端资源被清理
- **Scheduled Requeue**: 5min OIDC 同步、15min ImageStream import
- **虚拟资源模式**: ImageStreamImport/Mapping 仅一次性操作

---

## 相关页面

- [[kdc-project-env-lifecycle]]
- [[kdc-image-stream]]
- [[kdc-user-sync]]
- [[kdo-architecture]]

---

_Last updated: 2026-07-17_
