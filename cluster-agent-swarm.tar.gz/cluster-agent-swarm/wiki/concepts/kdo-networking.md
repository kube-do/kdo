---
title: KDO 网络模型
tags: [kdo, networking, service, ingress, networkpolicy]
---

# KDO 网络模型

KDO 基于 Kubernetes 网络模型，默认使用 **Calico** CNI，提供 Service/Ingress/NetworkPolicy 三层网络抽象。

---

## Service 类型

| 类型 | 访问范围 | 说明 |
|------|---------|------|
| **ClusterIP** | 集群内部 | 默认类型，通过虚拟 IP 访问 |
| **NodePort** | 节点 IP + 端口 | 每个节点开放静态端口 |
| **LoadBalancer** | 外部 | 云平台负载均衡器 |
| **ExternalName** | 外部 | 映射到外部主机名(CNAME) |

- DNS 格式: `<服务名>.<命名空间名>.svc.cluster.local`

---

## Ingress

- 基于 Kubernetes Ingress API
- 默认使用 **nginx-ingress** 控制器
- 支持路径、主机名、TLS 配置
- 高级特性通过 annotations 配置

### 表单字段

| 字段 | 说明 |
|------|------|
| 名称 | 路由名称 |
| 路由类型 | IngressClass |
| 主机名 | 域名 |
| 路径 | URL 路径 |
| 服务 | 目标 Service |
| 目标端口 | Service 端口 |

---

## NetworkPolicy

- 基于标签选择器: `podSelector` / `namespaceSelector` / `ipBlock`
- 支持方向: Ingress(入站) / Egress(出站) / Both
- **白名单机制**: 默认允许所有 → 创建策略后选择性限制
- 作用于 **Pod IP**，非 Service IP；端口是容器端口

### 典型场景

| 场景 | 策略 |
|------|------|
| 三层架构隔离 | Web → App → DB 逐层开放 |
| 多租户隔离 | 按 namespace 标签隔离 |
| 出口限制 | 仅允许访问特定外部 IP |

### 最佳实践

- **最小权限**: 只开放必须的入站和出站流量
- **默认拒绝**: 创建默认拒绝策略，再添加白名单
- **命名空间隔离**: 按环境/团队划分命名空间
- **版本控制**: NetworkPolicy YAML 纳入 Git 管理
- **定期审计**: 检查策略有效性和冗余规则

---

## 相关页面

- [[kdo-architecture]]
- [[kdo-platform-project-management]]
- [[kdo-rbac-auth]]

---

_Last updated: 2026-07-17_
