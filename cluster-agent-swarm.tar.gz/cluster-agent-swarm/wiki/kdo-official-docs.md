---
title: KDO 官方文档知识索引
description: 将常见问题映射到 KDO 官方文档解决方案
created: 2026-07-17
author: desk
tags: [docs, kdo, 官方文档, 知识库]
---

# KDO 官方文档知识索引

## 使用原则

1. **遇到问题先查文档**：所有 KDO 相关问题，优先参考官方文档解决方案
2. **文档优先级**：官方文档 > 本地知识库 > 通用 Kubernetes 文档
3. **引用格式**：`[文档标题](https://docs.kube-do.cn/路径)`
4. **组合使用**：先文档定位问题，再结合本地排查工具深入分析

## 本地知识库索引

> 基于实际集群分析的详细配置和故障排查指南

| 页面 | 内容 |
|------|------|
| [[wiki/platform/kdo-cluster-architecture]] | 平台架构全景图、组件依赖关系 |
| [[wiki/platform/kdo-component-details]] | 各组件详细配置、端口、存储 |
| [[wiki/platform/kdo-templates]] | 应用模板、流水线模板详解 |
| [[wiki/platform/kdo-monitoring-setup]] | 监控栈配置、Prometheus/Grafana/Alertmanager |
| [[wiki/platform/kdo-logging-setup]] | 日志栈配置、Loki/MinIO |
| [[wiki/platform/kdo-networking]] | 网络拓扑、Calico/Ingress/Service |
| [[wiki/platform/kdo-storage-setup]] | 存储方案、NFS/Harbor |
| [[wiki/platform/kdo-security]] | 安全配置、Keycloak/Cert-Manager |
| [[wiki/platform/kdo-troubleshooting-patterns]] | 常见故障模式与排查路径 |

## 文档分类索引

### 一、应用管理

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| 创建/管理应用 | [应用管理](https://docs.kube-do.cn/docs/dev/applications/) | 通过「应用」菜单操作 |
| 工作负载管理 | [工作负载](https://docs.kube-do.cn/docs/dev/workloads/) | Deployment/StatefulSet/DaemonSet 操作 |
| 配置管理 | [配置管理](https://docs.kube-do.cn/docs/dev/configurations/) | ConfigMap/Secret 管理 |
| 存储管理 | [存储](https://docs.kube-do.cn/docs/dev/network-stroage/) | PV/PVC/StorageClass 配置 |
| 网络管理 | [网络](https://docs.kube-do.cn/docs/dev/network-stroage/) | Service/Ingress/路由配置 |

### 二、工作负载操作

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| 创建 PDB | [创建 PodDisruptionBudget](https://docs.kube-do.cn/docs/admin/workloads/pdb/) | 配置最小可用/最大不可用 |
| 创建 HPA | [创建 HPA](https://docs.kube-do.cn/docs/workload-actions/hpa/) | 配置扩缩容策略 |
| 挂载存储卷 | [存储](https://docs.kube-do.cn/docs/admin/storage/) | PVC 挂载配置 |
| 更新策略 | [更新策略](https://docs.kube-do.cn/docs/workload-actions/edit-update-strategy/) | 滚动更新/重建 |
| 资源限制 | [资源](https://docs.kube-do.cn/docs/workload-actions/edit-resource-limits/) | CPU/Memory requests/limits |
| 健康检查 | [健康检查](https://docs.kube-do.cn/docs/workload-actions/edit-health-checks/) | Readiness/Liveness/Startup Probe |
| Pod 副本数 | [Pod 副本数](https://docs.kube-do.cn/docs/workload-actions/edit-pod-count/) | 扩缩容操作 |

### 三、DevOps 流水线

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| 创建流水线 | [创建流水线](https://docs.kube-do.cn/docs/dev/applications/pipelines/) | Pipeline 配置 |
| 应用部署 | [应用部署](https://docs.kube-do.cn/docs/devops/app-deploy/) | Java/Python/Golang/NodeJS/PHP/.NetCore |
| GitFlow | [GitFlow](https://docs.kube-do.cn/docs/devops/gitflow/) | Git 工作流配置 |
| 持续交付 | [持续交付](https://docs.kube-do.cn/docs/devops/continuous/) | CD 流程 |
| 项目管理 | [项目管理](https://docs.kube-do.cn/docs/devops/project-manage/) | DevOps 项目配置 |
| 流水线管理 | [流水线](https://docs.kube-do.cn/docs/devops/introduce/) | Tekton 流水线配置 |
| 流水线执行记录 | [执行记录](https://docs.kube-do.cn/docs/admin/pipeline/pipelineruns/) | 查看历史运行 |

### 四、可观测性

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| 监控配置 | [监控](https://docs.kube-do.cn/docs/observability/monitoring/) | Prometheus + Grafana |
| 日志查询 | [日志](https://docs.kube-do.cn/docs/observability/logging/) | Loki 日志系统 |
| 事件查询 | [事件](https://docs.kube-do.cn/docs/observability/events/) | 事件记录 |

### 五、RBAC 与用户管理

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| 认证配置 | [认证](https://docs.kube-do.cn/docs/rbac/) | OIDC/Keycloak/LDAP |
| 授权配置 | [授权](https://docs.kube-do.cn/docs/rbac/) | Role/ClusterRole |
| RBAC 概念 | [RBAC](https://docs.kube-do.cn/docs/rbac/) | 权限模型 |
| 用户管理 | [用户管理](https://docs.kube-do.cn/docs/user/) | 创建/管理用户 |
| 用户组管理 | [用户组管理](https://docs.kube-do.cn/docs/user/) | 组权限配置 |
| ServiceAccount | [ServiceAccount](https://docs.kube-do.cn/docs/rbac/) | 服务账户 |
| Role/ClusterRole | [Role/ClusterRole](https://docs.kube-do.cn/docs/rbac/) | 角色定义 |
| RoleBinding | [RoleBinding](https://docs.kube-do.cn/docs/rbac/) | 角色绑定 |

### 六、运维管理

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| 节点管理 | [节点](https://docs.kube-do.cn/docs/admin/management/nodes/) | 节点状态/操作 |
| 命名空间管理 | [命名空间](https://docs.kube-do.cn/docs/admin/management/namespaces/) | Namespace 生命周期 |
| 配额管理 | [配额](https://docs.kube-do.cn/docs/admin/management/resourcequotas/) | ResourceQuota |
| 限制范围 | [限制范围](https://docs.kube-do.cn/docs/admin/management/limitranges/) | LimitRange |
| CRD 管理 | [CRD](https://docs.kube-do.cn/docs/admin/management/customresourcedefinitions/) | 自定义资源 |

### 七、云终端

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| CloudShell 使用 | [CloudShell](https://docs.kube-do.cn/docs/terminal/) | 云端终端 |
| LocalShell 使用 | [LocalShell](https://docs.kube-do.cn/docs/terminal/) | 本地终端 |
| 终端配置 | [终端](https://docs.kube-do.cn/docs/terminal/) | 运维终端 |

### 八、AI 助手

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| AI 助手使用 | [AI 助手](https://docs.kube-do.cn/docs/aiops/) | Ollama 模型集成 |
| AIOps | [AIOps](https://docs.kube-do.cn/docs/aiops/) | AI 运维 |

### 九、应用商店

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| OperatorHub | [OperatorHub](https://docs.kube-do.cn/docs/admin/application-management/operator-hub/) | 应用商店 |
| Operator 管理 | [Operator 管理](https://docs.kube-do.cn/docs/admin/application-management/operators/) | 安装/更新/卸载 |

### 十、集群配置

| 问题场景 | 官方文档 | 解决方案要点 |
|---------|----------|-------------|
| KDO Web 控制台 | [KDO Web 控制台](https://docs.kube-do.cn/docs/config/console/) | 平台配置 |
| 平台安装 | [安装](https://docs.kube-do.cn/docs/install/kdo/) | 部署指南 |

## 常见问题快速解决

### 问题 1：Pod 无法创建
1. 检查 [资源限制](https://docs.kube-do.cn/docs/workload-actions/edit-resource-limits/) 配置
2. 检查 [ResourceQuota](https://docs.kube-do.cn/docs/admin/management/resourcequotas/)
3. 检查节点状态：[节点管理](https://docs.kube-do.cn/docs/admin/management/nodes/)

### 问题 2：流水线运行失败
1. 检查 [项目管理](https://docs.kube-do.cn/docs/devops/project-manage/) 配置
2. 检查 [Tekton 流水线](https://docs.kube-do.cn/docs/devops/introduce/) 配置
3. 查看 [执行记录](https://docs.kube-do.cn/docs/admin/pipeline/pipelineruns/)

### 问题 3：权限不足
1. 检查 [RBAC 配置](https://docs.kube-do.cn/docs/rbac/)
2. 检查 [用户管理](https://docs.kube-do.cn/docs/user/)
3. 检查 [RoleBinding](https://docs.kube-do.cn/docs/rbac/)

### 问题 4：存储挂载失败
1. 检查 [存储管理](https://docs.kube-do.cn/docs/dev/network-stroage/)
2. 检查 [PVC 状态](https://docs.kube-do.cn/docs/admin/storage/)
3. 检查 StorageClass 配置

### 问题 5：监控数据缺失
1. 检查 [监控配置](https://docs.kube-do.cn/docs/observability/monitoring/)
2. 检查 Prometheus 服务状态
3. 检查 Grafana 数据源配置

## 工具命令参考

### 通用 kubectl 命令

```bash
# 查看资源
kubectl get pods -n <namespace>
kubectl get svc -n <namespace>
kubectl get pv,pvc

# 调试
kubectl describe pod <pod-name> -n <namespace>
kubectl logs <pod-name> -n <namespace>
kubectl exec -it <pod-name> -n <namespace> -- /bin/sh

# 配置管理
kubectl get configmap <name> -n <namespace> -o yaml
kubectl get secret <name> -n <namespace> -o yaml
```

## 监控指标查询

### Prometheus 常用查询

```promql
# Pod CPU 使用率
sum(rate(container_cpu_usage_seconds_total{namespace="<ns>"}[5m])) by (pod)

# Pod 内存使用率
sum(container_memory_working_set_bytes{namespace="<ns>"}) by (pod)

# Pod 网络流量
sum(rate(container_network_receive_bytes_total{namespace="<ns>"}[5m])) by (pod)
```

### Grafana 仪表板

```bash
# 访问 Grafana
kubectl port-forward svc/grafana 3000:3000 -n monitoring

# 常用仪表板
# - Kubernetes Cluster Monitoring
# - Pod Monitoring
# - Node Exporter
```

## 日志查询

### Loki 日志查询

```logql
# 查询命名空间日志
{namespace="<ns>"}

# 查询 Pod 日志
{namespace="<ns>", pod="<pod-name>"}

# 按关键字过滤
{namespace="<ns>"} |= "error"
{namespace="<ns>"} |= "timeout"
```

## 事件查询

```bash
# 查看命名空间事件
kubectl get events -n <namespace> --sort-by='.lastTimestamp'

# 查看特定资源事件
kubectl describe <resource-type> <resource-name> -n <namespace>
```

## 联系支持

- **官方文档**：https://docs.kube-do.cn/
- **技术支持**：platform-k8s@cestc.com
- **内部文档**：https://docs.kube-do.cn/docs/install/kdo/
