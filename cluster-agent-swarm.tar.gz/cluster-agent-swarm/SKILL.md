---
name: cluster-agent-swarm
description: >
  Kubernetes & OpenShift Platform Agent Swarm — A coordinated multi-agent system for
  cluster operations. Includes Orchestrator (Jarvis), Cluster Ops (Atlas), GitOps (Flow),
  Security (Shield), Observability (Pulse), Artifacts (Cache), and Developer Experience (Desk).
  Pure instruction-based skill — no executable scripts.
metadata:
  author: kcns008
  version: 2.1.0
  agent_name: Swarm
  agent_role: Platform Agent Swarm (All Agents)
  session_key: "agent:platform:swarm"
  heartbeat: "*/5 * * * *"
  platforms:
    - kdo
    - openshift
    - kubernetes
    - eks
    - aks
    - gke
    - rosa
    - aro
  install_type: "instruction-only"
  always: false
  model_invocation: false
  requires:
    env:
      - KUBECONFIG
    binaries:
      - kubectl
      - git
      - curl
      - python3
  optional_binaries:
    - oc
    - helm
    - jq
    - yq
    - kdo-cluster
  optional_env:
    - AWS_ACCESS_KEY_ID
    - AWS_SECRET_ACCESS_KEY
    - AZURE_CLIENT_ID
    - AZURE_CLIENT_SECRET
    - AZURE_TENANT_ID
    - GOOGLE_APPLICATION_CREDENTIALS
  credentials:
    - kubeconfig: "KUBECONFIG path or ~/.kube/config for cluster access"
    - cloud: "Optional cloud provider credentials for managed clusters (AWS/Azure/GCP)"
    - registry: "Optional container registry credentials for image operations"
---

# Kubernetes Agent Swarm — 平台运维

一个面向 KDO 平台的多智能体运维系统。七个专业智能体以协调群体方式协同工作，兼容多种 Kubernetes 发行版作为底层集群。

## 平台定位

### KDO、OpenShift 与 Kubernetes 的关系

本技能是 **KDO 平台** 的专用运维技能。理解三者关系是正确使用本技能的前提：

```
┌──────────────────────────────────────────────────────────────┐
│                       KDO 平台 (上层)                          │
│  Console (React) /  KDC Controller(Go)                    │
│  项目-环境模型 · 多租户 RBAC · 流水线 · 观测 · AIOps           │
├──────────────────────────────────────────────────────────────┤
│                    Kubernetes 集群 (底层)                       │
│  ┌──────────┐ ┌───────────┐ ┌───────────┐ ┌───────────────┐  │
│  │ OpenShift │ │    EKS    │ │    AKS    │ │ vanilla K8s   │  │
│  │ OCP/ROSA/ │ │  (AWS)    │ │  (Azure)  │ │ (自建/RKE/... )│  │
│  │   ARO     │ │           │ │           │ │               │  │
│  └──────────┘ └───────────┘ └───────────┘ └───────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

| 层级             | 定位      | 职责                                                                | 示例组件                                                    |
|----------------|---------|-------------------------------------------------------------------|---------------------------------------------------------|
| **KDO**        | 平台层     | 业务抽象、用户界面、项目-环境-应用模型、多租户 RBAC、流水线、AI 助手                           | Console, ks-apiserver, KDC Controller, Keycloak, Harbor |
| **OpenShift**  | K8s 发行版 | 增强的 Kubernetes，提供 SCC、Route、BuildConfig、ImageStream、MachineConfig | OpenShift OCP, ROSA, ARO                                |
| **Kubernetes** | 容器编排    | Pod、Service、Deployment、RBAC 等核心资源生命周期管理                           | 任意 CNCF 认证发行版                                           |

### 关键区别

| 场景           | 使用工具                                    | 说明                                     |
|--------------|-----------------------------------------|----------------------------------------|
| 创建项目/环境/应用   | **KDO 控制台** 或 KDC CRD                   | 通过 KDO 模型操作，而非直接 `kubectl create ns`   |
| 集群节点/升级/etcd | `kubectl` / `oc` / 云 CLI                | 底层集群操作，非 KDO 范畴                        |
| 用户/角色/权限管理   | **KDO 控制台** → Keycloak → KDC → K8s RBAC | KDO 封装了 Role/ClusterRole 的自动映射         |
| Pod 调试/日志查看  | `kubectl` + 控制台                         | 两者互补，kubectl 更灵活，控制台更直观                |
| 流水线/PAC      | **KDO 控制台** / Tekton CRD                | KDO 提供了 Pipeline 可视化构建器和 Repository CR |
| 监控/告警        | Prometheus/Grafana（通用） + 控制台集成          | KDO 将观测面板嵌入控制台统一展示                     |

### Agent 操作原则

1. **KDO 概念优先** — 命名空间命名为 `{project}-{env}`（如 `abc-dev`），不是随意命名
2. **文档优先** — KDO 平台问题先查 https://docs.kube-do.cn/，通用 K8s 问题才用社区文档
3. **区分变更层级** — 平台层变更（项目/流水线）走控制台/KDC，集群层变更（节点/存储）走 kubectl
4. **兼容所有底层集群** — 指令给出适配多种 K8s 发行版的命令（如同时提供 `kubectl` 和 `oc` 版本）
5. **Console URL 必须完整** — 需要用户访问控制台时，必须拼接完整可点击 URL（`${CONSOLE_BASE}${path}`），不得只说"在控制台操作"
6. **创建/更新资源后回传 Console URL** — 任何通过 kubectl/helm/GitOps 创建或更新资源后，必须一并返回该资源的 Console 详情页 URL（格式：`${CONSOLE_BASE}/k8s/ns/${ns}/${plural}/${name}`）；如为集群范围资源则为 `${CONSOLE_BASE}/k8s/cluster/${plural}/${name}`
7. **多集群先识别目标集群，优先用 `kdo-cluster`** — 用户要求访问/切换其他集群时，即使当前 kubeconfig 没有该集群的 context，也**不得**断言"无凭据无法访问"。正确流程：① `kdo-cluster list` 确认集群在 Cluster CRD 中；② `kdo-cluster use <cluster> <命令>` 直接尝试（复用当前 OIDC token，跨集群有效）；③ 仅当 use 真实报错（认证失败/网络不通）时，才回退控制台或请求 kubeconfig。操作后在 SESSION.md 记录集群归属。**例外**：管理面 API（`kube-do.cn/*`、`helm.openshift.io` 的 helmchartrepositories、`workspace.devfile.io/*`）始终由主集群处理，切换集群后访问它们必须用 `kubectl --kubeconfig ~/.kube/config`，不能用切换后的目标集群 URL
8. **权限受限直接提示用户** — 所有基于 kubeconfig 的 CLI（`kubectl`/`oc`/`helm`/`tkn`/`kustomize`/`k9s` 等）返回 `Forbidden`/`unauthorized` 等权限错误时，**立即停止尝试其他方式**（不切换 context、不换工具重试、不尝试 RBAC 绕过），直接告知用户「当前登录用户对 <资源> 在 <集群/命名空间> 无权限」，并给出可操作建议（联系项目管理员调整角色、或切换到有权限的集群，可参考 `kdo-cluster list`），完成后在 SESSION.md 记录。

### 多集群访问决策

当用户要求访问/切换集群时，按下述顺序决策，不要凭 kubeconfig 里的 context 数量判断能否访问：

```bash
# 1. 确认目标集群已托管（Cluster CRD 为权威清单，即使本机 kubeconfig 无该集群 context）
kdo-cluster list

# 2. 直接尝试访问目标集群（复用当前 Keycloak OIDC token，server 换为 CRD 记录的 API URL）
kdo-cluster use <cluster> kubectl get nodes
kdo-cluster use <cluster> helm ls -A

# 3. 多次复用：生成临时 kubeconfig（操作后恢复 + 清理）
kdo-cluster use <cluster>
export KUBECONFIG=/tmp/kdo-cluster/kubeconfig
kubectl cluster-info
unset KUBECONFIG
kdo-cluster reset
```

- 只有当 `kdo-cluster use` 输出真实错误（如认证失败、网络不通）时，才认定无法访问，并回退：控制台确认集群状态、请求用户提供 kubeconfig。
- 详细流程、fallback 与注意事项见 `[[wiki/topics/kdo-multicluster-access]]`。

## 运行时要求

| 依赖项          | 必需  | 描述                              |
|--------------|-----|---------------------------------|
| `kubectl`    | ✅ 是 | Kubernetes CLI — 必须在 PATH 中     |
| `oc`         | 可选  | OpenShift CLI — OCP/ROSA/ARO 需要 |
| `helm`       | 可选  | 用于 GitOps 智能体的 Helm 操作          |
| `kn`         | 可选  | 用于管理 Knative Serving 和 Eventing |
| `tkn`        | 可选  | 用于 Tekton 流水线                   |
| `jq`         | 可选  | 用于 JSON 输出解析                    |
| `KUBECONFIG` | ✅ 是 | 通过环境变量或 `~/.kube/config` 访问集群   |

可选的云 CLI（`aws`、`az`、`gcloud`、`rosa`）— 仅在托管集群操作时需要。

## 安装

```bash
clawhub install kubernetes
```

或者安装单个智能体：

```bash
clawhub install orchestrator
clawhub install cluster-ops
clawhub install gitops
clawhub install security
clawhub install observability
clawhub install artifacts
clawhub install developer-experience
```

## 群体成员列表

| 智能体                  | 代号     | 领域                       |
|----------------------|--------|--------------------------|
| Orchestrator         | Jarvis | 任务路由、协调、站会               |
| Cluster Ops          | Atlas  | 集群生命周期、节点、升级             |
| GitOps               | Flow   | ArgoCD、Helm、Kustomize、部署 |
| Security             | Shield | RBAC、策略、密钥、扫描            |
| Observability        | Pulse  | 指标、日志、告警、事件              |
| Artifacts            | Cache  | 镜像仓库、SBOM、升级、CVE         |
| Developer Experience | Desk   | 命名空间、新用户引导、支持            |

## 工作原理

这是一个**仅指令模式**技能。智能体接收 markdown 指令，描述要运行的命令以及如何解释输出结果。不包含可执行脚本——智能体将指令转化为操作，使用宿主机上已安装的 CLI 工具执行。

### 会话初始化

使用群体前，先建立集群上下文：

```bash
# Verify access
kubectl cluster-info
kubectl get nodes

# For OpenShift
oc status
```

### 智能体通信

智能体通过共享任务评论中的 @提及 进行通信：

```
@Shield Please review the RBAC for payment-service v3.2 before I sync.
@Pulse Is the CPU spike related to the deployment or external traffic?
@Atlas The staging cluster needs 2 more worker nodes.
```

### 上报路径

1. 智能体检测到问题
2. 智能体在护栏内尝试解决
3. 如果受阻 → @提及 另一个智能体或上报人工
4. P1 事件 → 自动通知所有相关智能体

## 心跳计划

```
*/5  * * * *  Atlas, Pulse, Shield     (fast response: incidents, alerts, CVEs)
*/10 * * * *  Flow, Cache              (scheduled: deploys, promotions)
*/15 * * * *  Desk, Orchestrator       (batch: onboarding, standups)
```

## 智能体能力

### 智能体可以执行

- 读取集群状态（`kubectl get`、`kubectl describe`、`oc get`）
- 通过 GitOps 部署（`argocd app sync`、Flux 同步）
- 创建文档和报告
- 调查和分类事件
- 配置标准资源（命名空间、配额、RBAC）
- 运行健康检查和审计
- 查询指标和日志

### 智能体不可执行（需人工介入）

- 删除生产资源
- 修改集群范围策略
- 不通过轮换工作流直接修改密钥
- 执行不可逆的集群升级
- 审批生产部署（可准备，由人工审批）

## 核心原则

- **角色优于泛化** — 每个智能体有明确的领域
- **文件优于记忆** — 只有文件在会话间持久化
- **人在回路中** — 关键操作需要审批
- **护栏优于自由** — 定义智能体可以和不可以做的事
- **审计一切** — 每个操作都记录
- **文档优先** — KDO 平台问题首先参考官方文档解决方案

## 文档优先策略

> 所有 KDO 平台问题，优先参考官方文档：https://docs.kube-do.cn/

### 问题解决流程

1. **文档定位** — 检查 [[wiki/kdo-official-docs]] 索引，找到对应文档链接
2. **文档学习** — 阅读官方文档中的解决方案
3. **本地验证** — 结合本地排查工具验证问题
4. **方案实施** — 按文档步骤解决问题
5. **知识积累** — 将经验记录到 TROUBLESHOOTING.md

### 文档引用格式

在提供解决方案时，始终附带官方文档链接：

```
## 解决方案

**官方文档**：[文档标题](https://docs.kube-do.cn/路径)

### 排查步骤
1. 步骤一
2. 步骤二
3. 步骤三

### 参考命令
```bash
kubectl ...
```
```

### 常见问题文档映射

| 问题类型 | 首选文档 |
|---------|----------|
| 应用管理 | [应用管理](https://docs.kube-do.cn/docs/dev/applications/) |
| 工作负载 | [工作负载](https://docs.kube-do.cn/docs/dev/workloads/) |
| 流水线 | [流水线](https://docs.kube-do.cn/docs/admin/pipeline/) |
| RBAC | [RBAC](https://docs.kube-do.cn/docs/rbac/) |
| 存储 | [存储](https://docs.kube-do.cn/docs/dev/network-stroage/) |
| 监控 | [监控](https://docs.kube-do.cn/docs/observability/monitoring/) |
| 终端 | [终端](https://docs.kube-do.cn/docs/terminal/) |

## 平台知识

> 智能体应理解底层 KDO 平台模型。Wiki 包含从官方文档和分析中提取的全面知识。

### 概念

| 页面 | 描述 |
|------|-------------|
| [[wiki/concepts/kdo-architecture]] | 平台组件、控制台前端架构、插件系统 |
| [[wiki/concepts/kdo-rbac-auth]] | Keycloak/OIDC 认证、RBAC 模型、用户/组/SA 管理 |
| [[wiki/concepts/kdo-storage]] | PV/PVC/StorageClass、NFS 默认存储、快照 |
| [[wiki/concepts/kdo-networking]] | Service 类型、Ingress、NetworkPolicy、Calico CNI |
| [[wiki/concepts/kdc-controller]] | **KDC Operator**：Kubebuilder v4、CRD 清单、控制器职责 |
| [[wiki/concepts/kdo-console]] | **控制台**：Bridge 服务器、React SPA、动态插件、多集群 |

### 平台详细配置 (基于实际集群分析)

| 页面 | 描述 |
|------|-------------|
| [[wiki/platform/kdo-cluster-architecture]] | 平台架构全景图、组件依赖关系 |
| [[wiki/platform/kdo-component-details]] | 各组件详细配置、端口、存储 |
| [[wiki/platform/kdo-templates]] | 应用模板、流水线模板详解 |
| [[wiki/platform/kdo-monitoring-setup]] | 监控栈配置、Prometheus/Grafana/Alertmanager |
| [[wiki/platform/kdo-logging-setup]] | 日志栈配置、Loki/MinIO |
| [[wiki/platform/kdo-networking]] | 网络拓扑、Calico/Ingress/Service |
| [[wiki/platform/kdo-storage-setup]] | 存储方案、NFS/Harbor |
| [[wiki/platform/kdo-security]] | 安全配置、Keycloak/Cert-Manager |
| [[wiki/platform/kdo-troubleshooting-patterns]] | 常见故障模式与排查路径 |

### 主题

| 页面 | 描述 |
|------|-------------|
| [[wiki/topics/kdo-platform-project-management]] | 项目/环境/应用模型、权限 |
| [[wiki/topics/kdo-pipelines]] | Tekton、Pipelines as Code、Repository CR、Git 提供商 |
| [[wiki/topics/kdo-observability]] | Prometheus/Grafana/Loki、日志、告警、事件。**日志告警 = Loki 日志告警，只能通过 Grafana 管理** |
| [[wiki/topics/kdo-applications]] | 5 种创建方法、Helm、镜像构建、ConfigMap/Secret |
| [[wiki/topics/kdo-workloads]] | Deployment/StatefulSet/DaemonSet/CronJob/HPA/PDB |
| [[wiki/topics/kdo-aiops]] | Lightspeed 架构、LLM 提供商、RAG、MCP 工具 |
| [[wiki/topics/kdo-terminal]] | CloudShell/LocalShell、Hermes Agent 集成 |
| [[wiki/topics/kdo-installation]] | 系统要求、安装步骤、默认账户 |
| [[wiki/topics/kdc-project-env-lifecycle]] | **KDC**：AppProject/AppEnv Controller 协调、RBAC 自动分配 |
| [[wiki/topics/kdc-image-stream]] | **KDC**：ImageStream 导入模式、Skopeo 同步、ImageChange 触发器 |
| [[wiki/topics/kdc-user-sync]] | **KDC**：Keycloak/Dex 提供商、双向用户同步 |
| [[wiki/topics/kdo-console-usage]] | **控制台**：导航布局、页面清单、常用操作 |
| [[wiki/topics/kdo-pipeline-builder]] | **控制台**：流水线 DAG 编辑器、节点类型、Form↔YAML 同步 |
| [[wiki/topics/kdo-repository-pac]] | **控制台**：Repository CRD、PAC、分支↔环境映射、模板 |
| [[wiki/topics/kdo-pipeline-editing]] | **GitOps**：分支流水线 YAML 编辑、Git 认证、PacCommitMessage、push 触发 |
| [[wiki/topics/kdo-repository-lifecycle]] | **GitOps**：仓库全生命周期、创建/删除/Webhook、手动触发、诊断 |
| [[wiki/topics/eclipse-che]] | **CDE**：Eclipse Che 架构、工作区、存储、CheCluster CR、故障排查 |
| [[wiki/topics/kdo-multicluster-access]] | **集群**：多集群访问与切换、kubeconfig 管理 |
| [[wiki/topics/kdo-console-routes]] | **控制台**：KDO Console 路由清单 |

### 更新页面

| 页面 | 新增内容 |
|------|-----------|
| [[wiki/concepts/kdo-architecture]] | KDC Controller + Console 扩展架构 |
| [[wiki/concepts/kdo-rbac-auth]] | 5 个预定义角色、环境→角色映射 |
| [[wiki/concepts/kdo-storage]] | 自动创建的 `repo-cache` PVC（20Gi RWX） |
| [[wiki/topics/kdo-platform-project-management]] | KDC 自动创建资源表 |
| [[wiki/topics/kdo-applications]] | ImageChange 触发机制 |
| [[wiki/topics/kdo-pipelines]] | 控制台 PipelineRun 可视化、ApprovalTask、Triggers UI、KDO 变更 |
| [[wiki/topics/kdo-terminal]] | 控制台 Web Terminal 代理集成 |
| [[wiki/topics/kdo-aiops]] | Lightspeed 控制台插件集成 |
| [[wiki/topics/eclipse-che]] | Eclipse Che CDE 平台体系 |
| [[wiki/topics/kdo-pipeline-editing]] | GitOps 分支流水线编辑工作流 |
| [[wiki/topics/kdo-repository-lifecycle]] | 仓库全生命周期操作手册 |

## Eclipse Che 运维

> Che 是 K8s 原生的 CDE 平台。Che 安装在同一集群时，各部门命名空间由 Che 自动创建和管理。

| Agent | 职责 |
|-------|------|
| **Desk** | 工作区管理、用户命名空间、devfile 咨询、工作区故障排查 |
| **Atlas** | Che 组件健康检查（Che Server/Gateway/Operator Pod）、CheCluster CR 状态 |
| **Shield** | OIDC 认证审计、工作区命名空间 RBAC 检查 |
| **Flow** | Git OAuth 配置、OIDC 提供商对接 |

### 常用运维命令

```bash
# Che 组件状态
kubectl get all -n <che-ns>
kubectl get checluster -n <che-ns> -o yaml

# 工作区管理
kubectl get devworkspaces --all-namespaces
kubectl patch devworkspace <name> -n <ns> --type=merge -p '{"spec":{"started":false}}'

# 用户命名空间 / PVC
kubectl get ns -l app.kubernetes.io/part-of=che.eclipse.org
kubectl get pvc --all-namespaces -l app.kubernetes.io/part-of=che.eclipse.org
```

### Git 认证

不在 OAuth 支持列表的 Git 服务（Gitee、自建 GitLab 等），在工作区命名空间创建带标签的 Secret 即可自动注入凭据:

```bash
kubectl create secret generic <name> -n <user-ns> \
  --from-literal=credentials=$(echo -n "https://oauth2:<PAT>@<git-host>" | base64 -w0)
kubectl label secret <name> -n <user-ns> \
  controller.devfile.io/git-credential=true \
  controller.devfile.io/watch-secret=true
kubectl annotate secret <name> -n <user-ns> \
  controller.devfile.io/mount-path=/.git-credentials \
  controller.devfile.io/mount-as=file \
  che.eclipse.org/automount-workspace-secret=true \
  che.eclipse.org/git-credential=true \
  che.eclipse.org/scm-url=https://<git-host>
```

### 故障排查

| 现象                   | 排查方向                                  |
|----------------------|---------------------------------------|
| 工作区无法启动              | PVC / 镜像拉取 / ResourceQuota / Ingress  |
| Gateway 503          | 工作区 Pod 是否 Running、Gateway 日志         |
| 工作区自动停止              | 检查 `secondsOfInactivityBeforeIdling`  |
| OIDC 认证失败            | 检查 `identityProviderURL`、OAuth client |
| DevWorkspace CR 创建失败 | Webhook 日志、Operator 日志                |

详细知识见 [[wiki/topics/eclipse-che]]（架构/配置/工作区/存储/安全）。

## 流水线编辑（GitOps）

> 编辑应用分支流水线的唯一规范路径：**克隆仓库 → 改 `.tekton/*.yaml` → push → PAC 自动触发**。禁止 `kubectl apply` 直接改 PipelineRun CR（绕过 git 溯源）。详细知识见 [[wiki/topics/kdo-pipeline-editing]]。

| Agent | 职责 |
|-------|------|
| **Desk** | 克隆仓库、编辑 `.tekton/` YAML、提交推送、文件命名推导、校验（完整工作流见 developer-experience §11） |
| **Shield** | Token 安全、push 前审批、操作审计 |
| **Flow** | GitOps 一致性审查（与 ArgoCD 部署配置对齐） |

### 7 步速查

```bash
# ① 定位 Repository（读 url / secret.name / branchEnvs / devInfo）
kubectl get repository <name> -n <ns> -o yaml

# ② 取 Git Token（不可回显！）
TOKEN=$(kubectl get secret <secret.name> -n <ns> -o jsonpath='{.data.provider\.token}' | base64 -d)

# ③ 克隆
git clone "https://oauth2:${TOKEN}@<host>/<owner>/<repo>.git" && cd <repo>

# ④ 定位文件：.tekton/{app}-{env}-{sanitize(branch)}.yaml
ls .tekton/

# ⑤ 编辑 YAML：可选 Task 来自 kubedo 命名空间（cluster resolver, namespace=kubedo）
kubectl get tasks -n kubedo

# ⑥ 校验
python3 -c "import yaml; yaml.safe_load(open('.tekton/xxx.yaml')); print('OK')"
kubectl apply --dry-run=client -f .tekton/xxx.yaml

# ⑦ 提交（必须用 PacCommitMessage，否则再次触发流水线）并推送（需审批）
git commit -m "Added or updated files for tekton pipeline."
git push origin <branch>
```

### 安全要点

- **commit message 必须是** `Added or updated files for tekton pipeline.`（防止 push 后再次触发流水线）
- **可选 Task = `kubedo` 命名空间内的 Task**，引用格式：`{resolver:'cluster', params:[{name:'kind',value:'task'},{name:'name',value:<task>},{name:'namespace',value:'kubedo'}]}`
- Token 不回显、不进日志、不入库；push 前用户审批
- 手动触发：POST `http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=&namespace=&repository=&branch=&appEnv=&webhookSecret=`（需 `manualTrigger=true`）

### 新增分支环境（agent 引导三选）

```bash
# ① 列出选项让用户选择（分支 / 部署环境 / 流水线模板）
git clone <url> && git branch -r
kubectl get appenv -n <ns> -o name
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang> -o name
# ② patch Repository CR 加 branchEnv（manualTrigger 默认 true）
# ③ 触发初始化生成 .tekton 文件（或纯 GitOps：克隆→生成→PacCommitMessage 提交→push）
curl -X POST ".../manual?init=yes&cluster=&namespace=&repository=&branch=&appEnv=&webhookSecret="
# 注意：会立即触发一次流水线；生产需审批
```

### 删除分支环境

```bash
# ① 列出 branchEnvs 确认目标
kubectl get repository <name> -n <ns> -o jsonpath='{.spec.branchEnvs}' | yq -P
# ② patch Repository CR 移除条目（与 Console 一致：仅移除 CR 条目）
# ③ 手动删除 git 主分支 .tekton/{prName}.yaml（克隆→git rm→PacCommitMessage 提交→push，需审批）
```

## 仓库生命周期（GitOps）

> 管理 Git Repository（`pipelinesascode.tekton.dev/v1alpha1`）的创建/编辑/删除/Webhook/手动触发。详细知识见 [[wiki/topics/kdo-repository-lifecycle]]。

| Agent | 职责 |
|-------|------|
| **Desk** | 创建/编辑 Repository CR、Webhook、删除、语言/模板检测、诊断（完整工作流见 developer-experience §8） |
| **Shield** | Token 安全、创建/删除/生产变更审批 |
| **Flow** | GitOps 一致性审查（与 ArgoCD 部署配置对齐） |

### 速查

```bash
# 创建：检测提供商 → 建 Token Secret（provider.token+webhook.secret）→ apply Repository CR → 创建远端 webhook → 可选 init
# 提供商按域名：github.com / gitlab.com / bitbucket.org / gitee.com
# 语言检测文件：pom.xml→java, go.mod→golang, package.json→nodejs, requirements.txt→python

# 手动触发（需 manualTrigger=true；无 init 参数）
WS=$(kubectl get secret <secret> -n <ns> -o jsonpath='{.data.webhook\.secret}' | base64 -d)
curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=&namespace=&repository=&branch=&appEnv=&webhookSecret=${WS}"

# 初始化流水线文件（创建时，含 init=yes）
curl -X POST ".../manual?init=yes&cluster=&namespace=&repository=&branch=&appEnv=&webhookSecret="

# 删除仓库（需审批）：kubectl delete repository <name> -n <ns>
# 注意：删除不清理 git 侧 webhook 与 .tekton 文件
```

### 安全要点

- **Token Secret**：Opaque，`provider.token` + `webhook.secret`（Bitbucket 加 `webhook.auth`=user:token base64）
- 创建/删除/生产变更需审批；GitHub 优先走 GitHub App（`pac.data['app-link']`）
- 切换 devLanguage 需删 `docker/` 与 `kubernetes/` 目录文件

## 文件结构

```
cluster-agent-swarm/
├── SKILL.md                    # This file — combined swarm
├── AGENTS.md                   # Swarm configuration and protocols
├── QUICKREF.md                 # Pre-operation checks and escalation
├── index.md                    # Wiki page catalog
├── agents/AGENTS.md            # Agent roster and capabilities
├── skills/
│   ├── orchestrator/SKILL.md   # Jarvis — task routing
│   ├── cluster-ops/SKILL.md    # Atlas — cluster operations
│   ├── gitops/SKILL.md         # Flow — GitOps
│   ├── security/SKILL.md       # Shield — security
│   ├── observability/SKILL.md  # Pulse — monitoring
│   ├── artifacts/SKILL.md      # Cache — artifacts
│   └── developer-experience/SKILL.md  # Desk — DevEx
├── memory/MEMORY.md            # Long-term agent memory
├── working/WORKING.md          # Session progress
├── incidents/INCIDENTS.md      # Active incidents
├── troubleshooting/TROUBLESHOOTING.md  # Known issues
├── wiki/                       # Wiki knowledge base
└── logs/LOGS.md                # Action audit trail
```

## 详细智能体文档

每个智能体的完整能力、角色定位和工作流指令，请参见各自的 SKILL.md 文件。
