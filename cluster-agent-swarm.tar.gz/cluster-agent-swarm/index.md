# Wiki Index

Catalog of all wiki pages, organized by category.

## Entities

> People, organizations, projects, products

## Concepts

> Ideas, theories, frameworks, methods

- [[wiki/concepts/kdo-architecture|KDO 平台架构]] — 平台组件、Console 前端架构、插件系统、技术栈
- [[wiki/concepts/kdo-rbac-auth|KDO 认证与授权]] — Keycloak/OIDC、RBAC 四要素、用户/组/SA 管理
- [[wiki/concepts/kdo-storage|KDO 存储体系]] — PV/PVC/StorageClass、NFS 默认存储、快照体系
- [[wiki/concepts/kdo-networking|KDO 网络模型]] — Service、Ingress、NetworkPolicy、Calico CNI
- [[wiki/concepts/kdc-controller|KDC Controller 架构]] — Kubebuilder Operator、CRD 清单、Controller 职责、外部依赖
- [[wiki/concepts/kdo-console|KDO Console 平台架构]] — Bridge 服务器、前端 SPA、动态插件系统、多集群管理

## Topics

> Subject areas and themes

- [[wiki/topics/kdo-platform-project-management|KDO 平台项目管理]] — 项目、环境、应用的模型与成员权限
- [[wiki/topics/kdo-pipelines|KDO CI/CD 流水线]] — Tekton、Pipelines as Code、Repository CR、Git 提供商集成
- [[wiki/topics/eclipse-che|Eclipse Che 云开发平台]] — CDE 架构、CheCluster CR、工作区管理、安全与故障排查
- [[wiki/topics/kdo-observability|KDO 观测平台]] — Prometheus/Grafana/Loki、日志、告警、事件；日志告警 = Loki 日志告警，只能通过 Grafana 管理
- [[wiki/topics/kdo-applications|KDO 应用管理]] — 5 种创建方式、Helm、镜像构建、ConfigMap/Secret
- [[wiki/topics/kdo-workloads|KDO 工作负载]] — Deployment/StatefulSet/DaemonSet/CronJob/HPA/PDB
- [[wiki/topics/kdo-aiops|KDO AIOps 智能助手]] — Lightspeed 六层架构、LLM 提供商、RAG、MCP 工具
- [[wiki/topics/kdo-terminal|KDO 终端与 CLI]] — CloudShell/LocalShell、Hermes Agent 集成
- [[wiki/topics/kdo-installation|KDO 安装与配置]] — 系统要求、安装步骤、默认账号
- [[wiki/topics/kdc-project-env-lifecycle|KDC 项目与环境生命周期]] — AppProject/AppEnv Controller 调和逻辑、RBAC 自动分配
- [[wiki/topics/kdc-image-stream|KDC 镜像流系统]] — ImageStream 导入模式、Skopeo Job 同步、ImageChange 触发
- [[wiki/topics/kdc-user-sync|KDC 用户身份同步]] — Keycloak/Dex Provider 抽象、双向同步流程
- [[wiki/topics/kdo-console-usage|KDO 控制台使用指南]] — 导航布局、页面清单、常见操作
- [[wiki/topics/kdo-console-routes|KDO Console 路由清单]] — Console 全部前端路由
- [[wiki/topics/kdo-multicluster-access|KDO 多集群访问]] — 多集群接入、切换与 kubeconfig 管理
- [[wiki/topics/kdo-pipeline-builder|KDO Pipeline 可视化构建器]] — DAG 编辑器、节点类型、Form↔YAML 同步
- [[wiki/topics/kdo-repository-pac|KDO Repository PAC]] — 应用 Git 仓库管理、分支环境映射、模板系统
- [[wiki/topics/kdo-pipeline-editing|KDO 分支流水线编辑 (GitOps)]] — 克隆改 .tekton 推 push、Git 认证、PacCommitMessage、kubedo Task
- [[wiki/topics/kdo-repository-lifecycle|KDO 仓库全生命周期管理 (GitOps)]] — 创建/编辑/删除仓库、Webhook、手动触发、语言检测、模板查询

## Sources

> Summaries of ingested source documents

## Comparisons & Analyses

> Side-by-sides, syntheses, explorations

---

_Last updated: 2026-08-11_
