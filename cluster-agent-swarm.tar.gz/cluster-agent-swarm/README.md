# Kubernetes Agent Swarm

一个用于 Kubernetes 和 OpenShift 平台运维的协调多智能体系统。七个专业智能体以群体方式协同工作。

## 智能体

| 智能体 | 代号 | 领域 |
|-------|-----------|--------|
| Orchestrator | Jarvis | 任务路由、协调、每日站会 |
| Cluster Ops | Atlas | 集群生命周期、节点、升级、etcd |
| GitOps | Flow | ArgoCD、Helm、Kustomize、部署 |
| Security | Shield | RBAC、策略、密钥、CVE 扫描 |
| Observability | Pulse | 指标、日志、告警、事件响应 |
| Artifacts | Cache | 镜像仓库、SBOM、镜像升级 |
| Developer Experience | Desk | 命名空间配置、新用户引导 |

## 安装

```bash
clawhub install kubernetes
```

## 工作原理

**仅指令模式** — 不包含可执行脚本。每个智能体接收 markdown 指令，描述要运行的 kubectl/oc 命令以及如何解释输出结果。实际工作由宿主机上已安装的 CLI 工具完成。

## 前提条件

- `kubectl`（必需）
- `oc`（可选，用于 OpenShift）
- `helm`（可选，用于 GitOps 智能体）
- `KUBECONFIG` 集群访问权限

## 架构

```
cluster-agent-swarm/
├── SKILL.md                          # Root — combined swarm
├── AGENTS.md                         # Swarm protocols
├── QUICKREF.md                       # Pre-op checks
├── index.md                          # Wiki catalog
├── agents/AGENTS.md                  # Agent roster
├── skills/
│   ├── orchestrator/SKILL.md         # Jarvis
│   ├── cluster-ops/SKILL.md          # Atlas
│   ├── gitops/SKILL.md               # Flow
│   ├── security/SKILL.md             # Shield
│   ├── observability/SKILL.md        # Pulse
│   ├── artifacts/SKILL.md            # Cache
│   └── developer-experience/SKILL.md # Desk
├── memory/MEMORY.md                  # Long-term memory
├── working/WORKING.md                # Session progress
├── incidents/INCIDENTS.md            # Active incidents
├── troubleshooting/TROUBLESHOOTING.md
├── wiki/                             # Knowledge base
└── logs/LOGS.md                      # Audit trail
```

## 安全规范

- 生产环境变更需要人工审批
- 破坏性操作需要明确确认
- 所有操作均记录到审计追踪
- 建议使用最小权限服务账号

## 许可证

MIT
