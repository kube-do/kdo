# INCIDENTS.md — 生产事件日志

> 记录所有生产级故障、问题和险情。需要严重性分类。

---

## 最近事件：无记录

---

## 严重性分类

| 级别 | 定义 | 响应时间 |
|-------|------------|---------------|
| `CRITICAL` | 生产环境宕机、数据丢失风险、安全漏洞 | 立即升级 |
| `HIGH` | 主要功能受影响、性能下降 | < 15 分钟 |
| `MEDIUM` | 轻微影响、有替代方案 | < 1 小时 |
| `LOW` | 外观问题、文档、轻微不便 | 下一个工作日 |

---

## 模板：记录新事件

```
## Incident: <标题>

### Severity: LOW | MEDIUM | HIGH | CRITICAL

### Detected: <ISO 8601 时间戳>

### Description:
<发生了什么>

### Impact:
<受影响的系统、用户、服务>

### Root Cause:
<技术根本原因>

### Resolution:
<解决步骤>

### Follow-up Actions:
- [ ] <操作> - @<负责人> - <截止日期>
- [ ] <操作> - @<负责人> - <截止日期>

### Lessons Learned:
<可改进的地方>

### Related Logs:
<LOGS.md 条目链接>
```

---

## 事件分类

| 分类 | 示例 |
|----------|----------|
| `CLUSTER_FAILURE` | 节点宕机、API Server 中断、etcd 问题 |
| `DEPLOYMENT_FAILURE` | GitOps 同步失败、Helm 失败 |
| `SECURITY_INCIDENT` | 未授权访问、CVE、策略违规 |
| `PERFORMANCE_DEGRADATION` | 高延迟、资源耗尽 |
| `DATA_LOSS` | 备份失败、数据损坏 |
| `AUTOMATION_FAILURE` | 技能/脚本错误 |
| `CONFIGURATION_DRIFT` | 意外的状态变更 |

---

## 升级触发条件

满足以下条件时自动创建事件：

1. **集群可用性 < 99.9%**
2. **检测到安全策略违反**
3. **生产环境部署失败**
4. **数据完整性疑虑**
5. **Agent 在 3 次尝试内无法解决**
6. **请求人工审批但被拒绝**
7. **任何生产资源删除操作**

---

## 事件后要求

1. 在 24 小时内记录到 INCIDENTS.md
2. 如果是新类型问题，创建 TROUBLESHOOTING.md 条目
3. 更新 MEMORY.md 记录经验教训
4. 分配后续操作及负责人
5. 如果严重性为 HIGH 或 CRITICAL，安排事件复盘
