# AGENTS.md — 群体配置与协议

## 概述

这是一个用于 Kubernetes/Kdo/OpenShift 平台运维的**多智能体群体**。七个智能体协同工作，每个都有明确的领域和角色定位。

## 智能体协议

### 通信

- 智能体通过共享任务上下文中的 @提及 进行通信
- 评论任务 → 自动订阅该线程
- 被 @提及 → 自动订阅
- 一旦订阅 → 在心跳时接收所有后续评论

### 协调

1. Orchestrator（Jarvis）将任务路由到合适的智能体
2. 智能体在其领域护栏内执行
3. 跨领域问题 → @提及 相关智能体
4. P1 事件 → 自动通知所有相关智能体

### 文件结构约定

```
skills/<agent-name>/
├── SKILL.md       # Agent personality, capabilities, workflows
└── (no scripts)   # Instruction-only — no executable code
```

### 工作流模式

#### 任务路由（Orchestrator）

- 分析传入请求
- 匹配到智能体领域
- 附带上下文进行路由
- 跟踪完成情况

#### 每日站会（Orchestrator）

- 汇总所有智能体状态
- 总结集群健康、部署、事件
- 标记需要人工关注的事项

#### SLA 监控（Orchestrator）

- 跟踪任务分配以来的时间
- 接近 SLA 阈值时发出告警
- 超限后上报人工

#### 技能改进（Orchestrator）

- 监控智能体日志中的错误和低效
- 建议对 SKILL.md 文件的改进
- 创建 PR 供人工审查

## 环境检测

在操作之前，检测集群平台：

```bash
# Check if OpenShift
kubectl api-resources | grep openshift

# Check if EKS
kubectl get nodes -o jsonpath='{.items[0].metadata.labels}' | grep eks

# Check if AKS  
kubectl get nodes -o jsonpath='{.items[0].metadata.labels}' | grep aks

# Check if GKE
kubectl get nodes -o jsonpath='{.items[0].metadata.labels}' | grep gke
```

## 共享上下文文件

| 文件 | 用途 |
|------|---------|
| `working/WORKING.md` | 当前会话进度 |
| `logs/LOGS.md` | 操作审计追踪 |
| `memory/MEMORY.md` | 长期经验总结 |
| `incidents/INCIDENTS.md` | 活跃事件 |
| `troubleshooting/TROUBLESHOOTING.md` | 已知问题与解决方案 |
| `wiki/` | 平台知识库 |
| `wiki/kdo-official-docs.md` | KDO 官方文档索引 |
| `wiki/platform/` | 基于实际集群分析的详细配置 |

## 安全规则

- **生产环境变更**：始终需要人工审批
- **破坏性操作**：未经明确确认不得执行
- **凭证访问**：使用最小权限服务账号
- **审计追踪**：每个操作记录到 LOGS.md
- **回滚计划**：始终在变更前准备回滚方案
