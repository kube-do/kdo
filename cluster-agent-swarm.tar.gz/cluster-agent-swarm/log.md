# Wiki Log

Chronological record of all wiki activity.

Format: `## [YYYY-MM-DD] type | Title`

Types: `ingest` | `query` | `lint` | `create` | `update`

---

## [2026-07-17] create | KDO 平台项目管理

Created wiki page documenting KDO platform project management model, including project/environment/application relationships, member roles and permissions across environments (dev/test/stage/prod), namespace mapping conventions, and environment replication capabilities.

Reference: [[wiki/topics/kdo-platform-project-management]]

## [2026-07-17] ingest | KDO 平台知识全面导入

Imported comprehensive KDO platform knowledge from official documentation and my-note analysis notes. Created 12 wiki pages covering architecture, RBAC/auth, storage, networking, pipelines, observability, applications, workloads, AIOps, terminal, installation, and project management. Updated all 7 agent SKILL.md files with cross-references.

New pages:
- [[wiki/concepts/kdo-architecture]]
- [[wiki/concepts/kdo-rbac-auth]]
- [[wiki/concepts/kdo-storage]]
- [[wiki/concepts/kdo-networking]]
- [[wiki/topics/kdo-pipelines]]
- [[wiki/topics/kdo-observability]]
- [[wiki/topics/kdo-applications]]
- [[wiki/topics/kdo-workloads]]
- [[wiki/topics/kdo-aiops]]
- [[wiki/topics/kdo-terminal]]
- [[wiki/topics/kdo-installation]]
- [[wiki/topics/kdo-platform-project-management]]

## [2026-07-17] ingest | KDC Controller 知识导入

Imported KDC (Kube-Do Controller) knowledge from source code analysis. Created 4 new wiki pages covering Controller architecture, project/environment lifecycle, image stream system, and user sync. Updated 5 existing wiki pages with KDC implementation details.

New pages:
- [[wiki/concepts/kdc-controller]]
- [[wiki/topics/kdc-project-env-lifecycle]]
- [[wiki/topics/kdc-image-stream]]
- [[wiki/topics/kdc-user-sync]]

## [2026-07-17] ingest | KDO Console 知识导入

Imported KDO Console (OpenShift Bridge fork) knowledge from source code analysis. Created 4 new wiki pages covering Console architecture, console usage, pipeline DAG builder, and Repository PAC. Updated 4 existing wiki pages with Console implementation details.

New pages:
- [[wiki/concepts/kdo-console]]
- [[wiki/topics/kdo-console-usage]]
- [[wiki/topics/kdo-pipeline-builder]]
- [[wiki/topics/kdo-repository-pac]]

## [2026-08-11] create | GitOps 流水线编辑与仓库生命周期

Created two GitOps wiki pages based on Console `repositories/` module source analysis. Updated SKILL.md with two new chapters (流水线编辑、仓库生命周期), fixed agent responsibility assignment (Desk executes, Shield approves), unified PAC Controller port 8080, and synchronized sub-skill references.

New pages:
- [[wiki/topics/kdo-pipeline-editing]]
- [[wiki/topics/kdo-repository-lifecycle]]

_Last updated: 2026-08-11_
