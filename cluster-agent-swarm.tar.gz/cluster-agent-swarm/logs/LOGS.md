# LOGS.md — Agent 操作审计追踪

> 将每个 agent 操作追加到此文件中。格式：最新的在前。

---

## 2026-02-24T00:00:00Z — 初始设置

### Agent: system-initialization
### 操作：创建日志记录基础设施
### 原因：启用持久化 agent 内存和审计追踪，用于 swarm 操作
### 目标：memory/、logs/、incidents/、troubleshooting/ 目录
### 结果：成功
### 下一步操作：开始正常的 agent 日志记录操作

---

## 模板：记录新操作

```
## [时间戳 UTC]

### Agent: <agent-name>
### Action: <执行的操作>
### Reason: <原因>
### Target: <文件/系统/资源>
### Result: SUCCESS | FAILURE | PARTIAL | BLOCKED
### Next Action: <计划下一步>
```

---

## 日志分类

| 分类 | 何时记录 |
|----------|-------------|
| `CLUSTER_ACTION` | 执行任何 kubectl/oc 命令 |
| `SKILL_EXECUTION` | 运行技能脚本 |
| `SKILL_IMPROVEMENT` | 识别到需要更新/改进技能或脚本 |
| `DECISION` | Agent 做出决策 |
| `APPROVAL_NEEDED` | 需要人工审批 |
| `ESCALATION` | 升级给人或其他 agent |
| `ERROR` | 任何错误或失败 |
| `SECURITY` | 安全相关操作 |
| `RELIABILITY` | 可靠性/可用性影响 |

---

## 每条记录必填字段

- **时间戳**：ISO 8601 UTC
- **Agent**：哪个 agent 执行的操作
- **操作**：执行的内容（祈使语气，例如"创建"、"读取"、"批准"）
- **原因**：为什么执行此操作
- **目标**：影响的对象（文件、资源、集群）
- **结果**：SUCCESS | FAILURE | PARTIAL | BLOCKED | PENDING_APPROVAL
- **下一步操作**：接下来要做什么
- **技能改进**（可选）：如果是 SKILL_IMPROVEMENT 分类，添加：
  - `技能`：哪个技能/脚本需要改进
  - `改进类型`：SCRIPT_FIX | NEW_CAPABILITY | REFERENCE_DOC | WORKFLOW_CHANGE
  - `建议修复`：应如何变更的简要描述

---

## SKILL_IMPROVEMENT 日志模板

当 agent 在故障排查或集群活动中发现技能需要改进时：

```
## [时间戳 UTC]

### Agent: <agent-name>
### Action: <执行的操作>
### Reason: <原因>
### Target: <文件/系统/资源>
### Result: SUCCESS | FAILURE | PARTIAL | BLOCKED | PENDING_APPROVAL
### Category: SKILL_IMPROVEMENT
### Skill: <技能名称>/<脚本或文件>
### Improvement Type: SCRIPT_FIX | NEW_CAPABILITY | REFERENCE_DOC | WORKFLOW_CHANGE
### Suggested Fix: <改进描述>
### Next Action: <计划下一步>
```

---

## 安全日志记录要求

涉及以下内容的所有操作必须以 HIGH 优先级记录：
- 密钥处理（读取、写入、轮换）
- RBAC 变更
- 网络策略修改
- 集群范围资源
- 生产环境变更
- 用户凭证操作
- 删除任何资源

---

## 审批工作流日志

```
### 已请求审批
### 审批人：<human-user>
### 请求方：<agent-name>
### 请求类型：DELETE | MODIFY_PROD | RBAC_CHANGE | SECRET_WRITE | CLUSTER_WIDE
### 目标：<resource>
### 状态：PENDING | APPROVED | REJECTED
### 回复：<human response>
```
