# Tekton / PAC / Repository CRD

KDO 的 CI/CD 基于 **Tekton Pipelines** + **Pipelines as Code (PAC)**，分**构建**和**部署**两条链路：

- **构建流水线**定义在应用仓库的 `.tekton/` 目录，Git 是唯一来源，改流水线必须走 Git；
- **部署流水线**定义在集群 ConfigMap `kubedo/pipelinerun-gitops-deploy`，**不在仓库里**，由 controller 在构建成功后自动创建运行（不需要 Git webhook）。

## Tekton 核心资源

| CRD | 说明 |
|-----|------|
| **Task** | 基本工作单元（单个步骤集合） |
| **TaskRun** | Task 的执行实例 |
| **Pipeline** | 多 Task 的执行流程 |
| **PipelineRun** | Pipeline 的执行实例 |
| **Workspaces** | 共享存储 |

> 集群不支持 ClusterTask；Task 存储在 `kubedo` 命名空间，通过 `resolver: cluster` 引用。

## PAC 架构

```
构建：Git Push/PR ──Webhook──▶ PAC Controller ──▶ 解析 .tekton/<prName> ──▶ 创建构建 PipelineRun
                                                              │
                                                     gitops-writeback 任务
                                               改 kubernetes/deploy-*.yaml 的镜像并 push
                                                              │
部署：构建 Succeeded + changed=true ──▶ PAC Controller 直接创建部署 PipelineRun
                                                              └──▶ kubectl apply ──▶ 滚动更新
```

部署这一段**不经过 Git webhook**：controller 从构建运行的 `gitops-writeback` 任务结果里拿到写回提交的 sha，直接创建部署运行，因此 Git 服务器访问不到 PAC 的仓库同样能部署。

三个 Deployment（`pipelines-as-code` 命名空间）：

| 组件 | 职责 | 关键日志 |
|------|------|---------|
| **Controller** | 接收 Git Webhook → 匹配 Repository CR → 解析模板 → 创建构建 PipelineRun；构建成功后创建**部署** PipelineRun | `kubectl logs -n pipelines-as-code -l app=controllers` |
| **Watcher** | 监视 PAC 管理的 PipelineRun 状态 → 报告结果到 Git → 清理旧运行 | `kubectl logs -n pipelines-as-code -l app=watchers` |
| **Webhook** | 准入验证，校验 Repository CR 创建/更新 | `kubectl logs -n pipelines-as-code -l app=webhook` |

> 部署运行不带 `pipelinesascode.tekton.dev/state` 注解，只有 `kube-do.cn/gitops-role=deploy` 等标记，所以 PAC 不会接管它、也不会向 Git 回报它的状态。

## 构建与部署的两条链路

| | 构建 | 部署 |
|---|---|---|
| 定义位置 | 仓库 `.tekton/<prName>` | ConfigMap `kubedo/pipelinerun-gitops-deploy`（可由 `spec.settings.gitops.deployTemplate` 覆盖） |
| 触发源 | Git push/PR 事件（`autoTrigger` 控制），或手动 `/manual` | 构建成功且 `gitops-writeback` 返回 `changed=true` |
| 运行名 | `<prName>` + 随机后缀 | `<repo>-<appEnv>-<branchKey>-deploy-<写回提交 sha 前 8 位>` |
| 部署版本 | — | `revision` = **写回提交的 sha**，与清单在 Git 的版本一一对应 |
| 可重跑 | 手动 `/manual` | 手动 `/manual?...&deploy=yes` |

要点：

- 部署运行是**幂等**的（同名已存在就跳过），同一分支只保留最近 3 份已结束的运行；
- 创建新部署运行前会取消该分支尚未完成的旧部署运行，避免并发 apply；
- 镜像 tag 由构建阶段生成并写进清单，部署只负责把清单 apply 到集群，**不再修改镜像**；
- 清单里的镜像**必须带 tag**。仓库里未经构建的初始清单是不带 tag 的，部署模板会拒绝并提示「先运行构建」。

## 手动触发与鉴权

`/manual` 使用**调用者的 Kubernetes 用户 Token** 做认证和授权，不再有共享令牌：

1. **PAC 认证**：请求必须带 `Authorization: Bearer <token>`。PAC 用该 Token 调 `SelfSubjectReview` 解析用户身份（用于审计），Token 无效/过期返回 `401`。
2. **PAC 授权（SSAR）**：项目命名空间校验 `create pipelineruns.tekton.dev`；非 `init` 请求还校验环境命名空间 `{project}-{appEnv}` 的 `patch deployments.apps`。拒绝返回 `403`。
3. **Console 后端**：浏览器只调用 Console 后端，由后端透传当前登录用户的 Token，并在 Console 侧再做一次 SAR 作为纵深；浏览器不接触 Token 或 `webhook.secret`。
4. **审计**：PAC 记录 `accepted` / `pipeline_created` / `denied` 结构化日志，并在 PipelineRun 上写入 `kube-do.cn/triggered-by`、`trigger-request-id`、`trigger-action` 等注解，便于追溯“谁触发了哪条流水线”。

> 安全边界：授权完全由 SSAR 决定。PAC 的 8080 端口同时承载 Git webhook，不能用 NetworkPolicy 只放行 Console；如需要限制直连，应另行设计 webhook 入站策略。

### 推荐入口：Console 后端

Console 前端（初始化仓库文件、Run Pipeline、发布历史回滚）统一调用：

```http
POST /api/dev-console/pac/manual
Content-Type: application/json

{
  "namespace": "<project>",
  "repository": "<app>",
  "branch": "<branch>",
  "appEnv": "<env>",
  "cluster": "<cluster>",
  "init": false,
  "deploy": false
}
```

服务端会校验：

- 调用者在项目命名空间有 `create pipelineruns.tekton.dev`；
- 调用者在环境命名空间 `{project}-{appEnv}` 有 `patch deployments.apps`（`init` 仅初始化文件时跳过）；
- `branch`/`appEnv` 必须存在于 Repository 的 `branchEnvs`，集群以 Repository 为准。

### 直接调用 PAC（仅调试/CLI）

优先使用 Console；确需在终端直接调用时，使用自己的 Kubernetes Token：

```bash
USER_TOKEN=<your-kubernetes-bearer-token>

curl -X POST \
  -H "Authorization: Bearer ${USER_TOKEN}" \
  "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<project>&repository=<app>&branch=<branch>&appEnv=<env>"
```

- `webhook.secret` 由 PAC 用 ServiceAccount 从 Repository 引用的 Secret 读取，调用方不需要传；
- `init=yes`：生成/刷新仓库流水线文件，**不创建 PipelineRun**；需要构建请在初始化完成后另行手动触发；
- `deploy=yes`：只创建部署运行，不跑构建；
- 两者同时出现时以 `init=yes` 为准；
- `401`：缺少/无效/过期的用户 Token；
- `403`：用户缺少项目或环境权限（响应里会带原因）；
- `503`：PAC 无法访问 API Server 做 SSR/SSAR。

Provider 支持情况：

| Provider | 直接手动触发 | 说明 |
|----------|--------------|------|
| GitHub | 支持 | 已改为 HMAC-SHA256 签名，并修复 `refs/heads/` 分支名回退 |
| Gitea | 支持 | 已补 `X-Gitea-Event-Type` 与 HMAC 签名 |
| GitLab / Gitee / Codeup | 支持 | token 头校验 |
| Bitbucket Cloud / Data Center | 不支持 | `BuildRequest` 未实现，请使用 Git 事件或 Console 支持的方式 |

### PAC 权限与安装检查

新认证链路依赖三组权限，排查 `401/403/503` 时按顺序检查：

1. **PAC controller ServiceAccount**（`pipelines-as-code/pipelines-as-code-controller`）
   - `selfsubjectreviews.authentication.k8s.io`：create（解析用户身份，审计用）
   - `selfsubjectaccessreviews.authorization.k8s.io`：create（项目/环境授权）
   - `secrets`：get（读取 Repository 的 `webhook.secret`）
   - `repositories.pipelinesascode.tekton.dev`：get/list
   - `pipelineruns.tekton.dev`：get/list/create/patch
2. **项目成员（触发用户）**
   - 项目命名空间：`create pipelineruns.tekton.dev`
   - 环境命名空间 `{project}-{appEnv}`：`patch deployments.apps`
   - 项目命名空间：`get repositories.pipelinesascode.tekton.dev`
3. **安装清单**
   - `release.yaml` 的 controller ClusterRole 已显式包含 `selfsubjectreviews` / `selfsubjectaccessreviews` 的 `create`；旧集群若依赖 `system:basic-user` 隐式授权，升级时应确认这两条规则已存在。

验证命令（把 `<user>` 换成触发者用户名，SA 换成 controller）：

```bash
SA=system:serviceaccount:pipelines-as-code:pipelines-as-code-controller
kubectl auth can-i create selfsubjectreviews.authentication.k8s.io --as=$SA
kubectl auth can-i create selfsubjectaccessreviews.authorization.k8s.io --as=$SA
kubectl auth can-i get secrets -n <project> --as=$SA
kubectl auth can-i create pipelineruns.tekton.dev -n <project> --as=<user>
kubectl auth can-i patch deployments.apps -n <project>-<env> --as=<user>
```

升级后清理旧共享令牌（新版已不使用）：

```bash
kubectl -n pipelines-as-code set env deployment/pipelines-as-code-controller PAC_MANUAL_TRIGGER_TOKEN-
kubectl -n pipelines-as-code patch configmap pipelines-as-code-info --type=json \
  -p '[{"op":"remove","path":"/data/manual-trigger-token"}]'
```

建议同时确认 `SYSTEM_NAMESPACE=pipelines-as-code`；新认证代码不依赖它，但 PAC 其他逻辑会用到。

> 权限边界：controller 的 `secrets get` 是集群范围的（PAC 现有设计），不是仅项目命名空间；做最小权限需要平台侧按项目创建 RoleBinding。`/manual` 与 Git webhook 共用 8080，不能用 NetworkPolicy 简单只放行 Console。

## Repository CR — 核心自定义资源

`pipelinesascode.tekton.dev/v1alpha1`，将 Git 仓库与 KDO 应用关联。

```yaml
apiVersion: pipelinesascode.tekton.dev/v1alpha1
kind: Repository
metadata:
  name: my-app
  namespace: my-project          # ★ 必须与 AppProject 同名，不能是 xxx-dev
spec:
  url: https://github.com/org/my-app
  git_provider:
    type: github                 # github/gitlab/gitea/bitbucketcloud/bitbucketserver/gitee（以平台实际支持为准）
    url: https://github.com
    secret:
      name: my-app-token
      key: provider.token
    webhook_secret:
      name: my-app-token
      key: webhook.secret
  branchEnvs:                    # KDO 扩展：分支→环境映射
    - branchName: main
      appEnv: prod               # 部署目标环境 → 命名空间 my-project-prod
      cluster: local-cluster
      prName: .tekton/my-app-prod-main.yaml
      prTemplate: <模板 ConfigMap 名>
      onEvent: ["push"]
      autoTrigger: false         # 构建触发模式：false=手动构建（默认）/ true=push 即构建；不影响部署
  settings:                      # 可选：只用来自定义部署流水线模板
    gitops:
      deployTemplate: pipelinerun-gitops-deploy
  devInfo:                       # KDO 扩展：应用元数据
    devLanguage: golang
    devTemplate: golang-gin
    port: "8080"
    gitProvider: github          # ★ 必须与 spec.git_provider.type 一致
```

关键约束：
- `spec.devInfo.gitProvider` 必须与 `spec.git_provider.type` **一致且同时存在**，否则 PAC 无法探测 Git 提供商。
- `spec.branchEnvs[].appEnv` 决定实际部署到哪个环境 namespace，与 Repository 所在 namespace 无关。

### branchEnvs 字段

| 字段 | 说明 |
|------|------|
| `branchName` | Git 分支名 |
| `appEnv` | 部署环境（dev/test/stage/prod） |
| `cluster` | 目标集群 |
| `prName` | `.tekton/` 文件名 |
| `prTemplate` | 模板 ConfigMap 名称（kubedo 命名空间） |
| `onEvent` | 触发事件 |
| `autoTrigger` | **构建**触发模式：`false`=手动（默认，push 不触发构建）/ `true`=push 即构建。部署不受它影响，构建成功后始终自动部署 |

## .tekton 文件注解体系

`.tekton/` 下的 PipelineRun YAML 通过头部注解控制触发条件：

| 注解 | 示例 | 说明 |
|------|------|------|
| `on-event` | `[push, pull_request]` | 匹配 Git 事件类型 |
| `on-target-branch` | `[main, release-*]` | 匹配目标分支（支持 glob） |
| `on-comment` | `^/test all$` | 匹配 PR 评论（正则） |
| `on-path-change` | `[src/**, *.go]` | 仅这些文件变更时触发 |
| `on-path-change-ignore` | `[docs/**, *.md]` | 忽略这些文件变更 |
| `on-cel-expression` | `event_type == "push" && target_branch == "main"` | CEL 自定义表达式 |
| `max-keep-runs` | `5` | 最大保留运行数 |
| `cancel-in-progress` | `true` | 新推送时取消进行中运行 |

CEL 变量：`event_type`、`body`、`headers`、`target_branch`、`source_branch`、`target_url`、`files`、`sender`、`pull_request_number` 等。

## 模板变量

PAC 在创建 PipelineRun 时替换 `{{ var }}`，值来自 Webhook Payload：

| 变量 | 说明 | 示例 |
|------|------|------|
| `{{ repo_url }}` | 仓库 URL | `https://github.com/org/my-app` |
| `{{ revision }}` | 提交 SHA | `abc1234` |
| `{{ target_namespace }}` | 部署目标命名空间 | `my-project-prod` |
| `{{ target_branch }}` | 目标分支 | `main` |
| `{{ source_branch }}` | 源分支（PR） | `feature/xxx` |
| `{{ image_tag }}` | 镜像 Tag | `20260722-v1.0-abc1234` |
| `{{ git_auth_secret }}` | Git 认证 Secret | `pac-gitauth-xxxxx` |
| `{{ pull_request_number }}` | PR 编号 | `42` |
| `{{ sender }}` | 事件发送者 | `dev1` |
| `{{ body.* }}` | Webhook 负载字段 | `body.pull_request.html_url` |

## kubedo 命名空间的 Task

KDO 预装 22 个 Tekton Task（`kubedo` 命名空间），涵盖 CI/CD 全流程：

```bash
kubectl get task -n kubedo            # 列出全部 Task
kubectl describe task buildah -n kubedo  # 查看参数
```

| 类别 | Task |
|------|------|
| 代码 | `git-clone` |
| 构建 | `golang-build`、`golang-test`、`maven`、`jib-maven`、`npm`、`yarn`、`cargo` |
| 镜像 | `buildah`、`buildpacks`、`kaniko`、`ko`、`s2i`、`skopeo-copy` |
| 写回/部署 | `gitops-writeback`、`kubernetes-actions`、`openshift-client`、`argocd-task-sync-and-wait` |
| 工具 | `kn`、`tkn` |
| 质量/其他 | `sonarqube-scanner`、`remote-ssh-commands` |

> `gitops-writeback` 是构建流水线的最后一个任务：修改 `kubernetes/deploy-<env>-<branchKey>.yaml` 里的镜像与注解并提交推送到仓库。它返回 `changed` 与 `commit-sha` 两个结果，controller 据此决定是否创建部署运行。

**引用格式**（cluster resolver，namespace 必须为 `kubedo`）：

```yaml
taskRef:
  resolver: cluster
  params:
    - name: kind
      value: task
    - name: namespace
      value: kubedo
    - name: name
      value: buildah
```

## 应用模板

模板存储在 `kubedo` 命名空间 ConfigMap 中：

```bash
# 应用模板（按语言）：devfile/Dockerfile/部署清单来源
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devTemplate=<lang>
# 流水线模板（按语言）：prName 对应 PipelineRun 模板来源
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang>
# 回退运行时模板
kubectl get cm -n kubedo -l pipelinesascode.openshift.io/runtime=<java|go|nodejs|python>
# 查看某模板内容
kubectl get cm golang-gin -n kubedo -o yaml
```

模板 ConfigMap 的 `data.template` 即 PipelineRun YAML（含 PAC 变量）。

## PAC 事件

PAC 在每个关键操作向 Repository 资源发出 K8s Event：

| 事件类型 | 说明 |
|---------|------|
| `PacNewRepoMatch` | 匹配到仓库 |
| `PacNewEventFromRepo` | 正在处理事件 |
| `PacPolicyDeny` | 策略拒绝 |
| `PacValidationError` | 验证错误 |
| `PacPipelineRunCreation` | PipelineRun 创建成功 |

```bash
kubectl get events -n <ns> --sort-by='.lastTimestamp' | tail -30
```