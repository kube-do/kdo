# Tekton / PAC / Repository CRD

KDO 的 CI/CD 基于 **Tekton Pipelines** + **Pipelines as Code (PAC)**，分**构建**和**部署**两条链路：

- **构建流水线**定义在应用仓库的 `.tekton/` 目录，Git 是唯一来源，改流水线必须走 Git；
- **部署流水线**定义在集群 ConfigMap `kubedo/pipelinerun-gitops-deploy`，**不在仓库里**，由 controller 在构建成功后自动创建运行（不需要 Git webhook）。

## Tekton 核心资源

| CRD | 说明 |
|-----|------|
| **Task** | 基本工作单元（单个步骤集合） |
| **TaskRun** | Task 的执行实例 |
| **Pipeline** | 多 Task 的执行流程 |
| **PipelineRun** | Pipeline 的执行实例 |
| **Workspaces** | 共享存储 |

> 集群不支持 ClusterTask；Task 存储在 `kubedo` 命名空间，通过 `resolver: cluster` 引用。

## PAC 架构

```
构建：Git Push/PR ──Webhook──▶ PAC Controller ──▶ 解析 .tekton/<prName> ──▶ 创建构建 PipelineRun
                                                              │
                                                     gitops-writeback 任务
                                               改 kubernetes/deploy-*.yaml 的镜像并 push
                                                              │
部署：构建 Succeeded + changed=true ──▶ PAC Controller 直接创建部署 PipelineRun
                                                              └──▶ kubectl apply ──▶ 滚动更新
```

部署这一段**不经过 Git webhook**：controller 从构建运行的 `gitops-writeback` 任务结果里拿到写回提交的 sha，直接创建部署运行，因此 Git 服务器访问不到 PAC 的仓库同样能部署。

三个 Deployment（`pipelines-as-code` 命名空间）：

| 组件 | 职责 | 关键日志 |
|------|------|---------|
| **Controller** | 接收 Git Webhook → 匹配 Repository CR → 解析模板 → 创建构建 PipelineRun；构建成功后创建**部署** PipelineRun | `kubectl logs -n pipelines-as-code -l app=controllers` |
| **Watcher** | 监视 PAC 管理的 PipelineRun 状态 → 报告结果到 Git → 清理旧运行 | `kubectl logs -n pipelines-as-code -l app=watchers` |
| **Webhook** | 准入验证，校验 Repository CR 创建/更新 | `kubectl logs -n pipelines-as-code -l app=webhook` |

> 部署运行不带 `pipelinesascode.tekton.dev/state` 注解，只有 `kube-do.cn/gitops-role=deploy` 等标记，所以 PAC 不会接管它、也不会向 Git 回报它的状态。

## 构建与部署的两条链路

| | 构建 | 部署 |
|---|---|---|
| 定义位置 | 仓库 `.tekton/<prName>` | ConfigMap `kubedo/pipelinerun-gitops-deploy`（可由 `spec.settings.gitops.deployTemplate` 覆盖） |
| 触发源 | Git push/PR 事件（`autoTrigger` 控制），或手动 `/manual` | 构建成功且 `gitops-writeback` 返回 `changed=true` |
| 运行名 | `<prName>` + 随机后缀 | `<repo>-<appEnv>-<branchKey>-deploy-<写回提交 sha 前 8 位>` |
| 部署版本 | — | `revision` = **写回提交的 sha**，与清单在 Git 的版本一一对应 |
| 可重跑 | 手动 `/manual` | 手动 `/manual?...&deploy=yes` |

要点：

- 部署运行是**幂等**的（同名已存在就跳过），同一分支只保留最近 3 份已结束的运行；
- 创建新部署运行前会取消该分支尚未完成的旧部署运行，避免并发 apply；
- 镜像 tag 由构建阶段生成并写进清单，部署只负责把清单 apply 到集群，**不再修改镜像**；
- 清单里的镜像**必须带 tag**。仓库里未经构建的初始清单是不带 tag 的，部署模板会拒绝并提示「先运行构建」。


## Repository CR — 核心自定义资源

`pipelinesascode.tekton.dev/v1alpha1`，将 Git 仓库与 KDO 应用关联。

```yaml
apiVersion: pipelinesascode.tekton.dev/v1alpha1
kind: Repository
metadata:
  name: my-app
  namespace: my-project          # ★ 必须与 AppProject 同名，不能是 xxx-dev
spec:
  url: https://github.com/org/my-app
  git_provider:
    type: github                 # github/gitlab/gitea/bitbucketcloud/bitbucketserver/gitee（以平台实际支持为准）
    url: https://github.com
    secret:
      name: my-app-token
      key: provider.token
    webhook_secret:
      name: my-app-token
      key: webhook.secret
  branchEnvs:                    # KDO 扩展：分支→环境映射
    - branchName: main
      appEnv: prod               # 部署目标环境 → 命名空间 my-project-prod
      cluster: local-cluster
      prName: .tekton/my-app-prod-main.yaml
      prTemplate: <模板 ConfigMap 名>
      onEvent: ["push"]
      autoTrigger: false         # 构建触发模式：false=手动构建（默认）/ true=push 即构建；不影响部署
  settings:                      # 可选：只用来自定义部署流水线模板
    gitops:
      deployTemplate: pipelinerun-gitops-deploy
  devInfo:                       # KDO 扩展：应用元数据
    devLanguage: golang
    devTemplate: golang-gin
    port: "8080"
    gitProvider: github          # ★ 必须与 spec.git_provider.type 一致
```

关键约束：
- `spec.devInfo.gitProvider` 必须与 `spec.git_provider.type` **一致且同时存在**，否则 PAC 无法探测 Git 提供商。
- `spec.branchEnvs[].appEnv` 决定实际部署到哪个环境 namespace，与 Repository 所在 namespace 无关。

### branchEnvs 字段

| 字段 | 说明 |
|------|------|
| `branchName` | Git 分支名 |
| `appEnv` | 部署环境（dev/test/stage/prod） |
| `cluster` | 目标集群 |
| `prName` | `.tekton/` 文件名 |
| `prTemplate` | 模板 ConfigMap 名称（kubedo 命名空间） |
| `onEvent` | 触发事件 |
| `autoTrigger` | **构建**触发模式：`false`=手动（默认，push 不触发构建）/ `true`=push 即构建。部署不受它影响，构建成功后始终自动部署 |

## .tekton 文件注解体系

`.tekton/` 下的 PipelineRun YAML 通过头部注解控制触发条件：

| 注解 | 示例 | 说明 |
|------|------|------|
| `on-event` | `[push, pull_request]` | 匹配 Git 事件类型 |
| `on-target-branch` | `[main, release-*]` | 匹配目标分支（支持 glob） |
| `on-comment` | `^/test all$` | 匹配 PR 评论（正则） |
| `on-path-change` | `[src/**, *.go]` | 仅这些文件变更时触发 |
| `on-path-change-ignore` | `[docs/**, *.md]` | 忽略这些文件变更 |
| `on-cel-expression` | `event_type == "push" && target_branch == "main"` | CEL 自定义表达式 |
| `max-keep-runs` | `5` | 最大保留运行数 |
| `cancel-in-progress` | `true` | 新推送时取消进行中运行 |

CEL 变量：`event_type`、`body`、`headers`、`target_branch`、`source_branch`、`target_url`、`files`、`sender`、`pull_request_number` 等。

## 模板变量

PAC 在创建 PipelineRun 时替换 `{{ var }}`，值来自 Webhook Payload：

| 变量 | 说明 | 示例 |
|------|------|------|
| `{{ repo_url }}` | 仓库 URL | `https://github.com/org/my-app` |
| `{{ revision }}` | 提交 SHA | `abc1234` |
| `{{ target_namespace }}` | 部署目标命名空间 | `my-project-prod` |
| `{{ target_branch }}` | 目标分支 | `main` |
| `{{ source_branch }}` | 源分支（PR） | `feature/xxx` |
| `{{ image_tag }}` | 镜像 Tag | `20260722-v1.0-abc1234` |
| `{{ git_auth_secret }}` | Git 认证 Secret | `pac-gitauth-xxxxx` |
| `{{ pull_request_number }}` | PR 编号 | `42` |
| `{{ sender }}` | 事件发送者 | `dev1` |
| `{{ body.* }}` | Webhook 负载字段 | `body.pull_request.html_url` |

## kubedo 命名空间的 Task

KDO 预装 22 个 Tekton Task（`kubedo` 命名空间），涵盖 CI/CD 全流程：

```bash
kubectl get task -n kubedo            # 列出全部 Task
kubectl describe task buildah -n kubedo  # 查看参数
```

| 类别 | Task |
|------|------|
| 代码 | `git-clone` |
| 构建 | `golang-build`、`golang-test`、`maven`、`jib-maven`、`npm`、`yarn`、`cargo` |
| 镜像 | `buildah`、`buildpacks`、`kaniko`、`ko`、`s2i`、`skopeo-copy` |
| 写回/部署 | `gitops-writeback`、`kubernetes-actions`、`openshift-client`、`argocd-task-sync-and-wait` |
| 工具 | `kn`、`tkn` |
| 质量/其他 | `sonarqube-scanner`、`remote-ssh-commands` |

> `gitops-writeback` 是构建流水线的最后一个任务：修改 `kubernetes/deploy-<env>-<branchKey>.yaml` 里的镜像与注解并提交推送到仓库。它返回 `changed` 与 `commit-sha` 两个结果，controller 据此决定是否创建部署运行。

**引用格式**（cluster resolver，namespace 必须为 `kubedo`）：

```yaml
taskRef:
  resolver: cluster
  params:
    - name: kind
      value: task
    - name: namespace
      value: kubedo
    - name: name
      value: buildah
```

## 应用模板

模板存储在 `kubedo` 命名空间 ConfigMap 中：

```bash
# 应用模板（按语言）：devfile/Dockerfile/部署清单来源
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devTemplate=<lang>
# 流水线模板（按语言）：prName 对应 PipelineRun 模板来源
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang>
# 回退运行时模板
kubectl get cm -n kubedo -l pipelinesascode.openshift.io/runtime=<java|go|nodejs|python>
# 查看某模板内容
kubectl get cm golang-gin -n kubedo -o yaml
```

模板 ConfigMap 的 `data.template` 即 PipelineRun YAML（含 PAC 变量）。

## PAC 事件

PAC 在每个关键操作向 Repository 资源发出 K8s Event：

| 事件类型 | 说明 |
|---------|------|
| `PacNewRepoMatch` | 匹配到仓库 |
| `PacNewEventFromRepo` | 正在处理事件 |
| `PacPolicyDeny` | 策略拒绝 |
| `PacValidationError` | 验证错误 |
| `PacPipelineRunCreation` | PipelineRun 创建成功 |

```bash
kubectl get events -n <ns> --sort-by='.lastTimestamp' | tail -30
```