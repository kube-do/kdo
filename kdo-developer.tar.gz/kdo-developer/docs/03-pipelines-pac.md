# Tekton / PAC / Repository CRD

KDO 的 CI/CD 基于 **Tekton Pipelines** + **Pipelines as Code (PAC)**，流水线定义存储在 Git 仓库中。

## Tekton 核心资源

| CRD | 说明 |
|-----|------|
| **Task** | 基本工作单元（单个步骤集合） |
| **TaskRun** | Task 的执行实例 |
| **Pipeline** | 多 Task 的执行流程 |
| **PipelineRun** | Pipeline 的执行实例 |
| **Workspaces** | 共享存储 |

> 集群不支持 ClusterTask；Task 存储在 `kubedo` 命名空间，通过 `resolver: cluster` 引用。

## PAC 架构

```
Git Push/PR → Webhook → PAC Controller → 解析 .tekton/ → 创建 PipelineRun → 执行 → 结果反馈
```

三个 Deployment（`pipelines-as-code` 命名空间）：

| 组件 | 职责 | 关键日志 |
|------|------|---------|
| **Controller** | 接收 Git Webhook → 匹配 Repository CR → 解析模板 → 创建 PipelineRun | `kubectl logs -n pipelines-as-code -l app=controllers` |
| **Watcher** | 监视 PipelineRun 状态 → 报告结果到 Git → 清理旧运行 | `kubectl logs -n pipelines-as-code -l app=watchers` |
| **Webhook** | 准入验证，校验 Repository CR 创建/更新 | `kubectl logs -n pipelines-as-code -l app=webhook` |

## Repository CR — 核心自定义资源

`pipelinesascode.tekton.dev/v1alpha1`，将 Git 仓库与 KDO 应用关联。

```yaml
apiVersion: pipelinesascode.tekton.dev/v1alpha1
kind: Repository
metadata:
  name: my-app
  namespace: my-project          # ★ 必须与 AppProject 同名，不能是 xxx-dev
spec:
  url: https://github.com/org/my-app
  git_provider:
    type: github                 # github/gitlab/gitee/bitbucket
    url: https://github.com
    secret:
      name: my-app-token
      key: provider.token
    webhook_secret:
      name: my-app-token
      key: webhook.secret
  branchEnvs:                    # KDO 扩展：分支→环境映射
    - branchName: main
      appEnv: prod               # 部署目标环境 → 命名空间 my-project-prod
      cluster: local-cluster
      prName: .tekton/my-app-prod-main.yaml
      prTemplate: <模板 ConfigMap 名>
      onEvent: ["push"]
      manualTrigger: true        # 手动触发模式（默认）
  devInfo:                       # KDO 扩展：应用元数据
    devLanguage: golang
    devTemplate: golang-gin
    port: "8080"
    gitProvider: github          # ★ 必须与 spec.git_provider.type 一致
```

关键约束：
- `spec.devInfo.gitProvider` 必须与 `spec.git_provider.type` **一致且同时存在**，否则 PAC 无法探测 Git 提供商。
- `spec.branchEnvs[].appEnv` 决定实际部署到哪个环境 namespace，与 Repository 所在 namespace 无关。

### branchEnvs 字段

| 字段 | 说明 |
|------|------|
| `branchName` | Git 分支名 |
| `appEnv` | 部署环境（dev/test/stage/prod） |
| `cluster` | 目标集群 |
| `prName` | `.tekton/` 文件名 |
| `prTemplate` | 模板 ConfigMap 名称（kubedo 命名空间） |
| `onEvent` | 触发事件 |
| `manualTrigger` | 手动触发模式 |

## .tekton 文件注解体系

`.tekton/` 下的 PipelineRun YAML 通过头部注解控制触发条件：

| 注解 | 示例 | 说明 |
|------|------|------|
| `on-event` | `[push, pull_request]` | 匹配 Git 事件类型 |
| `on-target-branch` | `[main, release-*]` | 匹配目标分支（支持 glob） |
| `on-comment` | `^/test all$` | 匹配 PR 评论（正则） |
| `on-path-change` | `[src/**, *.go]` | 仅这些文件变更时触发 |
| `on-path-change-ignore` | `[docs/**, *.md]` | 忽略这些文件变更 |
| `on-cel-expression` | `event_type == "push" && target_branch == "main"` | CEL 自定义表达式 |
| `max-keep-runs` | `5` | 最大保留运行数 |
| `cancel-in-progress` | `true` | 新推送时取消进行中运行 |

CEL 变量：`event_type`、`body`、`headers`、`target_branch`、`source_branch`、`target_url`、`files`、`sender`、`pull_request_number` 等。

## 模板变量

PAC 在创建 PipelineRun 时替换 `{{ var }}`，值来自 Webhook Payload：

| 变量 | 说明 | 示例 |
|------|------|------|
| `{{ repo_url }}` | 仓库 URL | `https://github.com/org/my-app` |
| `{{ revision }}` | 提交 SHA | `abc1234` |
| `{{ target_namespace }}` | 部署目标命名空间 | `my-project-prod` |
| `{{ target_branch }}` | 目标分支 | `main` |
| `{{ source_branch }}` | 源分支（PR） | `feature/xxx` |
| `{{ image_tag }}` | 镜像 Tag | `20260722-v1.0-abc1234` |
| `{{ git_auth_secret }}` | Git 认证 Secret | `pac-gitauth-xxxxx` |
| `{{ pull_request_number }}` | PR 编号 | `42` |
| `{{ sender }}` | 事件发送者 | `jzy99` |
| `{{ body.* }}` | Webhook 负载字段 | `body.pull_request.html_url` |

## kubedo 命名空间的 Task

KDO 预装 19 个 Tekton Task（`kubedo` 命名空间），涵盖 CI/CD 全流程：

```bash
kubectl get task -n kubedo            # 列出全部 Task
kubectl describe task buildah -n kubedo  # 查看参数
```

| 类别 | Task |
|------|------|
| 代码 | `git-clone` |
| 构建 | `golang-build`、`golang-test`、`maven`、`jib-maven`、`npm` |
| 镜像 | `buildah`、`buildpacks`、`kaniko`、`ko`、`s2i`、`s2i-java` |
| 部署 | `kubernetes-actions`、`argocd-task-sync-and-wait`、`openshift-client` |
| 工具 | `kn`、`tkn` |
| 质量/其他 | `sonarqube-scanner`、`remote-ssh-commands` |

**引用格式**（cluster resolver，namespace 必须为 `kubedo`）：

```yaml
taskRef:
  resolver: cluster
  params:
    - name: kind
      value: task
    - name: namespace
      value: kubedo
    - name: name
      value: buildah
```

## 应用模板

模板存储在 `kubedo` 命名空间 ConfigMap 中：

```bash
# 应用模板（按语言）
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devTemplate
# 流水线模板（按语言）
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage
# 查看某模板内容
kubectl get cm golang-gin -n kubedo -o yaml
```

模板 ConfigMap 的 `data.template` 即 PipelineRun YAML（含 PAC 变量）。

## PAC 事件

PAC 在每个关键操作向 Repository 资源发出 K8s Event：

| 事件类型 | 说明 |
|---------|------|
| `PacNewRepoMatch` | 匹配到仓库 |
| `PacNewEventFromRepo` | 正在处理事件 |
| `PacPolicyDeny` | 策略拒绝 |
| `PacValidationError` | 验证错误 |
| `PacPipelineRunCreation` | PipelineRun 创建成功 |

```bash
kubectl get events -n <ns> --sort-by='.lastTimestamp' | tail -30
```