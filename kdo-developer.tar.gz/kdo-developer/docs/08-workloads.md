# KDO 工作负载管理

KDO 管理 Kubernetes 各类工作负载资源，支持完整的生命周期操作。

## 工作负载类型

| 类型 | 适用场景 | 关键特性 |
|------|---------|---------|
| **Deployment** | 无状态应用 (Web/微服务) | 滚动更新、回滚、副本管理 |
| **StatefulSet** | 有状态应用 (DB/缓存) | 稳定网络标识 `<name>-0`、持久存储、有序部署 |
| **DaemonSet** | 节点级服务 (日志/监控) | 每个节点运行一个 Pod |
| **CronJob** | 定时任务 | 基于 Cron 表达式调度 |
| **Job** | 一次性任务 | 运行到完成 |

## Deployment

支持操作：启动/重启/停止/删除（批量）、编辑副本数（手动扩缩）、HPA（自动扩缩）、PDB（中断预算）、健康检查（存活/就绪探针）、添加存储（挂载 PVC）、更新策略（滚动更新参数）、资源限制（CPU/内存）。

详情页提供：详情、指标、YAML、副本集、容器组、环境变量、事件。

```bash
kubectl get deploy -n <ns>                                # 列表
kubectl rollout restart deployment/<app> -n <ns>          # 重启
kubectl scale deployment/<app> --replicas=3 -n <ns>       # 手动扩缩
kubectl rollout status deployment/<app> -n <ns>           # 滚动更新状态
kubectl rollout undo deployment/<app> -n <ns>             # 回滚
kubectl set image deployment/<app> <container>=<image>:<tag> -n <ns>  # 更新镜像
kubectl set resources deployment/<app> -n <ns> --limits=cpu=500m,memory=512Mi --requests=cpu=250m,memory=256Mi
```

## StatefulSet

关键特性：
- 稳定的网络身份（`<name>-0`, `<name>-1`, ...）
- 持久存储（每个 Pod 独立 PVC）
- 有序部署和扩展
- 有序滚动更新
- 需要 Headless Service

适用场景：数据库（MySQL/PostgreSQL）、缓存（Redis）、需要持久存储和稳定网络标识的应用。

## CronJob

Cron 表达式 5 段：

```
┌───────────── 分钟 (0-59)
│ ┌───────────── 小时 (0-23)
│ │ ┌───────────── 日 (1-31)
│ │ │ ┌───────────── 月 (1-12)
│ │ │ │ ┌───────────── 星期 (0-6)
│ │ │ │ │
* * * * *
```

KDO 操作：创建/编辑/删除、暂停/恢复、手动触发、查看历史运行记录。

```bash
kubectl get cronjob -n <ns>
kubectl create job --from=cronjob/<name> <job-name> -n <ns>   # 手动触发
```

## HPA（水平自动扩缩）

基于 CPU/内存 利用率自动调整副本数：

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
spec:
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
```

```bash
kubectl get hpa -n <ns>
kubectl autoscale deployment/<app> --min=2 --max=10 --cpu-percent=70 -n <ns>
```

## PDB（Pod 中断预算）

保证最小可用 Pod 数量，防止滚动更新/节点维护时服务中断：

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
spec:
  minAvailable: 2  # 或 maxUnavailable: 1
  selector:
    matchLabels:
      app: my-app
```

## 常见排查

| 现象 | 排查 |
|------|------|
| Pod 一直 Pending | `kubectl describe pod` Events：节点资源不足、PVC 未绑定、配额超限 |
| CrashLoopBackOff | `kubectl logs <pod> --previous`，参考 `07-troubleshooting.md` |
| 探针失败重启 | 检查存活/就绪探针的 path/port 与就绪时间 |

相关文档：`02-applications.md`（应用创建）、`01-project-env-app.md`（环境命名）。