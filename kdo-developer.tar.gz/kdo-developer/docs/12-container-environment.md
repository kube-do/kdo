# 容器运行环境与内置工具

本技能运行在 **Devfile 开发者镜像** 内（Eclipse Che / DevWorkspace 工作区容器）。镜像由上游仓库 [devfile/developer-images](https://github.com/devfile/developer-images) 构建，分两层：

| 镜像 | 说明 |
|------|------|
| `base-developer-image` | 基础工具层（bash、git、podman/buildah/skopeo 等语言无关工具） |
| `universal-developer-image` | 通用开发层，在 base 基础上叠加语言 SDK 与云原生 CLI（**本技能运行镜像**） |

默认镜像为 **UBI 10**：

```text
quay.io/devfile/universal-developer-image:ubi10-latest
quay.io/devfile/base-developer-image:ubi10-latest
```

UBI 9（`ubi9-latest`）为差异对照版本，二者工具集一致、版本不同（见[版本差异](#ubi9-与-ubi10-版本差异)）。

## 运行时模型

- **用户**：构建期用户 `user`（UID `10001`），运行期支持任意 UID；属组 `0`，`/home`、`/etc/passwd`、`/etc/group` 以 `g=u` 授权，故任意 UID 均可写。
- **HOME**：`/home/user`；工作目录 `/projects`（`mountSources` 挂载源码）。
- **工具安装位置**：所有工具先装到 `/home/tooling`，再通过 `stow` 在 `$HOME` 生成软链（防止 PVC 覆盖）。
- **入口脚本** `/entrypoint.sh` 首启依次执行：
  1. 创建 `$HOME`、生成 podman 存储配置、补写 `/etc/passwd`
  2. `HOST_USERS=false`（user namespace）时更新 `/etc/subuid`、`/etc/subgid`
  3. `source kubedock_setup`（见下节）
  4. 若 `/home/user` 是挂载点（`persistUserHome`），执行 `stow` 建立软链（由 `/home/user/.stow_completed` 守卫，只跑一次）
  5. 按 `/home/tooling/.copy-files` 复制不能做软链的文件（`.viminfo`、`.bashrc`、`.bash_profile`）
  6. 为 `/home/tooling/.config` 下文件在 `$HOME/.config` 建软链
  7. 后台 `jdk_import_ca_bundle` 将系统 CA 导入 JDK 信任库
- **默认命令**：`tail -f /dev/null`（工作区保持常驻）。

> **持久化注意**：启用 `persistUserHome` 时 `/home/user` 为 PVC。`$HOME` 下的配置文件多为指向 `/home/tooling` 的软链，**不要直接改写或删除这些软链**；若工具配置丢失，重启工作区让 entrypoint 重新 stow 即可。

## 权限与软件安装

- **无 root 权限**：本技能以非特权用户运行（构建期 UID `10001`，运行期任意 UID），**禁止**执行 `dnf`/`yum`/`microdnf`/`rpm` 等系统级安装——会因权限不足失败，不要反复尝试。
- **只能使用镜像内置工具**（见下方清单）。确需补充工具时，一律走**用户级**安装方式：
  - Python：`pip install --user <pkg>`
  - Node：`npm install -g <pkg>`（nvm 前缀位于 `$HOME`）
  - Go：`go install <module>@<ver>`（必要时 `export GOBIN=$HOME/go/bin`）
  - 其它：下载静态二进制放入 `$HOME/.local/bin`（已在 `PATH`）
- 若确实需要**系统软件包**，**联系平台管理员**或在 Devfile 中改用包含该工具的自定义镜像，切勿在容器内强行安装。

## Kubedock 与 podman 包装

容器内 `podman` 默认可能被 **kubedock** 接管：kubedock 把容器操作翻译为在集群里创建/管理 Pod。

- 开关：环境变量 `KUBEDOCK_ENABLED`
  - `true` → entrypoint 后台启动 `kubedock server --reverse-proxy --kubeconfig $KUBECONFIG`（日志 `/tmp/kubedock.log`），并将 `$HOME/.local/bin/podman` 指向 `podman.wrapper`
  - 未设置或 `false` → `podman` 直接指向原生 `podman.orig`
- 启动前会等待 `$KUBECONFIG` 出现，超时由 `KUBEDOCK_TIMEOUT` 控制（默认 10 秒）
- 包装逻辑：仅以下子命令转发到 kubedock（`CONTAINER_HOST=tcp://127.0.0.1:2475`），其余仍走原生 podman：

```text
podman run / ps / exec / cp / logs / inspect / kill / rm / wait / stop / start
```

- 启用时同时导出 `TESTCONTAINERS_RYUK_DISABLED=true`、`TESTCONTAINERS_CHECKS_DISABLE=true`
- 镜像构建期环境：`BUILDAH_ISOLATION=chroot`、`_BUILDAH_STARTED_IN_USERNS=""`；`/etc/subuid`、`/etc/subgid` 预置 `user:10000:65536`
- 存储驱动：entrypoint 生成 `$HOME/.config/containers/storage.conf`——有 `/dev/fuse` + `fuse-overlayfs` 用 `overlay`，否则回退 `vfs`
- `/etc/containers/containers.conf` 设置 `default_ulimits = nofile=65535:65535`

> **对本技能的含义**：`podman run` 不等于本地起容器，而是新建集群 Pod。日常应用部署走 KDO 流水线/Console，不要用 `podman` 绕过平台流程；确需临时验证时才考虑。

## 内置工具（UBI 10 默认）

### 云原生 / 平台 CLI

| 工具 | 版本 | 用途 |
|------|------|------|
| `kubectl` | 1.30.1 | K8s 操作（含 `kubens`/`kubectx` krew 插件） |
| `oc` | 4.20 | OpenShift CLI |
| `tkn` | 0.43.0 (Tekton) | Tekton CLI |
| `tkn` | 1.20.0 (OpenShift Pipelines) | OpenShift Pipelines CLI（含 `tkn-pac`） |
| `helm` | 4.0.4 | Helm（OCI Chart） |
| `kustomize` | 5.8.0 | 清单定制 |
| `kn` | 1.20.0 | Knative CLI |
| `krew` | — | kubectl 插件管理器（`kubens`/`kubectx` 由此安装） |
| `skaffold` | latest | 本地构建/部署 |
| `terraform` | 1.14.0 | IaC |
| `kamel` / `camel-k` | 2.8.0 | Camel K |
| `gcloud` | 565.0.0 | Google Cloud CLI |
| `shellcheck` | 0.11.0 | Shell 脚本检查 |
| `tmux` | 3.6a | 终端复用 |
| `herdr` | 0.7.3 | 上游内置 CLI（https://github.com/ogulcancelik/herdr） |

### 容器 / 镜像工具

| 工具 | 版本 | 说明 |
|------|------|------|
| `podman` | 系统包 | 受 kubedock 包装 |
| `buildah` | 系统包 | 无守护进程构建 |
| `skopeo` | 系统包 | 远端镜像检查/复制（`list-tags`、`inspect`） |
| `kubedock` | 0.18.2 | podman Pod 后端 |
| `fuse-overlayfs` | 系统包 | rootless 存储驱动 |
| `bubblewrap` | 0.11.2 | 沙箱 |

### 通用工具

`git`、`git-lfs`、`gh` 2.78.0、`jq`、`yq`、`rg` 13.0.0、`bat` 0.18.3、`fd` 8.7.0、`less`、`vim`、`nano`、`wget`、`curl`、`rsync`、`openssh-clients`（`ssh`/`scp`）、`net-tools`（`netstat`）、`iproute`（`ip`）、`socat`、`lsof`、`sudo`、`stow`

> **`sudo` 提示**：镜像构建期虽安装了 `sudo` 并将 `user` 加入 `wheel`/`root` 组，但运行期以任意 UID 启动时该组归属不生效，**当前用户实际没有 sudo 权限**。不要尝试 `sudo dnf`/`sudo yum` 等方式安装系统包，参见上文「权限与软件安装」。

### 语言与运行时

| 语言 | 内容 |
|------|------|
| Java | SDKMAN 5.20.0；JDK 8/11/17/21/**23（默认）**/25-mandrel；`maven`、`gradle`、`jbang`、Lombok 1.18.42 |
| Node.js | nvm（NODEJS_24 24.12.0 默认 / NODEJS_22 22.21.1）；`npm`、`yarn` 1.22.22 |
| Go | go 1.25.5、`gopls` 0.21.0 |
| Python | python3.13 + pip + setuptools；`pylint`、`yq` |
| PHP | `php`、`composer`、`xdebug` |
| .NET | dotnet-sdk-10.0 |
| Rust | 通过 `rustup`（rust-src、rust-analysis、rust-analyzer） |
| Scala | `cs`（coursier）、`sbt`、`mill` |
| C/C++ | `gcc`、`g++`、`clang`/`clangd`、`gdb` |

## 关键环境变量

| 变量 | 值 / 说明 |
|------|-----------|
| `HOME` | `/home/user` |
| `KUBECONFIG` | `/home/user/.kube/config` |
| `PROFILE_EXT` | `/etc/profile.d/udi_environment.sh`（语言环境追加于此，由 `~/.bashrc` 加载） |
| `SDKMAN_DIR` | `/home/tooling/.sdkman` |
| `JAVA_HOME` | `/home/tooling/.sdkman/candidates/java/current` |
| `JAVA_HOME_8` … `JAVA_HOME_25` | 各 JDK 绝对路径 |
| `GRAALVM_HOME` | `/home/tooling/.sdkman/candidates/java/25.0.1.r25-mandrel` |
| `NVM_DIR` / `NODEJS_HOME_24` / `NODEJS_HOME_22` | nvm 与各 Node 版本 |
| `GOBIN` | `/home/tooling/go/bin` |
| `BUILDAH_ISOLATION` | `chroot` |
| `KUBEDOCK_ENABLED` / `KUBEDOCK_TIMEOUT` | 见「Kubedock 与 podman 包装」 |
| `JDK_CA_BUNDLE` / `JDK_KEYSTORE_PASSWORD` | JDK 证书导入的源 bundle 与 keystore 口令（默认 `changeit`） |

> `alias docker=podman` 已写入通用镜像环境。

## 对本技能操作的用法要点

- **镜像预检**：镜像内 `skopeo` 可直接执行规则要求的 `skopeo list-tags docker://<image-repo>`；私有仓库需先确认有拉取凭证。
- **CLI 辅助排查**：`oc`、`tkn`、`helm`、`kustomize`、`kn` 可用于只读查询与诊断；但**流水线变更仍须走 GitOps**（改 `.tekton/` → push → 手动触发），禁止用 `tkn`/`kubectl apply` 直接改 PipelineRun。
- **数据加工**：`jq`、`yq` 可用，适合解析 `kubectl -o json` 与 YAML。
- **不要绕过平台**：应用创建/部署走 KDO 控制台、Repository CR 与流水线，不用 `podman build`/`kubectl create dep` 替代平台流程（临时验证除外，验证后仍须回写 Git）。
- **内网 TLS**：若 Maven/Gradle/容器访问内网 HTTPS 报证书错误，entrypoint 已将系统 CA 导入 JDK；仍失败时检查 `JDK_CA_BUNDLE` 是否指向正确 bundle。

## UBI9 与 UBI10 版本差异

UBI 9 镜像工具集与 UBI 10 一致，主要版本差异：

| 工具 | UBI 10（默认） | UBI 9 |
|------|----------------|-------|
| `oc` | 4.20 | 4.15 |
| `tkn`（OpenShift Pipelines） | 1.20.0 | 1.14.0 |
| `tkn`（Tekton CD） | 0.43.0 | 0.20.0 |
| `helm` | 4.0.4 | 3.14.3 |
| `kustomize` | 5.8.0 | 5.3.0 |
| `kn` | 1.20.0 | 1.13.0 |
| `terraform` | 1.14.0 | 1.7.5 |
| `kamel` / `camel-k` | 2.8.0 | 2.2.0 |
| `shellcheck` | 0.11.0 | 0.8.0 |
| `gh` | 2.78.0 | 2.83.2 |
| `rg` | 13.0.0 | 15.1.0 |
| `bat` | 0.18.3 | 0.26.0 |
| `fd` | 8.7.0 | 10.3.0 |
| `kubedock` | 0.18.2 | 0.19.0 |
| Go | 1.25.5 | 1.22.5 |
| Python | 3.13 | 3.11 |
| .NET | 10.0 | 8.0 |
| Node 默认 | 24.12.0 | 22.22.3 |
| JDK 默认 | 23.0.2-tem | 17.0.13-tem |
| SDKMAN | 5.20.0 | 5.18.2 |

> UBI 10 的 `stow` 从 EPEL 9 临时启用的仓库安装；UBI 9 直接来自 EPEL 9。
