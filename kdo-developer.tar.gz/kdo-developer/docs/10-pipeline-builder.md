# 标准流水线与流水线构建器

本文覆盖 KDO 的标准/嵌入流水线、Console 可视化流水线构建器、ApprovalTask 审批系统。Tekton/PAC 基础详见 `03-pipelines-pac.md`。

## Pipeline 类型

| 类型 | 说明 | 适用场景 |
|------|------|----------|
| **标准流水线** | 完整 Pipeline CR，参数和工作区需手动输入 | 复杂自定义流程 |
| **嵌入流水线** | PipelineRun CR + 模板参数，应用信息自动注入 | 快速创建 |

## 7 种 Git 提供商集成

| 提供商 | 集成方式 | 特性 |
|------|------|------|
| **GitHub App** | 应用安装 | 功能最完整：Checks API、ChatOps、自动配置 |
| **GitHub Webhook** | Webhook | 功能有限，不支持 Check Runs API |
| **GitLab** | Webhook | 支持 Merge Request 事件 |
| **Bitbucket Cloud** | Webhook | — |
| **Bitbucket Data Center** | Webhook | — |
| **Gitea** | Webhook | — |
| **Gitee** | Webhook | — |

## PAC 安全机制

- **Webhook 签名验证**：验证 Git 事件的真实性
- **Secret 保护**：日志自动脱敏
- **OWNERS 文件 ACL**：PR 触发权限控制
- **认证链**：Webhook 签名 → Git Token → 认证客户端
- **授权链**：Policy 检查 (OkToTest) → OWNERS 文件回退

## 流水线构建器（Console 可视化 DAG）

Console pipelines-plugin 的可视化 DAG 编辑器，拖拽/点击创建 Tekton Pipeline，支持表单与 YAML 双向同步。

### 添加任务

1. 点击已有任务节点的 "+" 装饰器
2. 选择添加位置：
   - **Before**：在当前任务前执行（设置 `runAfter`）
   - **After**：在当前任务后执行
   - **Parallel**：与当前任务并行
3. 创建占位节点（带正确的 `runAfter` 关系）
4. 点击占位节点 → 打开 Task 目录搜索
5. 从目录选择 Task → 转换为可编辑任务节点

### 任务属性编辑

点击任务节点 → 右侧滑出抽屉：

| 编辑项 | 功能 |
|--------|------|
| 参数（Params） | 添加/编辑/删除 Task 参数值 |
| 资源（Resources） | 配置 Task 输入/输出资源 |
| 工作区（Workspaces） | 配置 Task 工作区挂载 |
| When 表达式 | 配置 When 条件（`(input == '') \|\| (input == '')`） |

### 删除/重命名任务

- 删除：右键菜单 → Remove Task，级联清理依赖关系
- 重命名：任务节点内直接编辑名称

### Finally 任务

支持添加 Finally 任务区（`finallyTasks`），在常规任务完成后执行（如清理、通知）。

### 表单 ↔ YAML 双向同步

YAML 编辑器（Monaco）与表单视图（Formik）双向同步，切换时自动执行 Yup 校验，确保数据一致。适用场景：不熟悉 YAML 的用户可用表单可视化编排，高级用户直接编辑 YAML。

### Task 目录搜索

- 数据源：Tekton Hub / Artifact Hub / 集群已有 Task（平台预置 Task 存于 `kubedo` 命名空间）
- 选择后自动安装到集群（Create Task CRD），安装失败自动回退

## ApprovalTask 审批系统

KDO 特有 CRD `openshift-pipelines.org/v1alpha1`，流水线中的审批节点：

| 组件 | 功能 |
|------|------|
| ApprovalTasks 列表页 | 审批任务列表 |
| Approve/Reject 操作 | 审批/拒绝 |
| Approval 模态框 | 审批/拒绝确认对话框 |
| ApprovalTaskNode | DAG 中审批节点渲染 |

> 流水线包含审批节点时，运行到该节点会暂停，需有权限用户在 Console 审批/拒绝后继续。

## PipelineRun DAG 可视化

Console 的 PipelineRun 详情页提供实时 DAG 可视化：
- 节点类型：`TASK_NODE`（普通）/ `CUSTOM_TASK_NODE`（自定义）/ `APPROVAL_TASK_NODE`（审批）
- 日志查看：多流日志查看器，支持 ANSI 颜色
- 条件标签页：TaskRuns / ApprovalTasks / Output（按条件显示）
- 状态：Succeeded / Failed / Running / Cancelled / Pending / Skipped

## KDO 特有改动

| 改动 | 说明 |
|------|------|
| `PIPELINERUN_TEMPLATE_NAMESPACE = 'kubedo'` | PipelineRun 模板存储在 `kubedo` 命名空间 |
| ApprovalTask | 完整的审批任务 CRD 支持 |
| CustomRun | `tekton.dev/v1beta1/CustomRun` 支持 |
| Kueue 多集群 | `PIPELINE_RUN_MANAGED_BY_KUEUE_LABEL` 标签支持 |
| 中文翻译 | `locales/zh/pipelines-plugin.json` 完整翻译 |

相关文档：`03-pipelines-pac.md`（Tekton/PAC 架构）、`11-console-usage.md`（Console 页面与 URL）。