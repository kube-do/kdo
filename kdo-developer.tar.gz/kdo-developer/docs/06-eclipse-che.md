# Eclipse Che 工作区管理

KDO 的开发环境基于 **Eclipse Che**（DevWorkspace）。开发者在此容器内运行本技能（web-terminal-tooling 镜像）。

## 工作区生命周期

```
Pending → Starting → Running → Stopping → Stopped
```

状态通过 `DevWorkspace` CR 的 `spec.started` 控制。

```bash
kubectl get devworkspaces -A                            # 全局查看
kubectl get devworkspace <name> -n <ns> -o wide         # 查看状态
```

## 启停与删除

```bash
# 停止工作区
kubectl patch devworkspace <name> -n <ns> --type=merge -p '{"spec":{"started":false}}'

# 启动工作区
kubectl patch devworkspace <name> -n <ns> --type=merge -p '{"spec":{"started":true}}'

# 删除工作区（⚠️ 需审批，会删除容器与数据）
kubectl delete devworkspace <name> -n <ns>
```

## 用户命名空间

用户首次登录/启动工作区时自动创建，命名模板 `<username>-che`（Go template，可含 `username`/`userID` 变量）。

标识标签：

```bash
kubectl get ns -l app.kubernetes.io/part-of=che.eclipse.org
# app.kubernetes.io/component=workspaces-namespace
# app.kubernetes.io/part-of=che.eclipse.org
```

## 工作区自动创建的资源

| 资源 | 说明 |
|------|------|
| Deployment / Pod | IDE 容器 + 辅助容器 |
| Service + Endpoints | 工作区访问入口 |
| Ingress / Route | 外部访问 |
| PVC | 持久化（存储策略见下） |
| ConfigMap / Secret | 工作区配置与凭据 |

## 工作区组件

- **IDE 容器**：Code-OSS / JetBrains，通用开发镜像 **UDI**：`quay.io/devfile/universal-developer-image:latest`
  - Code-OSS 需要镜像内含 `openssl` + `libbrotli`
- **Language Servers**：语言智能感知（Java/Go/Python/Node 等）
- **运行时**：应用运行所需容器

## 故障排查

### 工作区无法启动

| 原因 | 定位 | 处理 |
|------|------|------|
| PVC 未就绪 | `kubectl get pvc -n <user-ns>` | 等待绑定，检查存储类 |
| 镜像拉取失败 | `kubectl describe pod` Events | 检查镜像地址/私有仓库凭证 |
| ResourceQuota 不足 | `kubectl describe resourcequota -n <user-ns>` | 提升配额 |
| Ingress 未就绪 | `kubectl get ingress -n <user-ns>` | 检查域名/TLS |
| OIDC 配置错误 | che-gateway 日志 | 检查 OIDC 提供方 |
| TLS 证书问题 | Ingress/Route 描述 | 更新证书 |

### 自动停止（Idling）

由 CheCluster 配置控制：

| 参数 | 默认 | 说明 |
|------|------|------|
| `secondsOfInactivityBeforeIdling` | `1800` | 空闲多少秒后自动停止 |
| `secondsOfRunBeforeIdling` | `-1` | 最多运行多少秒（-1=永不过期） |

### Gateway 503

1. 工作区 Pod 是否 Running：`kubectl get pods -n <user-ns>`
2. che-gateway 日志：`kubectl logs -n che <che-gateway-pod>`
3. 检查工作区容器是否 crash。

### 诊断命令

```bash
kubectl get cm kdo-info -n kubedo -o jsonpath='{.data.eclipseCheUrl}'        # Che 访问地址
kubectl get devworkspaces -A
kubectl get ns -l app.kubernetes.io/part-of=che.eclipse.org
kubectl logs -n devworkspace-controller deployment/devworkspace-controller-manager  # 控制器日志
kubectl get events -n <user-ns> --sort-by='.lastTimestamp'                  # 最近事件
```

## 存储策略

| 策略 | 说明 |
|------|------|
| per-user | 每个用户一个共享 PVC |
| per-workspace | 每个工作区独立 PVC |
| ephemeral | 临时存储，重启丢失 |

数据备份注意：删除工作区前确认是否需要迁移持久数据（尤其 ephemeral 策略）。