# Eclipse Che 工作区管理

KDO 的开发环境基于 **Eclipse Che**（DevWorkspace）。开发者在此工作区容器内运行本技能，运行镜像为 devfile `universal-developer-image`（默认 UBI 10；web-terminal-tooling 是另一套 OpenShift Web Terminal 镜像，二者不同），详见 [`12-container-environment.md`](./12-container-environment.md)。

Eclipse Che 提供 **Che Dashboard**（Web 界面）与 **kubectl CLI** 两条操作路径：Dashboard 面向用户在浏览器中创建/管理工作区；本技能主要通过 kubectl + git 协助排查与运维。两类操作视角如下。

## 进入云开发环境

> **注意**：使用云开发环境前，**先配置好 Git 仓库的[个人访问令牌（PAT）](https://docs.kube-do.cn/docs/ide/personal-access-tokens/)** 才能正常访问。如果涉及多个不同的 Git 服务商或仓库，需要分别配置。

两种进入方式：

| 方式 | 操作 |
|------|------|
| 控制台顶部导航 | 登录 KDO 平台 Web 控制台，点击顶部导航 **云开发环境** 入口，浏览器自动打开 Che Dashboard |
| Git 仓库应用入口 | 进入某 Git 仓库应用的详情页面，点击 **访问云开发环境**，即可把该应用直接加载到云开发环境 |

## Dashboard 页面导航

Che Dashboard 的核心路由（用户在浏览器中访问）：

| 页面 | 路由 | 说明 |
|------|------|------|
| 创建工作区 | `/create-workspace` | 从 Git 仓库或示例创建新的工作区 |
| 工作区列表 | `/workspaces` | 查看、启动、停止、删除、批量管理 |
| 工作区详情 | `/workspace/:namespace/:workspaceName` | 概览/Devfile/备份/日志/事件/高级 |
| IDE 加载器 | `/ide/:namespace/:workspaceName`、`/load-factory?url=` | 启动工作区、工厂一键创建 |
| 从备份恢复 | `/restore-from-backup` | 从备份镜像恢复工作区（含跨集群迁移） |
| 用户偏好设置 | `/user-preferences` | 容器注册表、Git 服务、SSH 密钥、Git 身份、PAT、AI 密钥 |

用户从 KDO 平台 Web 控制台顶部导航「云开发环境」进入 Che Dashboard，详细使用手册见 https://docs.kube-do.cn/docs/ide/ 。

## 创建工作区（Dashboard）

用户在 Dashboard 创建新工作区，主要有两种方式：

- **从 Git 导入**：在 **Git 仓库 URL** 输入 HTTPS 或 SSH 地址 → 点击「创建并打开」→ 确认「您信任此仓库的作者吗？」→ 进入工厂加载流程自动克隆代码并启动 IDE。
  - 可选配置：Git 分支、附加 Git 远程仓库、Devfile 路径、容器镜像覆盖、临时存储、内存/CPU 限制
  - SSH 地址需用户已配置 SSH 密钥；未配置时提示到用户偏好设置中添加
  - 仓库根目录含 `devfile.yaml` / `.devfile.yaml` 时自动使用其中定义的环境；否则用通用开发镜像（UDI）
- **从示例创建**：在「选择示例」中选择预置的语言/框架示例（Java、Node.js、Python、Go 等），无需关联仓库

### 工作区名称规则

- 最大长度 63 字符
- 合法字符：字母、数字、连字符（`-`）、下划线（`_`），必须以字母或数字开头和结尾
- 与已有工作区重名提示「名称已被使用」

### 工厂（Factory）一键创建

- 访问 `https://<che-host>#/<仓库地址>` 或 `https://<che-host>/dashboard/github.com/组织/仓库` 自动重定向到工厂加载
- 加载进度步骤：初始化 → 检查运行工作区数量限制 → 创建工作区（获取 devfile → 检查现有工作区 → 等待 SCC 权限 → 应用 devfile）→ 等待启动 → 打开 IDE

## 工作区状态

Dashboard 与 kubectl 查看的状态对应：

| Dashboard 状态 | 含义 | kubectl 对应（`spec.started` / DevWorkspaceStatus） |
|------|------|------|
| Running | 运行中 | RUNNING |
| Starting | 启动中 | STARTING |
| Stopping | 停止中 | STOPPING |
| Stopped | 已停止 | STOPPED |
| Failed / Failing | 失败 | ERROR / FAILED |
| Terminating | 正在删除 | - |
| Deprecated | 已弃用（旧版，需删除重建） | - |

## 工作区列表与操作（Dashboard）

列表列：名称（状态图标）、编辑器、AI 提供商（平台配置 AI 工具时）、最后修改时间、备份状态（配置备份 registry 时）、项目。

行操作（打开按钮 + ⋮ 菜单）：打开 / 以调试模式打开 / 后台启动 / 重启工作区 / 以调试模式重启 / 停止工作区 / 删除工作区 / 工作区详情。支持全选批量删除（删除确认需勾选「我理解此操作无法撤销。」）。

## 工作区详情（Dashboard 6 个 Tab）

| Tab | 内容 |
|-----|------|
| **概览** | 工作区名称（可编辑）、Kubernetes 命名空间（只读）、存储类型（可编辑）、AI 工具、项目、Git 仓库 URL（复制） |
| **Devfile** | 只读查看 devfile YAML，支持复制/下载/展开全屏 |
| **备份** | 备份状态、备份计划、上次备份、备份镜像 |
| **日志** | 工作区运行日志 |
| **事件** | 工作区相关 Kubernetes 事件 |
| **高级** | 刷新 Kubeconfig（运行中可用） |

## 备份与恢复

- 备份由 **DevWorkspace Operator** 根据集群配置自动创建，工作区**停止时**自动生成备份镜像
- 工作区列表 →「备份」视图查看备份（工作区名称/备份时间/大小/状态），行操作「从备份创建」
- 恢复支持两种模式：
  - **默认注册表**：从当前集群默认注册表中选择备份恢复
  - **外部注册表**：输入外部备份镜像 URL（`registry-host/namespace/workspace-name:tag`），支持跨集群迁移
- 恢复会**创建一个新的工作区**（非原地还原），可自定义工作区名称、资源限制与编辑器

## 用户偏好与访问令牌（Dashboard）

用户偏好设置（`/user-preferences`）包含 6 个 Tab：

| Tab | 说明 |
|-----|------|
| Container Registries | 配置私有容器镜像仓库凭据（主机/用户名/密码） |
| Git Services | 查看 Git 服务商 OAuth 授权状态，可撤销 |
| Personal Access Tokens | 配置 Git 访问令牌（详见下） |
| Git Config | 配置 `user.name` / `user.email` 身份 |
| SSH Keys | 管理 SSH 密钥对，供 SSH 克隆与推送 |
| AI Provider Keys | AI 服务商 API 密钥（平台启用 AI 时显示） |

**Personal Access Tokens（PAT）**：支持 GitHub / GitLab / Bitbucket / Bitbucket Server / Azure DevOps / Gitee。配置字段：名称、提供商、端点（自动填充默认值）、组织（仅 Azure DevOps）、令牌。令牌经 Che 后端 API 保存为带标签（`app.kubernetes.io/part-of: che.eclipse.org`、`app.kubernetes.io/component: scm-personal-access-token`）的 Secret。克隆私有仓库、推送代码、访问 `/.che`、`/.vscode` 目录、同步 Git 身份时使用。管理员已配置 OAuth 时无需 PAT。

## 工作区生命周期

```
Pending → Starting → Running → Stopping → Stopped
```

状态通过 `DevWorkspace` CR 的 `spec.started` 控制。

```bash
kubectl get devworkspaces -A                            # 全局查看
kubectl get devworkspace <name> -n <ns> -o wide         # 查看状态
```

## 启停与删除（kubectl）

```bash
# 停止工作区
kubectl patch devworkspace <name> -n <ns> --type=merge -p '{"spec":{"started":false}}'

# 启动工作区
kubectl patch devworkspace <name> -n <ns> --type=merge -p '{"spec":{"started":true}}'

# 删除工作区（⚠️ 需审批，会删除容器与数据）
kubectl delete devworkspace <name> -n <ns>
```

> **注意**：Dashboard 的停止/删除操作与 kubectl 等价。删除工作区会同时清理持久化数据（**不可恢复**），删除前确认是否需要备份。

## 用户命名空间

用户首次登录/启动工作区时自动创建，命名模板 `<username>-che`（Go template，可含 `username`/`userID` 变量）。

标识标签：

```bash
kubectl get ns -l app.kubernetes.io/part-of=che.eclipse.org
# app.kubernetes.io/component=workspaces-namespace
# app.kubernetes.io/part-of=che.eclipse.org
```

## 工作区自动创建的资源

| 资源 | 说明 |
|------|------|
| Deployment / Pod | IDE 容器 + 辅助容器 |
| Service + Endpoints | 工作区访问入口 |
| Ingress / Route | 外部访问 |
| PVC | 持久化（存储策略见下） |
| ConfigMap / Secret | 工作区配置与凭据（含 PAT 等） |

## 工作区组件

- **IDE 容器**：Code-OSS / JetBrains，通用开发镜像 **UDI**：`quay.io/devfile/universal-developer-image`
  - Code-OSS 需要镜像内含 `openssl` + `libbrotli`
  - 实际部署建议固定具体版本 tag，避免使用 `latest`（便于复现与预检）
- **Language Servers**：语言智能感知（Java/Go/Python/Node 等）
- **运行时**：应用运行所需容器

## 故障排查

### 工作区无法启动

| 原因 | 定位 | 处理 |
|------|------|------|
| PVC 未就绪 | `kubectl get pvc -n <user-ns>` | 等待绑定，检查存储类 |
| 镜像拉取失败 | `kubectl describe pod` Events | 检查镜像地址/私有仓库凭证（确认 Container Registries 已配置） |
| ResourceQuota 不足 | `kubectl describe resourcequota -n <user-ns>` | 提升配额；Dashboard 提示资源不足时先停止不用的工作区 |
| Ingress 未就绪 | `kubectl get ingress -n <user-ns>` | 检查域名/TLS |
| OIDC 配置错误 | che-gateway 日志 | 检查 OIDC 提供方 |
| TLS 证书问题 | Ingress/Route 描述 | 更新证书 |
| 私有仓库克隆失败 | Dashboard 提示无法访问仓库 | 用户未配置 PAT/OAuth，或令牌权限/有效期不足，见用户偏好部分 |

### 自动停止（Idling）

由 CheCluster 配置控制：

| 参数 | 默认 | 说明 |
|------|------|------|
| `secondsOfInactivityBeforeIdling` | `1800` | 空闲多少秒后自动停止 |
| `secondsOfRunBeforeIdling` | `-1` | 最多运行多少秒（-1=永不过期） |

### Gateway 503

1. 工作区 Pod 是否 Running：`kubectl get pods -n <user-ns>`
2. che-gateway 日志：`kubectl logs -n che <che-gateway-pod>`
3. 检查工作区容器是否 crash。

### 诊断命令

```bash
kubectl get cm kdo-info -n kubedo -o jsonpath='{.data.eclipseCheUrl}'        # Che 访问地址
kubectl get devworkspaces -A
kubectl get ns -l app.kubernetes.io/part-of=che.eclipse.org
kubectl logs -n devworkspace-controller deployment/devworkspace-controller-manager  # 控制器日志
kubectl get events -n <user-ns> --sort-by='.lastTimestamp'                  # 最近事件
```

## 存储策略

| 策略 | 说明 | Dashboard 对应 |
|------|------|------|
| per-user | 每个用户一个共享 PVC | 存储类型「按用户」 |
| per-workspace | 每个工作区独立 PVC | 存储类型「按工作区」 |
| ephemeral | 临时存储，重启丢失 | 存储类型「临时存储」 |

数据备份注意：删除工作区前确认是否需要迁移持久数据（尤其 ephemeral 策略）。更改存储类型可能丢失工作区数据；多个 per-user 工作区共享同一 PVC（RWO），删除前需停止其他使用该存储的工作区。