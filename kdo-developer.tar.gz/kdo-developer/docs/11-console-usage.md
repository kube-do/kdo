# KDO Console 使用指南与 URL 拼接

KDO Console 基于 Kubernetes Console 扩展，提供管理、开发和运维功能。**本文最重要的用途：Agent 需要引导用户访问 Console 时，必须拼接完整可点击 URL。**

## 获取 Console 基础地址

```bash
CONSOLE_BASE=$(kubectl get cm -n kubedo-system console -o json | \
  jq -r '.data["config.yaml"]' | grep consoleBaseAddress | awk '{print $2}')
# 回退方式
if [ -z "$CONSOLE_BASE" ]; then
  CONSOLE_HOST=$(kubectl get ingress -n kubedo-system console -o jsonpath='{.spec.rules[0].host}')
  CONSOLE_BASE="http://${CONSOLE_HOST}"
fi
```

## URL 拼接规则

**URL 模板：`${CONSOLE_BASE}${path}`**

| 作用域 | 模板 | 说明 |
|--------|------|------|
| 指定命名空间 | `/k8s/ns/${ns}/${plural}` | 命名空间范围内资源 |
| 所有命名空间 | `/k8s/all-namespaces/${plural}` | 跨命名空间查看 |
| 集群范围 | `/k8s/cluster/${plural}` | 集群级资源（Node、CRD、Project） |
| **资源详情 ← 创建/更新后回传** | **`/k8s/ns/${ns}/${plural}/${name}`** | **Agent 创建/更新资源后必须回传此 URL** |
| YAML 编辑 | `/k8s/ns/${ns}/${plural}/${name}/edit-yaml` | YAML 方式编辑 |
| 表单创建 | `/k8s/ns/${ns}/${plural}/~new/form` | 表单方式创建 |

CRD 使用 API 组限定格式 `<apiGroup>~<version>~<kind>`：

| CRD | plural | 示例路径 |
|-----|--------|---------|
| Repository | `pipelinesascode.tekton.dev~v1alpha1~Repository` | `/k8s/ns/${ns}/pipelinesascode.tekton.dev~v1alpha1~Repository` |
| Pipeline | `tekton.dev~v1~Pipeline` | `/k8s/ns/${ns}/tekton.dev~v1~Pipeline` |
| PipelineRun | `tekton.dev~v1~PipelineRun` | `/k8s/ns/${ns}/tekton.dev~v1~PipelineRun` |
| Task | `tekton.dev~v1~Task` | `/k8s/ns/${ns}/tekton.dev~v1~Task` |
| TaskRun | `tekton.dev~v1~TaskRun` | `/k8s/ns/${ns}/tekton.dev~v1~TaskRun` |

## 常用路由速查

### 流水线 / PAC（pipelines-plugin）

| 路径 | 功能 |
|------|------|
| `/k8s/ns/${ns}/pipelinesascode.tekton.dev~v1alpha1~Repository` | PAC Repository 列表 |
| `/k8s/ns/${ns}/pipelinesascode.tekton.dev~v1alpha1~Repository/${name}/form` | 编辑 Repository |
| `/k8s/ns/${ns}/tekton.dev~v1~Pipeline` | Pipeline 列表 |
| `/k8s/ns/${ns}/tekton.dev~v1~PipelineRun` | PipelineRun 列表 |
| `/k8s/ns/${ns}/tekton.dev~v1~PipelineRun/${plr}/logs/${task}` | PipelineRun 任务日志 |
| `/k8s/ns/${ns}/tekton.dev~v1~Pipeline/~new/builder` | Pipeline 构建器（可视化编排） |
| `/k8s/ns/${ns}/tekton.dev~v1~Pipeline/${name}/builder` | Pipeline 构建器（编辑） |

### 开发者常用（dev-console）

| 路径 | 功能 |
|------|------|
| `/add/ns/${ns}` | 添加页面（源码/镜像/目录） |
| `/topology/ns/${ns}` | 拓扑视图 |
| `/builds/ns/${ns}` | 构建列表 |
| `/deploy-image/ns/${ns}` | 镜像部署 |
| `/helm-releases/ns/${ns}` | Helm Release |
| `/project-details/ns/${ns}` | 项目详情 |
| `/appenv-details/ns/${ns}` | 环境详情 |
| `/k8s/ns/${ns}/deployments/~new/form` | 创建 Deployment |

### 其他

| 路径 | 功能 |
|------|------|
| `/dashboards` | 集群概览仪表盘 |
| `/monitoring/query-browser` | PromQL 查询 |
| `/monitoring/logs` | 日志查看 |
| `/terminal` | CloudShell 命令行终端 |
| `/search` | 跨命名空间全文搜索 |
| `/api-explorer` | API Explorer |

## 导航布局

```
Masthead（顶部栏）：Logo / 项目选择 / 搜索 / 用户菜单（登录信息/复制登录命令/修改密码/退出）/ 告警
Sidebar（导航侧栏）：
  Home / 工作负载 / 网络 / 存储 / 监控 / 搜索 / API Explorer / Pipelines / Helm / OperatorHub / 用户管理
```

支持两种视角（Perspectives）：
- **Admin 视角**：完整平台管理功能（默认）
- **Developer 视角**：精简的开发者体验，聚焦应用

## 常见操作

### 查看 Pod 日志
1. 导航到「工作负载 → Pods」
2. 点击目标 Pod → 切到「日志」选项卡
3. 多容器 Pod 可选择容器，可设时间范围

### 进入容器终端
1. Pod 详情页 → 「终端」选项卡
2. 选择容器 → 自动启动 WebSocket 终端会话

### 快速创建资源
1. 右上角 "+" 按钮 → 选择资源类型
2. 选择创建方式：表单 / YAML 编辑器 → 提交

### 修改密码
用户头像 → 「修改密码」→ 输入旧密码 + 新密码

相关文档：`10-pipeline-builder.md`（流水线构建器）、`02-applications.md`（应用管理）。