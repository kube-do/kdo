# KDO 应用管理

KDO 支持 5 种创建应用的方式，覆盖从简单部署到完整 CI/CD 的不同场景。

## 5 种创建方式

| 方式 | 自动化程度 | 适用场景 |
|------|----------|---------|
| **应用(Git 仓库)** | ★★★★★ | 需要自动化 CI/CD 的代码项目 |
| **流水线(Tekton)** | ★★★★ | 自定义 CI/CD 流程 |
| **Helm 应用** | ★★★★ | 复杂应用、中间件 |
| **镜像构建** | ★★★ | 有源码需构建，无需完整流水线 |
| **手动镜像** | ★ | 快速部署、测试、一次性服务 |

> 开发者的日常主路径是 **Git 仓库应用**（基于 PAC），详见 `05-repository-lifecycle.md`。

## Git 仓库应用

基于 **Pipelines as Code** 创建，对接 GitHub、GitLab、Gitea、Bitbucket、Gitee、阿里云 Codeup。只需 **Git URL + Git Token** 即可自动生成多环境多分支流水线。

自动生成文件：

| 文件 | 说明 | 所在分支 |
|------|------|------|
| `devfile.yaml` | 应用定义 | 默认分支（main/master，以仓库实际为准） |
| `.tekton/` | 流水线定义（`{repositoryName}-{appEnv}-{branchKey}.yaml`），该分支环境的触发源 | `spec.branchEnvs[].branchName` 分支 |
| `docker/Dockerfile` | 镜像配置（该分支专属） | `spec.branchEnvs[].branchName` 分支 |
| `kubernetes/` | 部署配置（该分支专属） | `spec.branchEnvs[].branchName` 分支 |

> **文件分布**：`.tekton/`、`docker/Dockerfile` 与 `kubernetes/` 由 init 生成到 **Repository `spec.branchEnvs[].branchName`** 指定的各分支（该分支环境流水线/构建/部署消费的清单），仅 `devfile.yaml` 集中在**默认分支**（若设置 `spec.settings.pipelinerun_provenance: default_branch`，`.tekton` 也改在默认分支读写）。修改流水线、Dockerfile 或部署清单都需 `git checkout <branchName>` 切到对应分支，改完 push 回该分支，再手动触发该分支环境流水线（PAC 默认手动触发）。切换 Pipeline Template、应用模板或开发语言并**保存、重新初始化**后（或下一次事件），系统按 `generated-template` 标记重建对应的生成文件，无需手工删除各分支文件；不是保存后立即重建。`devfile.yaml` 的 `metadata.appProject` 即该应用所属项目名（项目命名空间 `{project}`，也是 Repository CR 所在 namespace；同名 AppProject 是集群级 CR），操作应用前先读取确认。

> **运行问题应急修复遵循「先 K8s 后 Git」**：应用运行/配置/密码问题先改 Deployment/ConfigMap/Secret 并验证恢复，再将同样改动回写仓库对应分支（详见 `07-troubleshooting.md`）。流水线文件（`.tekton/`）编辑则始终走 GitOps。

## Helm 应用

三大核心概念：**Chart**（打包格式）/ **Repository**（仓库）/ **Release**（部署实例）。

**KDO 平台内置 Chart 仓库**（OCI 格式）：

```yaml
type: oci
url: 'https://quay.io/kubedocharts'
```

```bash
# 安装前先查仓库有哪些应用、应用有哪些版本
curl -s 'https://quay.io/api/v1/repository?namespace=kubedocharts&public=true' | jq -r '.repositories[].name'
skopeo list-tags docker://quay.io/kubedocharts/<chart> | jq -r '.Tags[]'

# 强制显式指定 --version 安装
helm install <release> oci://quay.io/kubedocharts/<chart> --version <ver> -n <ns>
helm show values oci://quay.io/kubedocharts/<chart> --version <ver>
```

安装向导：基础信息（Release 名称、命名空间、Chart 版本）→ 参数配置（图形化 values.yaml）→ 审查与安装。

值优先级（后者覆盖前者）：`Chart 默认 values.yaml → UI 提交值/自定义 values 文件 → --set 参数`（`--set` 最高）。

```bash
helm list -A                    # 查看 Release
helm status <release> -n <ns>   # 查看 Release 状态
```

## 手动镜像

表单字段：应用名称、镜像地址、应用端口、副本数、拉取策略、命令/参数、环境变量（键值对 / ConfigMap / Secret 引用）、资源限制、数据持久化（PVC）、健康检查（存活/就绪探针）。

平台自动生成 **Deployment + Service (ClusterIP)**。

> **端口规范**：应用端口必须 **>1024**；HTTP 服务默认 **8080**，HTTPS 服务默认 **8443**。Service 端口、探针端口遵循同样规范。

## 镜像构建

从源码自动构建容器镜像并部署：

- 源码管理、自动 docker build
- 推送到内置 Harbor
- 镜像地址格式：`<harbor-endpoint>/<namespace>/<app-name>:<tag>`
- 支持多语言构建模板（Java/Go/Python/Node.js）
- 自动生成 Deployment + Service

常见构建失败：

| 原因 | 解决 |
|------|------|
| Git 克隆失败 | 检查仓库权限和 URL |
| Dockerfile 未找到 | 检查 Dockerfile 路径 |
| 端口冲突 | 检查端口占用 |
| 推送失败 | 检查 Harbor 凭证 |
| 超时 | 增加构建超时时间 |

## ConfigMap 和 Secret

### ConfigMap
- 键值对存储非敏感数据，用作环境变量、命令行参数或挂载卷
- 编辑：图形界面 + YAML 双模式

### Secret
- 存储敏感信息（密码、API 密钥、TLS 证书）
- 类型：Opaque、SA Token、TLS、dockerconfigjson、basic-auth、ssh-auth
- 注意：Base64 仅编码非加密

### 配置管理最佳实践

- **非敏感配置用 ConfigMap**，敏感配置用 Secret，通过**卷挂载或 envFrom** 注入容器
- **禁止把配置硬编码进镜像或 `.tekton/` 流水线**——否则每次改配置都需重新构建镜像并运行流水线
- 修改配置：更新 ConfigMap/Secret → `kubectl rollout restart deployment/<app>` 重启 Pod 生效，**无需运行流水线**
- 配置变更遵循「先 K8s 验证后同步」：先改 ConfigMap/Secret 验证，再回写 Git 部署清单（详见 `07-troubleshooting.md`）

## ImageChange 自动触发滚动更新

> **可选路径**：标准发布走 `gitops-writeback` + PAC Controller 部署；PAC 构建**不会**自动创建 ImageStream。以下机制仅在项目显式使用 ImageStream 时生效。

当应用的 ImageStream 中的 tag 被更新时，KDC ImageStreamController 自动触发 Deployment 滚动更新：

1. 只扫描带 `namespace.kube-do.cn/app-env` 标签的环境命名空间
2. 检查 Deployment 是否引用该 ImageStream 的 tag（`kdc.kube-do.cn/imagestreams` 注解或镜像串匹配）
3. 匹配成功 → 添加 annotation `kdc.kube-do.cn/image-change.<is>--<tag>` = 时间戳
4. Deployment 控制器检测 annotation 变更 → 触发 Pod 滚动更新

## 常用查询命令

```bash
kubectl get deploy,sts,ds -n <ns>       # 工作负载（环境命名空间 {project}-{env}）
kubectl get cm,secret -n <ns>           # 配置（环境命名空间）
kubectl get imagestream -n <ns>         # 镜像流（环境命名空间）
kubectl get pipelineruns -n <ns> --sort-by=.metadata.creationTimestamp  # 流水线运行（Repository 所在项目命名空间）
```