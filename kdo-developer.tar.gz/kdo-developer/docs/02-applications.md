# KDO 应用管理

KDO 支持 5 种创建应用的方式，覆盖从简单部署到完整 CI/CD 的不同场景。

## 5 种创建方式

| 方式 | 自动化程度 | 适用场景 |
|------|----------|---------|
| **应用(Git 仓库)** | ★★★★★ | 需要自动化 CI/CD 的代码项目 |
| **流水线(Tekton)** | ★★★★ | 自定义 CI/CD 流程 |
| **Helm 应用** | ★★★★ | 复杂应用、中间件 |
| **镜像构建** | ★★★ | 有源码需构建，无需完整流水线 |
| **手动镜像** | ★ | 快速部署、测试、一次性服务 |

> 开发者的日常主路径是 **Git 仓库应用**（基于 PAC），详见 `05-repository-lifecycle.md`。

## Git 仓库应用

基于 **Pipelines as Code** 创建，对接 GitHub/GitLab/Gitee/Gitea。只需 **Git URL + Git Token** 即可自动生成多环境多分支流水线。

自动生成文件：

| 文件 | 说明 |
|------|------|
| `devfile.yaml` | 应用定义 |
| `.tekton/` | 流水线定义（`应用名-环境-分支.yaml`） |
| `docker/Dockerfile` | 镜像配置 |
| `kubernetes/` | 部署配置 |

## Helm 应用

三大核心概念：**Chart**（打包格式）/ **Repository**（仓库）/ **Release**（部署实例）。

安装向导：基础信息（Release 名称、命名空间、Chart 版本）→ 参数配置（图形化 values.yaml）→ 审查与安装。

值优先级：`Chart 默认 values.yaml → UI 提交值 → --set 参数 → 自定义 YAML 文件`

```bash
helm list -A                    # 查看 Release
kubectl get helmreleases -A     # KDO/OpenShift 方式查看
```

## 手动镜像

表单字段：应用名称、镜像地址、应用端口、副本数、拉取策略、命令/参数、环境变量（键值对 / ConfigMap / Secret 引用）、资源限制、数据持久化（PVC）、健康检查（存活/就绪探针）。

平台自动生成 **Deployment + Service (ClusterIP)**。

## 镜像构建

从源码自动构建容器镜像并部署：

- 源码管理、自动 docker build
- 推送到内置 Harbor
- 镜像地址格式：`<harbor-endpoint>/<namespace>/<app-name>:<tag>`
- 支持多语言构建模板（Java/Go/Python/Node.js）
- 自动生成 Deployment + Service

常见构建失败：

| 原因 | 解决 |
|------|------|
| Git 克隆失败 | 检查仓库权限和 URL |
| Dockerfile 未找到 | 检查 Dockerfile 路径 |
| 端口冲突 | 检查端口占用 |
| 推送失败 | 检查 Harbor 凭证 |
| 超时 | 增加构建超时时间 |

## ConfigMap 和 Secret

### ConfigMap
- 键值对存储非敏感数据，用作环境变量、命令行参数或挂载卷
- 编辑：图形界面 + YAML 双模式

### Secret
- 存储敏感信息（密码、API 密钥、TLS 证书）
- 类型：Opaque、SA Token、TLS、dockerconfigjson、basic-auth、ssh-auth
- 注意：Base64 仅编码非加密

## ImageChange 自动触发滚动更新

当应用的 ImageStream 中的 tag 被更新时，KDC ImageStreamController 自动触发 Deployment 滚动更新：

1. 扫描当前 Namespace 下所有 Deployment
2. 检查容器镜像地址是否引用该 ImageStream 的 tag
3. 匹配成功 → 添加 annotation `kdc.kube-do.cn/image-change.{is--tag}` = 时间戳
4. Deployment 控制器检测 annotation 变更 → 触发 Pod 滚动更新

## 常用查询命令

```bash
kubectl get deploy,sts,ds -n <ns>       # 工作负载
kubectl get cm,secret -n <ns>           # 配置
kubectl get imagestream -n <ns>         # 镜像流
kubectl get pipelineruns -n <ns> --sort-by=.metadata.creationTimestamp  # 流水线运行
```