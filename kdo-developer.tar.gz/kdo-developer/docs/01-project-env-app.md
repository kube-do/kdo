# KDO 项目-环境-应用模型

KDO 平台的 **项目（Project）**、**环境（Environment）** 和 **应用（Application）** 三者关联，共同构成资源管理体系。理解此模型能回答大部分命名空间/环境/权限问题。

## 核心概念

### 项目（Project）
- 为实现目标而协调的一系列活动，可包含多个应用
- 创建项目时自动创建同名 Kubernetes 命名空间
- 仅**集群管理员**可创建项目
- 底层由 **KDC AppProject Controller** 自动调和

### 环境（Environment）
- 对应 Kubernetes 命名空间，命名规则：`{project}-{env}`
- 例：项目 `abc` 的开发环境命名空间为 `abc-dev`

| 环境 | 标识 | 用途 |
|------|------|------|
| 开发环境 | `dev` | 开发者编写和调试代码 |
| 测试环境 | `test` | QA 功能/性能测试 |
| 预发环境 | `stage` | 模拟生产做最终验证 |
| 生产环境 | `prod` | 最终用户使用 |

### 应用（Application）
- 为用户提供功能的软件程序，在同一项目中可开发多个应用
- 在不同环境中经历开发、测试、上线的生命周期

## 三者关系

- **AppProject : AppEnv = 1 : N**：一个项目包含多个环境（dev/test/stage/prod）
- **AppProject : Application = 1 : N**：一个项目包含多个应用
- **应用 ↔ 环境**：应用通过 Repository CR 的 `spec.branchEnvs[].branchName` 绑定环境——每个分支对应一个环境，流水线把应用部署到对应环境命名空间

```
AppProject（项目，集群管理员创建）
   ├── 1:N ── AppEnv（环境）   → 环境命名空间 {project}-{env}（如 abc-dev）
   └── 1:N ── Application（Repository CR）→ 项目命名空间 {project}（与项目同名）
                  └── spec.branchEnvs[] 分支映射到环境
```

**命名空间两条线**：

| 命名空间 | 资源 |
|----------|------|
| **项目命名空间** `{project}`（与项目同名） | Repository CR、PipelineRun、TaskRun、PAC 事件 |
| **环境命名空间**（`{project}-{env}`） | Deployment、Service、Pod、ConfigMap、Secret、中间件 |

> 记忆要点：**Repository 建在项目命名空间 `{project}`**（项目名与集群级 AppProject 同名，但 AppProject 是集群级 CR、不是 namespace）；严禁使用环境命名空间（如 `xxx-dev`）；工作负载与中间件在环境命名空间。

## 项目成员与权限

KDC 定义 5 种预定义角色，按环境类型自动分配 RBAC：

| 角色 | dev | test | stage | prod |
|------|-----|------|-------|------|
| **project-admin** | R+W | R+W | R+W | R+W |
| **developer** | R+W | R | R | R |
| **qa** | R | R+W | R | R |
| **ops** | R | R | R+W | R+W |
| **view** | R | R | R | R |

> 这是角色→可写环境的**概念矩阵**，实际以命名空间 RoleBinding 为准：环境 ns 通常只绑该环境需要的角色（如 dev 绑 `developer`/`ops`/`view`，test 绑 `qa`/`ops`/`view`，stage/prod 绑 `ops`/`view`），另有 `project-admin` 与项目 `default-sa`（其 SA 在所有环境 ns 绑 `developer`）。

## 用户与组（Casdoor）

平台身份由 **Casdoor** 统一提供（Console `oidcProvider: casdoor`，issuer `https://sso.kube-do.cn`，组织 `kdo`）。

- `users.kube-do.cn` / `groups.kube-do.cn` 由 KDC 从 Casdoor 同步（`SYNC=casdoor`）；用户字段 `username` / `email` / `enabled`，组名形如 `kdo:<group>`。
- 项目成员从平台用户或组中选择；通知收件人可以是用户、组或项目角色。
- 普通用户只能查看自己的信息；用户/组的新增、禁用由平台管理员在控制台用户管理中完成。

## KDC 自动创建资源

创建项目（AppProject CR）时自动调和：

| 资源 | 说明 |
|------|------|
| Namespace | 同名项目命名空间 |
| PVC `repo-cache` | 20Gi RWX，代码仓库缓存 |
| ClusterRole + ClusterRoleBinding | 项目管理员 CRD 操作权限 |
| 4 个 RoleBinding | project-admin / view / kdo-project-workload / kdo-project-secret-view（环境 ns 再按 AppEnv 角色绑定 developer/qa/ops/view） |
| registry Secret | dockerconfigjson 类型，Harbor 认证 |
| Harbor Robot 账号 | 系统级，所有 project 完全权限 |

创建环境（AppEnv CR）时自动调和：

| 资源 | 说明 |
|------|------|
| Namespace | `{project}-{env}` |
| RoleBinding | 按环境类型分配角色 |
| registry Secret | 环境级别 Harbor 认证 |
| Harbor Project | `{project}-{env}` 私有项目（仅公共 `kubedo` 项目为 public） |

## 环境复制（历史能力）

> 环境复制是早期功能，当前 Console 以**项目概览 → Environments** 的部署矩阵与多集群环境卡片为主；如界面无此入口，以项目/环境模型为准。

支持基于已部署应用复制到其他环境，适用于多分支并行迭代、多开发者独立环境、开发→测试→预发推进、生产灰度。

依赖关系处理：

| 场景 | 处理方式 |
|------|----------|
| 组件及其依赖同时被复制 | 保持依赖关系，在新组件之间建立 |
| 仅依赖方被复制，目标在当前团队 | 新组件依然依赖源组件 |
| 仅依赖方被复制，目标在不同团队 | 复制时解除依赖关系 |

## 常用查询命令

```bash
kubectl get appproject -o name                          # 项目列表
kubectl get appenv -n <project> -o name                 # 项目内环境
kubectl get ns -l namespace.kube-do.cn/app-project=<project> -o name  # 项目命名空间
kubectl auth can-i create repositories.pipelinesascode.tekton.dev -n <project>  # 权限检查
```