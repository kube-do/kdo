# 仓库生命周期管理

Git 仓库应用（Repository CR）的创建、编辑、删除、触发与诊断。

> 应用所属项目以**默认分支** `devfile.yaml` 的 `metadata.appProject` 为准：`git show origin/HEAD:devfile.yaml | yq '.metadata.appProject'`。该值是项目名 = 项目命名空间 `{project}`（也是 Repository CR 所在 namespace）；同名 AppProject 是集群级 CR，不是命名空间。

## 创建仓库（6 步，末步可选）

### ① 识别 Git 提供商

按仓库域名判断（`detectGitType`）：

| 域名 | 提供商 |
|------|--------|
| `github.com` | github |
| `bitbucket.org` | bitbucket |
| `gitlab.com` | gitlab |
| `gitee.com` | gitee |
| 其他 | 默认 gitlab |

### ② 识别开发语言

按仓库根目录特征文件判断：

| 文件 | 语言 |
|------|------|
| `pom.xml` | java |
| `go.mod` | golang |
| `requirements.txt` | python |
| `package.json` | nodejs |
| `*.csproj` | dotnet |
| `Gemfile` | ruby |
| `composer.json` | php |
| 均无 | 默认 java |

### ③ 创建 Token Secret

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: <app>-token
  namespace: <project>          # 项目命名空间（与项目同名；AppProject 是集群级 CR）
type: Opaque
stringData:
  provider.token: <git-token>
  webhook.secret: <随机字符串>
  # Bitbucket 额外需要：
  # webhook.auth: <user:token 的 base64>
```

Token 权限要求：

| 提供商 | 要求 |
|--------|------|
| GitHub | scope: `repo` + `admin:repo_hook` |
| GitLab | scope: `api`，且用户角色 Maintainer/Owner |

> Token 由用户提供，创建后不可回显。

### ④ 构建 Repository CR

```yaml
apiVersion: pipelinesascode.tekton.dev/v1alpha1
kind: Repository
metadata:
  name: <app>
  namespace: <project>          # ★ 必须建在项目命名空间 <project>，不能是环境 ns <project>-<env>
spec:
  url: <git-url>
  git_provider:
    type: <github|gitlab|gitea|bitbucketcloud|bitbucketserver|gitee>
    url: <提供商根地址>
    secret:
      name: <app>-token
      key: provider.token
    webhook_secret:
      name: <app>-token
      key: webhook.secret
  branchEnvs:
    - branchName: main
      appEnv: dev
      cluster: <cluster>
      prName: .tekton/<app>-dev-main.yaml
      prTemplate: <模板 ConfigMap 名>
      onEvent: ["push"]
      autoTrigger: false        # 默认手动触发（false）
  devInfo:
    devLanguage: <golang|java|...>
    devTemplate: <模板名>
    port: "8080"
```


### ⑤ 创建远端 Webhook

1. 获取 Controller 地址：
   ```bash
   kubectl get cm pipelines-as-code-info -n pipelines-as-code -o jsonpath='{.data.controller-url}'
   ```

2. **Git 侧接收地址是 PAC Controller 的根地址**（上述 `controller-url`）；下表是 Console 后端代为创建/校验 Webhook 时使用的接口，不是填到 Git 平台的接收 URL：

| 提供商 | Console 自动创建 Webhook 的接口 |
|--------|----------------------------------|
| GitHub | `/api/dev-console/webhooks/github` |
| GitLab | `/api/dev-console/webhooks/gitlab` |
| Bitbucket | `/api/dev-console/webhooks/bitbucket` |
| Gitee | `/api/dev-console/webhooks/gitee` |
| Codeup | `/api/dev-console/webhooks/codeup`（Codeup 只能由 Console 代理，不能浏览器直连） |

3. 在 Git 平台创建 Webhook → **PAC Controller 根地址** + `webhook.secret`；或在 Console 创建仓库时由平台自动创建。

需订阅的触发事件：

| 提供商 | 事件 |
|--------|------|
| GitHub | Commit comments / Issue comments / Pull request / Pushes |
| GitLab、Gitee | Merge request Events + Push Events |
| Bitbucket | Repository Push / PR Created / PR Updated / PR Comment Created |

> GitHub：若 PAC ConfigMap 中配置了 `app-link`，优先使用 **GitHub App** 而非 Webhook。

### ⑥ 可选：init 生成 .tekton 文件

```bash
USER_TOKEN=<your-kubernetes-bearer-token>
# 新仓库通常 branch=main、appEnv=首个环境（如 dev），按需替换
curl -X POST -H "Authorization: Bearer ${USER_TOKEN}" \
  "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?init=yes&cluster=<cluster>&namespace=<project>&repository=<app>&branch=<branch>&appEnv=<env>"
```

## 编辑仓库

```bash
kubectl edit repository <app> -n <project>
```

> ⚠️ **需用户审批**：Repository 属于生产变更，编辑前说明改哪一项、影响哪个分支环境，并准备回滚（保留原 YAML）。

## 删除仓库

```bash
kubectl delete repository <app> -n <project>
```

> ⚠️ **需用户审批**。该操作只删除 Repository CR；Git 侧 Webhook 与 `.tekton/` 文件需另行手动清理。

## 手动触发流水线

优先在 Console 点击 Run Pipeline；终端直连 PAC 时使用自己的 Kubernetes Token：

```bash
USER_TOKEN=<your-kubernetes-bearer-token>
curl -X POST -H "Authorization: Bearer ${USER_TOKEN}" \
  "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<project>&repository=<app>&branch=<branch>&appEnv=<env>"
```

（无 `init` 参数。手动触发与 `autoTrigger` 无关——它只决定 webhook 事件是否自动构建；`autoTrigger=false` 时 push/PR 不触发构建，但仍可随时手动触发。Token 无效返回 401，权限不足返回 403，详见 `07-troubleshooting.md`。）

## 诊断

```bash
git ls-remote --heads <git-url>                 # 分支列表
git ls-tree -r HEAD --name-only | grep '\.tekton'  # 流水线文件是否存在
kubectl describe repository <app> -n <project>  # 看 Events
kubectl logs -n pipelines-as-code deploy/pipelines-as-code-controller --tail=100
```

Repository **没有 `.status` 子资源**，诊断以 Events、controller 日志和 PipelineRun 标签/注解为准：

| 现象 | 排查 |
|------|------|
| 事件未触发 | `kubectl get events -n <project> --field-selector involvedObject.name=<app>`，确认 `RepositoryPipelineRun` / `RepositoryPipelineRunSkipped` |
| 提供商识别失败 | 检查 `spec.git_provider.type` 与 URL 域名；看 `RepositoryDetectProvider` 事件 |
| 403/401 | 检查 Token Secret 的 `provider.token`、用户项目权限 |
| 策略拒绝 | 看 `PolicySetAllowed` / `PolicySetDisallowed` 与 `ParamsError` |
| 构建成功未部署 | 看 `RepositoryGitOpsDeploy` 事件、`gitops-writeback` 结果 `changed`、部署模板 |

## 模板查询

```bash
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang>   # 流水线模板（prTemplate 来源）
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang> -l pipelinesascode.tekton.dev/devTemplate=<framework>   # 应用模板（Dockerfile/部署清单来源；devTemplate 标签是框架名）
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang> -o name   # 按语言列出模板
```

PAC Controller 地址：`pipelines-as-code-controller.pipelines-as-code.svc:8080`。