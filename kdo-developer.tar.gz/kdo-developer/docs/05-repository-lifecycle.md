# 仓库生命周期管理

Git 仓库应用（Repository CR）的创建、编辑、删除、触发与诊断。

> 应用所属项目（AppProject / 项目 namespace，也是 Repository CR 所在 namespace）以主分支 `devfile.yaml` 的 `metadata.appProject` 为准：`git show origin/main:devfile.yaml | yq '.metadata.appProject'`。

## 创建仓库（6 步，末步可选）

### ① 识别 Git 提供商

按仓库域名判断（`detectGitType`）：

| 域名 | 提供商 |
|------|--------|
| `github.com` | github |
| `bitbucket.org` | bitbucket |
| `gitlab.com` | gitlab |
| `gitee.com` | gitee |
| 其他 | 默认 gitlab |

### ② 识别开发语言

按仓库根目录特征文件判断：

| 文件 | 语言 |
|------|------|
| `pom.xml` | java |
| `go.mod` | golang |
| `requirements.txt` | python |
| `package.json` | nodejs |
| `*.csproj` | dotnet |
| `Gemfile` | ruby |
| `composer.json` | php |
| 均无 | 默认 java |

### ③ 创建 Token Secret

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: <app>-token
  namespace: <project>          # 与 AppProject 同名
type: Opaque
stringData:
  provider.token: <git-token>
  webhook.secret: <随机字符串>
  # Bitbucket 额外需要：
  # webhook.auth: <user:token 的 base64>
```

Token 权限要求：

| 提供商 | 要求 |
|--------|------|
| GitHub | scope: `repo` + `admin:repo_hook` |
| GitLab | scope: `api`，且用户角色 Maintainer/Owner |

> Token 由用户提供，创建后不可回显。

### ④ 构建 Repository CR

```yaml
apiVersion: pipelinesascode.tekton.dev/v1alpha1
kind: Repository
metadata:
  name: <app>
  namespace: <project>          # ★ 必须与 AppProject 同名，不能是 xxx-dev
spec:
  url: <git-url>
  git_provider:
    type: <github|gitlab|gitea|bitbucketcloud|bitbucketserver|gitee>
    url: <提供商根地址>
    secret:
      name: <app>-token
      key: provider.token
    webhook_secret:
      name: <app>-token
      key: webhook.secret
  branchEnvs:
    - branchName: main
      appEnv: dev
      cluster: <cluster>
      prName: .tekton/<app>-dev-main.yaml
      prTemplate: <模板 ConfigMap 名>
      onEvent: ["push"]
      autoTrigger: false        # 默认手动触发（false）
  devInfo:
    devLanguage: <golang|java|...>
    devTemplate: <模板名>
    port: "8080"
    gitProvider: <github|gitlab|...>   # ★ 必须与 spec.git_provider.type 一致
```

> `spec.devInfo.gitProvider` 与 `spec.git_provider.type` 必须同时存在且一致，否则 PAC 无法探测 Git 提供商。

### ⑤ 创建远端 Webhook

1. 获取 Controller 地址：
   ```bash
   kubectl get cm pipelines-as-code-info -n pipelines-as-code -o jsonpath='{.data.controller-url}'
   ```

2. 各提供商端点：

| 提供商 | 端点 |
|--------|------|
| GitHub | `/api/dev-console/webhooks/github` |
| GitLab | `/api/dev-console/webhooks/gitlab` |
| Bitbucket | `/api/dev-console/webhooks/bitbucket` |
| Gitee | 由 gitee-service 提供，具体端点以平台实际配置为准 |

3. 在 Git 平台创建 Webhook → Controller URL + 对应端点 + `webhook.secret`。

需订阅的触发事件：

| 提供商 | 事件 |
|--------|------|
| GitHub | Commit comments / Issue comments / Pull request / Pushes |
| GitLab、Gitee | Merge request Events + Push Events |
| Bitbucket | Repository Push / PR Created / PR Updated / PR Comment Created |

> GitHub：若 PAC ConfigMap 中配置了 `app-link`，优先使用 **GitHub App** 而非 Webhook。

### ⑥ 可选：init 生成 .tekton 文件

```bash
WS=$(kubectl get secret <app>-token -n <project> -o jsonpath='{.data.webhook\.secret}' | base64 -d)
# 新仓库通常 branch=main、appEnv=首个环境（如 dev），按需替换
curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?init=yes&cluster=<cluster>&namespace=<project>&repository=<app>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

## 编辑仓库

```bash
kubectl edit repository <app> -n <project>
```

## 删除仓库

```bash
kubectl delete repository <app> -n <project>
```

> ⚠️ **需用户审批**。该操作只删除 Repository CR；Git 侧 Webhook 与 `.tekton/` 文件需另行手动清理。

## 手动触发流水线

```bash
curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<project>&repository=<app>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

（无 `init` 参数；PAC 默认手动触发，需 `branchEnvs[].autoTrigger=false`（手动模式）。）

## 诊断

```bash
git ls-remote --heads <git-url>                 # 分支列表
git ls-tree -r HEAD --name-only | grep '\.tekton'  # 流水线文件是否存在
kubectl describe repository <app> -n <project>  # RepoStatus
```

常见 `RepoStatus` 错误：

| 错误 | 含义 | 处理 |
|------|------|------|
| `RateLimitExceeded` | 触发过多 | 稍后重试，检查 webhook 重复 |
| `GitTypeNotDetected` | 无法识别提供商 | 检查 `url` 与 `git_provider.type` |
| `PrivateRepo` | Token 无权限 | 检查 Token 有效期/scope |
| `ResourceNotFound` | 仓库不存在 | 检查 URL 是否含 `.git` 后缀且完全一致 |
| `InvalidGitTypeSelected` | 提供商类型错误 | 修正 `type` |
| `AccessTokenError` | Token 失效 | 重新生成 Token |

## 模板查询

```bash
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang>   # 流水线模板（prTemplate 来源）
kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devTemplate=<lang>   # 应用模板（Dockerfile/部署清单来源）
kubectl get cm -n kubedo -l pipelinesascode.openshift.io/runtime=<java|go|nodejs|python>   # 回退运行时模板
kubectl get cm <PAC_TEMPLATE_DEFAULT> -n kubedo -o jsonpath='{.data.template}'   # 默认模板
```

PAC Controller 地址：`pipelines-as-code-controller.pipelines-as-code.svc:8080`。