# 分支流水线编辑（GitOps 工作流）

KDO 流水线以 **Git 为唯一事实来源**：编辑 `.tekton/` 下的 PipelineRun 文件并 push，再手动触发（**PAC 默认手动触发**，push 不会自动执行）。**禁止** `kubectl apply` 直接修改 PipelineRun CR（会绕过 Git 溯源，且修改会被覆盖）。

## 7 步工作流

### ① 定位仓库

```bash
kubectl get repository <app> -n <ns> -o yaml
```

关键字段：`spec.url`（Git 地址）、`spec.git_provider.type`、`spec.git_provider.secret.name`（Token Secret 名）、`spec.branchEnvs`（分支环境列表）、`spec.devInfo.devLanguage`。

### ② 认证（可选）

Che 工作区已配置 Git 凭据，push 无需额外认证。仅当 push 报认证失败时，才从 Secret 取 Token 配置远端 URL：

```bash
TOKEN=$(kubectl get secret <app>-token -n <ns> -o jsonpath='{.data.provider\.token}' | base64 -d)
git remote set-url origin "https://oauth2:${TOKEN}@<git-host>/<owner>/<repo>.git"
```

> Token 只进入当前 shell 环境变量，**不回显、不进日志、不写入任何文件**。如遇权限不足请直接提示用户联系项目管理员。

### ③ 进入本地仓库（无需重新 clone）

本技能运行于 **Eclipse Che 工作区**，仓库已由 devfile 检出到本地，直接使用当前工作目录，**无需重新 `git clone`**：

```bash
git remote -v               # 确认当前目录是目标仓库
git branch --show-current   # 确认当前分支
git status                  # 工作区状态
```

> 仅当本地没有该仓库时（如补充场景）才需 clone：`git clone "<git-url>"`。

### ④ 定位目标文件与所在分支

**文件↔分支↔操作对照**：

| 操作目标 | 文件 | 所在分支 | 操作 |
|---------|------|---------|------|
| 编辑流水线 | `.tekton/{prName}.yaml` | **主分支** main/master | 本地主分支，直接改 |
| 修改构建配置 | `docker/Dockerfile` | **`spec.branchEnvs[].branchName` 分支** | 先 `git checkout` 切分支 |
| 修改部署清单 | `kubernetes/*.yaml` | **`spec.branchEnvs[].branchName` 分支** | 先 `git checkout` 切分支 |

> 本地仓库当前在**主分支**（`.tekton/` 所在）；`docker/`、`kubernetes/` 位于 branchName 分支，**两类文件在不同分支，必须分开操作**。**修改部署清单前必须先按原则「部署清单先验证后同步」在实际 K8s 环境验证**（详见 `07-troubleshooting.md`）：

```bash
git branch --show-current        # 确认当前分支
git fetch origin <branchName>    # 改 Dockerfile/部署清单前切到 branchName 分支
git checkout <branchName>
# ...编辑 docker/Dockerfile 或 kubernetes/...
git push origin <branchName>     # 提交回该分支（该分支环境流水线需手动触发）
```

> **若应用依赖中间件（数据库/缓存等）**：同步部署清单前，必须先验证目标环境中中间件**是否存在、数据是否已初始化、账户密码是否正确**；全部通过后方可更新 Git；任一失败**立即中止**，排查后重新验证。详见 `07-troubleshooting.md`。

文件名规则：`.tekton/{appName}-{appEnv}-{sanitize(branch)}.yaml`

**sanitize(分支名)** 规则：
1. 转小写
2. 去除首尾空白
3. 将连续的非字母数字字符（空格、下划线、连字符等）统一替换为单个连字符 `-`
4. 去除首尾连字符
5. 截断为 9 个字符

> 等价实现：`.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 9)`。可按此校验生成的文件名是否与 `prName` 一致。

例：app=`my-app`、env=`dev`、分支 `develop` → 文件 `my-app-dev-develop.yaml`。

> 更可靠的方式：直接从 `spec.branchEnvs[].prName` 精确取文件名。

```bash
git ls-tree -r HEAD --name-only | grep '\.tekton'   # 查看所有流水线文件
```

### ⑤ 编辑 PipelineRun YAML

可修改内容：`params`（构建参数、镜像 Tag）、`taskRef`（resolver: cluster，namespace=kubedo）、`workspaces`、`annotations`（触发条件）。**不要改 PipelineRun 的 name/metadata。**

### ⑥ 校验

```bash
python3 -c "import yaml; yaml.safe_load(open('.tekton/my-app-dev-develop.yaml'))"
kubectl apply --dry-run=client -f .tekton/my-app-dev-develop.yaml
```

### ⑦ 提交与推送

```bash
git add .
git commit -m "Added or updated files for tekton pipeline."
git push
```

> **commit message 必须为 `Added or updated files for tekton pipeline.`**（PAC 的 PacCommitMessage），否则会再次触发流水线循环。
>
> ⚠️ **触发流水线必须经用户审批**；生产环境（prod）变更需额外做影响评估。默认手动触发：push 后需调 `/manual` 或 Console 点击 Run Pipeline。

## 新增分支环境

### 方式 A：CR 触发 init（推荐）

1. **收集三要素让用户选择**：
   ```bash
   git branch -r                                                     # 分支列表
   kubectl get appenv -n <ns> -o name                                # 目标环境
   kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang> -o name  # 流水线模板（prTemplate 来源）
   ```

2. **patch Repository CR** 追加 `branchEnvs` 条目：
   ```yaml
   - branchName: <branch>
     appEnv: <env>                  # 部署目标环境
     cluster: <cluster>
     prName: .tekton/<app>-<env>-<sanitize(branch)>.yaml
     prTemplate: <模板 ConfigMap 名>
     onEvent: ["push"]
     autoTrigger: false           # 默认 false（手动）
   ```

3. **触发 init**（生成 .tekton 文件并执行一次）：
   ```bash
   WS=$(kubectl get secret <app>-token -n <ns> -o jsonpath='{.data.webhook\.secret}' | base64 -d)
   curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?init=yes&cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
   ```

> ⚠️ `init=yes` 会**立即触发一次流水线**，生产环境必须审批。

### 方式 B：纯 GitOps

从模板 ConfigMap 读取 `data.template` 生成 PipelineRun 文件，按 `prName` 命名放入 `.tekton/`，然后走 7 步工作流提交。

## 删除分支环境

1. 从 Repository CR 移除 `branchEnvs` 中对应条目：
   ```bash
   kubectl patch repository <app> -n <ns> --type=json -p '[{"op":"remove","path":"/spec/branchEnvs/<index>"}]'
   ```
   > 全部移除时保持空数组 `[]`，避免序列化为 `null` 导致校验失败。

2. 在主分支 `git rm .tekton/{prName}.yaml`，commit（PacCommitMessage），push。
3. 确认流水线不再触发。

## 手动触发

```bash
# 无 init 参数
curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

前提：对应 `branchEnvs[].autoTrigger=false`（手动模式）。触发后查询：

```bash
kubectl get pipelineruns -n <ns> --sort-by=.metadata.creationTimestamp   # PipelineRun 位于 Repository 所在的项目命名空间
```

## 切换触发模式（自动 ↔ 手动）

- `autoTrigger=false`（**默认**）→ **手动触发**：push 不触发，需手动调 `/manual` 或 Console Run Pipeline。
- `autoTrigger=true` → **自动触发**：push 代码到分支即触发流水线。

```bash
# 默认手动触发；切为自动触发（0 为第一个 branchEnv 下标，按需替换）
kubectl patch repository <app> -n <ns> --type=json -p '[{"op":"replace","path":"/spec/branchEnvs/0/autoTrigger","value":true}]'
```

> 注意：`autoTrigger=false`（手动模式）且从未触发过时，`.tekton/{prName}.yaml` 可能尚不存在，需先调 `/manual?init=yes` 生成再手动触发。