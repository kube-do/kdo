# 分支流水线编辑（GitOps 工作流）

KDO 流水线以 **Git 为唯一事实来源**：编辑 `.tekton/` 下的 PipelineRun 文件并 push，再手动触发（**PAC 默认手动触发**，push 不会自动执行）。**禁止** `kubectl apply` 直接修改 PipelineRun CR（会绕过 Git 溯源，且修改会被覆盖）。

## 7 步工作流

### ① 定位仓库

```bash
kubectl get repository <app> -n <ns> -o yaml
```

关键字段：`spec.url`（Git 地址）、`spec.git_provider.type`、`spec.git_provider.secret.name`（Token Secret 名）、`spec.branchEnvs`（分支环境列表）、`spec.devInfo.devLanguage`。

### ② 认证（可选）

Che 工作区已配置 Git 凭据，push 无需额外认证。仅当 push 报认证失败时，才从 Secret 取 Token 配置远端 URL：

```bash
TOKEN=$(kubectl get secret <app>-token -n <ns> -o jsonpath='{.data.provider\.token}' | base64 -d)
git remote set-url origin "https://oauth2:${TOKEN}@<git-host>/<owner>/<repo>.git"
```

> Token 只进入当前 shell 环境变量，**不回显、不进日志、不写入任何文件**。如遇权限不足请直接提示用户联系项目管理员。

### ③ 进入本地仓库（无需重新 clone）

本技能运行于 **Eclipse Che 工作区**，仓库已由 devfile 检出到本地，直接使用当前工作目录，**无需重新 `git clone`**：

```bash
git remote -v               # 确认当前目录是目标仓库
git branch --show-current   # 确认当前分支
git status                  # 工作区状态
```

> 仅当本地没有该仓库时（如补充场景）才需 clone：`git clone "<git-url>"`。

### ④ 定位目标文件与所在分支

**文件↔分支↔操作对照**：

| 操作目标 | 文件 | 所在分支 | 操作 |
|---------|------|---------|------|
| 编辑流水线 | `.tekton/{prName}.yaml` | **`spec.branchEnvs[].branchName` 分支** | 先 `git checkout` 切分支 |
| 修改构建配置 | `docker/Dockerfile` | **`spec.branchEnvs[].branchName` 分支** | 先 `git checkout` 切分支 |
| 修改部署清单 | `kubernetes/*.yaml` | **`spec.branchEnvs[].branchName` 分支** | 先 `git checkout` 切分支 |

> `.tekton/{prName}.yaml`、`docker/Dockerfile`、`kubernetes/` 均位于 branchName 分支；仅 `devfile.yaml` 在主分支（其 `metadata.appProject` 即该应用所属项目 / AppProject，也是 Repository CR 所在 namespace）。**编辑流水线或构建/部署清单前，都必须先切到对应分支**。**修改部署清单前必须先按原则「部署清单先验证后同步」在实际 K8s 环境验证**（详见 `07-troubleshooting.md`）：

```bash
git branch --show-current        # 确认当前分支
git fetch origin <branchName>    # 编辑 .tekton/、docker/Dockerfile 或 kubernetes/ 前切到 branchName 分支
git checkout <branchName>
# ...编辑 .tekton/{prName}.yaml、docker/Dockerfile 或 kubernetes/...
git push origin <branchName>     # 提交回该分支（该分支环境流水线需手动触发）
```

> **若应用依赖中间件（数据库/缓存等）**：同步部署清单前，必须先验证目标环境中中间件**是否存在、数据是否已初始化、账户密码是否正确**；全部通过后方可更新 Git；任一失败**立即中止**，排查后重新验证。详见 `07-troubleshooting.md`。

文件名规则：`.tekton/{appName}-{appEnv}-{branchKey(branch)}.yaml`（即 Repository `spec.branchEnvs[].prName`，请以 CR 中实际 `prName` 为准）

**branchKey(分支名)** 规则（先规范化，冲突才加 hash）：
1. **规范化 base**：
   1. 转小写
   2. 去除首尾空白
   3. 去除除字母、数字、空格、下划线、连字符以外的字符
   4. 将连续的空格/下划线/连字符统一替换为单个连字符 `-`
   5. 去除首尾连字符
   6. 截断为 9 个码点（≤9 个字符）
2. **冲突消歧**：同一 `appEnv` 下若有 **≥2 个不同分支名**的 base 相同，则这些分支的 key 统一追加 `-` + 6 位 FNV-1a hash（取分支原始名的低 24 位十六进制）；无冲突时直接用 base。

> 等价实现（Go）：`provider.BranchKeys([]BranchEnv)`；前端：`resolveBranchKeys(branchEnvs)`。可按此校验生成的文件名是否与 `prName` 一致。

例：app=`my-app`、env=`dev`、分支 `develop`（无冲突）→ 文件 `my-app-dev-develop.yaml`；若同环境另有 `develop-2` 等使 base 冲突 → 文件名会形如 `my-app-dev-develop-a46871.yaml`。

> 更可靠的方式：直接从 `spec.branchEnvs[].prName` 精确取文件名。

```bash
git ls-tree -r HEAD --name-only | grep '\.tekton'   # 查看所有流水线文件
```

### ⑤ 编辑 PipelineRun YAML

可修改内容：`params`（构建参数、镜像 Tag）、`taskRef`（resolver: cluster，namespace=kubedo）、`workspaces`、`annotations`（触发条件）。**不要改 PipelineRun 的 name/metadata。**

### ⑥ 校验

```bash
python3 -c "import yaml; yaml.safe_load(open('.tekton/my-app-dev-develop.yaml'))"
kubectl apply --dry-run=client -f .tekton/my-app-dev-develop.yaml
```

### ⑦ 提交与推送

```bash
git add .
git commit -m "Added or updated files for tekton pipeline."
git push
```

> **commit message 必须为 `Added or updated files for tekton pipeline.`**（PAC 的 PacCommitMessage），否则会再次触发流水线循环。
>
> ⚠️ **触发流水线必须经用户审批**；生产环境（prod）变更需额外做影响评估。默认手动触发：优先在 Console 点击 Run Pipeline；终端直连 PAC `/manual` 时必须带 `Authorization: Bearer <token>`（见 `03-pipelines-pac.md` 的「手动触发与鉴权」）。
>
> 审批针对的是**构建**。构建成功后，写回提交会由平台自动部署，不需要再确认一次；要阻止部署只能不构建，或回退清单提交。

## 新增分支环境

### 方式 A：CR 触发 init（推荐）

1. **收集三要素让用户选择**：
   ```bash
   git branch -r                                                     # 分支列表
   kubectl get appenv -n <ns> -o name                                # 目标环境
   kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang> -o name  # 流水线模板（prTemplate 来源）
   ```

2. **patch Repository CR** 追加 `branchEnvs` 条目：
   ```yaml
   - branchName: <branch>
     appEnv: <env>                  # 部署目标环境
     cluster: <cluster>
     prName: .tekton/<app>-<env>-<branchKey(branch)>.yaml
     prTemplate: <模板 ConfigMap 名>
     onEvent: ["push"]
     autoTrigger: false           # 默认 false（手动）
   ```

3. **触发 init**（生成 .tekton 文件）：
   ```bash
   USER_TOKEN=<your-kubernetes-bearer-token>
   curl -X POST -H "Authorization: Bearer ${USER_TOKEN}" \
     "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?init=yes&cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>"
   ```

> ⚠️ `init=yes` **只生成/刷新仓库文件，不创建 PipelineRun**；它会向仓库提交文件，生产分支仍需审批。

### 方式 B：纯 GitOps

从模板 ConfigMap 读取 `data.template` 生成 PipelineRun 文件，按 `prName` 命名放入 `.tekton/`，然后走 7 步工作流提交。

## 删除分支环境

1. 从 Repository CR 移除 `branchEnvs` 中对应条目：
   ```bash
   kubectl patch repository <app> -n <ns> --type=json -p '[{"op":"remove","path":"/spec/branchEnvs/<index>"}]'
   ```
   > 全部移除时保持空数组 `[]`，避免序列化为 `null` 导致校验失败。

2. 切到该 branchName 分支 `git rm .tekton/{prName}.yaml`，commit（PacCommitMessage），push；该分支后续事件中 PAC 也会自动清理多余的 `.tekton` 文件。
3. 确认流水线不再触发。

## 手动触发

```bash
USER_TOKEN=<your-kubernetes-bearer-token>
# 无 init 参数
curl -X POST -H "Authorization: Bearer ${USER_TOKEN}" \
  "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>"
```

前提：对应 `branchEnvs[].autoTrigger=false`（手动模式）。触发后查询：

```bash
kubectl get pipelineruns -n <ns> --sort-by=.metadata.creationTimestamp   # PipelineRun 位于 Repository 所在的项目命名空间
```

> 这里触发的是**构建**。部署会在构建成功且写回产生变更后由 controller 自动创建，不需要手动触发。

## 手动部署与回滚

部署运行通常由 controller 自动创建。只有以下情况才需要手动触发：

- **回滚**到历史版本：Console 的「发布历史」选版本 → 确认 → 提交清单（提交标题以 `[kubedo-writeback]` 开头），Console 会自动调用下面的接口让新提交立即部署；
- 清单在集群里被手工改过，需要重新对齐 Git 中的版本；
- 构建没有产生写回（`changed=false`），但需要重新 apply 一次。

```bash
USER_TOKEN=<your-kubernetes-bearer-token>
# 只创建部署运行，不跑构建
curl -X POST -H "Authorization: Bearer ${USER_TOKEN}" \
  "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>&deploy=yes"

# `deploy=yes` 始终部署该分支 HEAD；要部署历史版本，先在 Console 发布历史回滚（会生成新的 HEAD 提交）
```

- `deploy=yes` 与 `init=yes` 互斥，**两者同时出现时以 `init=yes` 为准**（先判断 init）。
- 部署运行名为 `<repo>-<appEnv>-<branchKey>-deploy-<提交 sha 前 8 位>`，revision 就是这个提交，所以部署的内容与 Git 完全对应。
- 同一分支重复触发是幂等的（同名运行已存在就跳过）；新的部署运行创建时，该分支尚未完成的旧部署运行会被取消。
- 清单里的镜像**必须带 tag**。分支从未成功构建过时，清单里是不带 tag 的初始镜像，部署会被拒绝并提示「先运行构建」。

```bash
kubectl get pipelinerun -n <ns> | grep -- "-deploy-"
kubectl logs -n <ns> -l tekton.dev/pipelineRun=<deploy-run> --tail=50   # 看 apply 步骤
```

## 切换触发模式（自动 ↔ 手动）

- `autoTrigger=false`（**默认**）→ **手动构建**：push 不触发，需手动调 `/manual` 或 Console Run Pipeline。
- `autoTrigger=true` → **push 即构建**。

```bash
# 默认手动触发；切为自动触发（0 为第一个 branchEnv 下标，按需替换）
kubectl patch repository <app> -n <ns> --type=json -p '[{"op":"replace","path":"/spec/branchEnvs/0/autoTrigger","value":true}]'
```

> 该开关**只影响构建**，部署始终由构建成功后自动触发。

> 注意：`autoTrigger=false`（手动模式）且从未触发过时，`.tekton/{prName}.yaml` 可能尚不存在，需先在 Console 触发初始化（或调 `/manual?init=yes` 并带 `Authorization: Bearer <token>`）生成再手动触发。