# 分支流水线编辑（GitOps 工作流）

KDO 流水线以 **Git 为唯一事实来源**：编辑 `.tekton/` 下的 PipelineRun 文件并 push，PAC 自动触发。**禁止** `kubectl apply` 直接修改 PipelineRun CR（会绕过 Git 溯源，且修改会被覆盖）。

## 7 步工作流

### ① 定位仓库

```bash
kubectl get repository <app> -n <ns> -o yaml
```

关键字段：`spec.url`（Git 地址）、`spec.git_provider.type`、`spec.git_provider.secret.name`（Token Secret 名）、`spec.branchEnvs`（分支环境列表）、`spec.devInfo.devLanguage`。

### ② 获取 Git Token（绝不回显）

```bash
TOKEN=$(kubectl get secret <token-secret> -n <ns> -o jsonpath='{.data.provider\.token}' | base64 -d)
```

> Token 只进入当前 shell 环境变量，**不回显、不进日志、不写入任何文件**。如遇权限不足请直接提示用户联系项目管理员。

### ③ 克隆仓库

```bash
git clone "https://oauth2:${TOKEN}@<git-host>/<owner>/<repo>.git"
```

### ④ 定位流水线文件

文件名规则：`.tekton/{appName}-{appEnv}-{sanitize(branch)}.yaml`

**sanitize(分支名)** 规则：
1. 转小写
2. 去首尾空白
3. 去除所有非字母数字字符
4. 空格/下划线/连字符合并为一个连字符
5. 去除首尾连字符
6. 截断为 9 个字符

例：分支 `feature/develop` → `develop` → 文件 `my-app-dev-develop.yaml`。

> 更可靠的方式：直接从 `spec.branchEnvs[].prName` 精确取文件名。

```bash
git ls-tree -r HEAD --name-only | grep .tekton   # 查看所有流水线文件
```

### ⑤ 编辑 PipelineRun YAML

可修改内容：`params`（构建参数、镜像 Tag）、`taskRef`（resolver: cluster，namespace=kubedo）、`workspaces`、`annotations`（触发条件）。**不要改 PipelineRun 的 name/metadata。**

### ⑥ 校验

```bash
python3 -c "import yaml; yaml.safe_load(open('.tekton/my-app-dev-develop.yaml'))"
kubectl apply --dry-run=client -f .tekton/my-app-dev-develop.yaml
```

### ⑦ 提交与推送

```bash
git add .
git commit -m "Added or updated files for tekton pipeline."
git push
```

> **commit message 必须为 `Added or updated files for tekton pipeline.`**（PAC 的 PacCommitMessage），否则会再次触发流水线循环。
>
> ⚠️ push 会触发流水线执行。**必须经用户审批**；生产环境（prod）变更需额外做影响评估。

## 新增分支环境

### 方式 A：CR 触发 init（推荐）

1. **收集三要素让用户选择**：
   ```bash
   git branch -r                                                     # 分支列表
   kubectl get appenv -n <ns> -o name                                # 目标环境
   kubectl get cm -n kubedo -l pipelinesascode.tekton.dev/devLanguage=<lang> -o name  # 模板
   ```

2. **patch Repository CR** 追加 `branchEnvs` 条目：
   ```yaml
   - branchName: <branch>
     appEnv: <env>                  # 部署目标环境
     cluster: <cluster>
     prName: .tekton/<app>-<env>-<sanitize(branch)>.yaml
     prTemplate: <模板 ConfigMap 名>
     onEvent: ["push"]
     manualTrigger: true            # 默认 true
   ```

3. **触发 init**（生成 .tekton 文件并执行一次）：
   ```bash
   WS=$(kubectl get secret <token-secret> -n <ns> -o jsonpath='{.data.webhook\.secret}' | base64 -d)
   curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?init=yes&cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
   ```

> ⚠️ `init=yes` 会**立即触发一次流水线**，生产环境必须审批。

### 方式 B：纯 GitOps

从模板 ConfigMap 读取 `data.template` 生成 PipelineRun 文件，按 `prName` 命名放入 `.tekton/`，然后走 7 步工作流提交。

## 删除分支环境

1. 从 Repository CR 移除 `branchEnvs` 中对应条目：
   ```bash
   kubectl patch repository <app> -n <ns> --type=json -p '[{"op":"remove","path":"/spec/branchEnvs/<index>"}]'
   ```
   > 全部移除时保持空数组 `[]`，避免序列化为 `null` 导致校验失败。

2. 在主分支 `git rm .tekton/{prName}.yaml`，commit（PacCommitMessage），push。
3. 确认流水线不再触发。

## 手动触发

```bash
# 无 init 参数
curl -X POST "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>&webhookSecret=${WS}"
```

前提：对应 `branchEnvs[].manualTrigger=true`。触发后查询：

```bash
kubectl get pipelineruns -n <ns> --sort-by=.metadata.creationTimestamp
```