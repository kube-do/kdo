# 问题排查

针对开发者高频故障：流水线（PAC）失败、Pod 异常、Che 工作区问题。

## 流水线失败排查

### 从外到内的排查顺序

```bash
# 1. PAC 组件健康
kubectl get pods -n pipelines-as-code
kubectl logs -n pipelines-as-code -l app=controllers   # 接收 webhook、创建 PipelineRun
kubectl logs -n pipelines-as-code -l app=watchers      # 报告结果、清理旧运行
kubectl get cm -n pipelines-as-code pipelines-as-code-info

# 2. Repository 状态
kubectl describe repository <app> -n <ns>

# 3. 事件（PAC 会发 PacNewRepoMatch/PacPipelineRunCreation 等）
kubectl get events -n <ns> --sort-by='.lastTimestamp' | tail -30

# 4. PipelineRun（位于 Repository 所在的项目命名空间 <ns>）
kubectl get pipelineruns -n <ns> --sort-by=.metadata.creationTimestamp

# 5. TaskRun 与容器日志
kubectl get taskrun -n <ns> -l tekton.dev/pipelineRun=<pr> -o custom-columns=NAME:.metadata.name,STATUS:.status.conditions[0].reason,MESSAGE:.status.conditions[0].message
kubectl logs <taskrun-pod> -n <ns> --tail=100
```

### 故障卡点定位

| 现象 | 定位组件 | 检查项 |
|------|---------|--------|
| Webhook 到达但无反应 | **Controller** | Controller 日志（app=controllers） |
| 有事件但没创建 PipelineRun | 注解/模板 | 注解匹配（on-event/on-target-branch）、模板变量解析 |
| PipelineRun 创建但无结果上报 | **Watcher** | Watcher 日志（app=watchers）、Token 写权限 |
| 运行中失败 | **TaskRun** | TaskRun Pod 日志 |
| 构建成功但没有部署运行 | **Controller 触发逻辑** | 见「构建成功但没有创建部署运行」 |

## 常见错误表

| 错误 | 原因 | 处理 |
|------|------|------|
| Webhook 未触发 | Webhook 配置错误 | 检查 URL 是否与 Git 仓库完全一致（含 `.git` 后缀） |
| 仓库匹配失败 | Repository CR 的 `url` 不一致 | 修正为完整 URL |
| 注解匹配失败 | `.tekton` 触发注解不匹配 | 检查 `on-event`/`on-target-branch` |
| 模板变量解析失败 | `{{ var }}` 名称错误 | 对照 `03-pipelines-pac.md` 变量表 |
| git clone 失败 | Token 过期/权限不足 | 重新生成 Token（`provider.token`） |
| npm 构建退出码 1 | 依赖或脚本错误 | 查看 TaskRun 日志 |
| buildah 构建失败 | Dockerfile 路径 / Harbor 凭证 | 检查路径与 registry Secret |
| ImagePullBackOff | 镜像不存在/私有仓库凭证缺失 | 见 Pod 问题 |
| Pending | 节点资源/PVC/配额 | 见 Pod 问题 |
| access denied | Token 过期、GitHub App 过期 | 提示用户重新登录 KDO 刷新 Token |
| PipelineRun 创建无状态上报 | Watcher 异常/Token 写权限 | 检查 Watcher 日志 |
| 构建成功但无部署运行 | 写回无变更、触发 RBAC 不足、部署模板缺失 | 见下一节 |
| 部署提示清单镜像没有 tag | 该分支从未成功构建写回 | 先跑一次构建，再看写回提交 |
| `/manual` 返回 401 | 缺少/无效/过期的用户 Token | 重新获取 Token；确认传递的是 `Authorization: Bearer <token>` |
| `/manual` 返回 403 | 用户缺少项目 `create pipelineruns` 或环境 `patch deployments` 权限 | 检查项目/环境 RoleBinding；响应 message 会给出具体命名空间和原因 |
| `/manual` 返回 503 | PAC 无法访问 API Server，或 controller SA 缺少 `selfsubjectreviews`/`selfsubjectaccessreviews` 的 create 权限 | 检查 controller 日志与 ClusterRole；见 `03-pipelines-pac.md` 的「PAC 权限与安装检查」 |
| `/manual` 返回 400/404 | 仓库、分支或环境不匹配 | 核对 Repository 的 `branchEnvs`，以及 `namespace`/`repository`/`branch`/`appEnv` |
| GitHub/Gitea 手动触发无运行 | 旧版签名/事件头问题 | 升级到已修复版本（HMAC 签名 + `X-Gitea-Event-Type` + 分支名规范化） |

## 构建成功但没有创建部署运行

从构建成功到部署运行，链路是：

```
构建 PipelineRun Succeeded
  → controller 读取 gitops-writeback 的任务结果（changed / commit-sha）
  → 创建 <repo>-<appEnv>-<branchKey>-deploy-<sha8>
  → fetch-repository(revision=写回 sha) → prepare-kubeconfig → show-diff → apply
```

部署**不经过 Git webhook**：即使仓库没配 webhook，构建成功也会部署。构建成功却看不到部署运行，按下面顺序查。

### 1. 写回任务是否成功、是否真改了东西

```bash
kubectl get taskrun -n <ns> -l tekton.dev/pipelineRun=<build-run> \
  -l tekton.dev/pipelineTask=gitops-writeback \
  -o jsonpath='{range .items[*].status.results[*]}{.name}={.value}{"\n"}{end}'
```

- `changed=false`：镜像和清单里的一致，**不会部署**（正常行为）；
- 没有 `gitops-writeback` 任务：说明这个仓库的 `.tekton` 还是旧模板（内联部署），需要让流水线文件按新模板重新生成；
- `commit-sha` 里带空格或换行：老版本写回 Task 的 bug，重新跑一次构建即可（新 Task 已 `tr -d '\n'`）。

### 2. Controller 是否报错

```bash
kubectl logs -n pipelines-as-code deploy/pipelines-as-code-watcher --tail=200 | grep -i "deploy pipelineRun"
kubectl logs -n pipelines-as-code deploy/pipelines-as-code-controller --tail=200 | grep -i "gitops"
```

| 日志 | 含义 | 处理 |
|------|------|------|
| `pipelineruns.tekton.dev is forbidden` | watcher 的 SA 没有 `create` 权限 | 联系管理员给 ClusterRole 加 `create`（自检：`kubectl auth can-i create pipelineruns -n <ns> --as=system:serviceaccount:pipelines-as-code:pipelines-as-code-watcher`） |
| `no branch environment matches cluster ... appEnv ...` | 运行名与 `spec.branchEnvs` 对不上 | 检查 Repository 的 `branchEnvs`（分支/环境/集群） |
| 无任何相关日志 | 该运行不是 PAC 管理的构建 | 确认运行带 `pipelinesascode.tekton.dev/state` 注解 |

### 3. 部署模板是否存在

```bash
kubectl get cm -n kubedo pipelinerun-gitops-deploy   # 或 Repository 里 settings.gitops.deployTemplate 指定的名字
```

模板缺失时 controller **只记日志并跳过**，不会让构建失败，所以很容易漏看。

### 4. 部署运行创建了却失败

```bash
kubectl get pipelinerun -n <ns> | grep -- "-deploy-"
kubectl logs -n <ns> <deploy-run>-apply-pod --tail=100    # apply 步骤日志
```

| 报错 | 原因 |
|------|------|
| `清单中的镜像 ... 没有 tag` | 该分支还没成功构建过，清单里仍是 `image: <repo>` 无 tag；先构建 |
| `no such file`（`kubernetes/deploy-*.yaml`） | 分支上缺少部署清单 |
| `Unauthorized` / `forbidden` | 目标集群 kubeconfig 未就绪或 RBAC 不足（见 `03-pipelines-pac.md` 的 `prepare-kubeconfig`） |

### 5. 需要立即重新部署

构建产物没变、只想把当前清单再 apply 一次（或回滚到某个历史版本）时，用 `deploy=yes` 手动创建部署运行：

```bash
USER_TOKEN=<your-kubernetes-bearer-token>
curl -X POST -H "Authorization: Bearer ${USER_TOKEN}" \
  "http://pipelines-as-code-controller.pipelines-as-code.svc:8080/manual?cluster=<cluster>&namespace=<ns>&repository=<app>&branch=<branch>&appEnv=<env>&deploy=yes"
```

部署运行按 `<repo>-<env>-<branchKey>-deploy-<sha8>` 命名，同一提交重复调用不会创建第二个。

## 部署清单调整流程（先 K8s 验证，后 Git 同步）

所有对部署清单的调整，必须**先在实际 Kubernetes 环境中验证，验证通过并经用户确认后，方可同步至 Git 仓库**。

### 调整应用部署清单（Deployment/Service 等）

先在集群中修改资源并验证功能正常，验证通过后再更新 Git 仓库中的清单文件：

```bash
kubectl edit deployment/<app> -n <ns>                    # 镜像/副本/资源限制/环境变量
kubectl edit service <app> -n <ns>                       # 服务端口/类型
kubectl rollout status deployment/<app> -n <ns>          # 等待就绪
```

验证点：Pod Ready、探针通过、日志正常、访问正常。

### 应用依赖配置文件（ConfigMap/Secret）

先在 K8s 创建并挂载这些配置进行验证，验证通过后再将配置定义同步到 Git 仓库的部署清单中：

```bash
kubectl edit configmap <name> -n <ns>                    # 配置修改
kubectl edit secret <name> -n <ns>                       # 密码修改
kubectl rollout restart deployment/<app> -n <ns>         # 挂载修改后重启生效
```

配置/密码通过 **ConfigMap/Secret 挂载**进容器（卷挂载或 envFrom），修改后重启 Pod 生效。**配置统一走 ConfigMap/Secret 管理，避免将配置硬编码进镜像或 `.tekton/` 流水线——否则每次改配置都需重新构建镜像并运行流水线。**

### 应用依赖中间件（数据库/缓存等）

先检查目标环境，全部验证通过后再更新 Git 仓库中的部署清单：

```bash
kubectl get deploy,sts,svc -n <ns> | grep <middleware>   # 中间件是否存在
kubectl get pvc -n <ns>                                  # 数据卷/初始化状态
kubectl get secret <db-secret> -n <ns>                   # 账户密码 Secret
```

检查点：中间件存在、数据已初始化、账户密码正确。

### 验证失败中止

任一验证步骤失败，**立即中止更新流程**，排查问题后重新验证。

> 流水线文件（`.tekton/`）编辑仍走 GitOps（进入本地仓库 → 改 → push → 手动触发）；本流程仅用于部署清单/应用运行/配置问题的调整。回写 Git 时同步到 `spec.branchEnvs[].branchName` 分支的 `docker/`、`kubernetes/`、配置清单，commit（PacCommitMessage）+ push，保持 Git 为最终真源。

## Pod 问题速查

### CrashLoopBackOff

退出码含义：

| 退出码 | 含义 | 处理 |
|--------|------|------|
| 0 | 正常退出 | 检查存活探针配置 |
| 1 | 应用错误 | 查看日志 |
| 137 | OOM 被杀 | 见 OOMKilled |
| 139 | 段错误 | 应用崩溃，检查核心转储 |
| 143 | SIGTERM | 被终止，检查 Deployment 变更 |

```bash
kubectl logs <pod> --previous    # 查看上一次崩溃日志
```

### OOMKilled

```bash
kubectl top pod <pod> -n <ns>
kubectl describe pod <pod> -n <ns> | grep -A2 Limits   # 确认内存限制
kubectl get events -n <ns> | grep OOMKilling
# 调大限制（示例 512Mi/256Mi）
kubectl set resources deployment/<app> --limits=memory=512Mi --requests=memory=256Mi
```

### ImagePullBackOff

```bash
kubectl describe pod <pod> -n <ns> | grep -A10 Events
```

常见原因：镜像不存在 / 缺 `regcred` Secret / ServiceAccount 未关联 registry Secret。

> **预防**：创建 Pod / 修改容器镜像前先预检，避免 ImagePullBackOff：
> ```bash
> skopeo list-tags docker://<image-repo>   # 确认目标 tag 在 Tags 列表中
> # 私有仓库镜像需先确认当前环境有拉取凭证
> ```

### Pending

```bash
kubectl describe pod <pod> -n <ns>   # 看 Events 的 FailedScheduling
```

常见原因：节点资源不足 / nodeSelector 或 taint 不匹配 / PVC 未绑定 / 命名空间配额超限。

### CreateContainerConfigError

缺少 ConfigMap / Secret 引用。

## Token 过期处理

提示用户：
1. 重新登录 KDO 平台
2. 重新访问 CloudShell（触发 Token 刷新）
3. 若持续失败，联系平台管理员检查 Token 绑定

> 涉及删除、生产变更、Secret/RBAC 修改时，先审批再执行。