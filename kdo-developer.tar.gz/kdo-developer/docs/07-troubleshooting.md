# 问题排查

针对开发者高频故障：流水线（PAC）失败、Pod 异常、Che 工作区问题。

## 流水线失败排查

### 从外到内的排查顺序

```bash
# 1. PAC 组件健康
kubectl get pods -n pipelines-as-code
kubectl logs -n pipelines-as-code -l app=controllers   # 接收 webhook、创建 PipelineRun
kubectl logs -n pipelines-as-code -l app=watchers      # 报告结果、清理旧运行
kubectl get cm -n pipelines-as-code pipelines-as-code-info

# 2. Repository 状态
kubectl describe repository <app> -n <ns>

# 3. 事件（PAC 会发 PacNewRepoMatch/PacPipelineRunCreation 等）
kubectl get events -n <ns> --sort-by='.lastTimestamp' | tail -30

# 4. PipelineRun
kubectl get pipelineruns -n <ns> --sort-by=.metadata.creationTimestamp

# 5. TaskRun 与容器日志
kubectl get taskrun -n <ns> -l tekton.dev/pipelineRun=<pr> -o custom-columns=NAME:.metadata.name,STATUS:.status.conditions[0].reason,MESSAGE:.status.conditions[0].message
kubectl logs <taskrun-pod> -n <ns> --tail=100
```

### 故障卡点定位

| 现象 | 定位组件 | 检查项 |
|------|---------|--------|
| Webhook 到达但无反应 | **Controller** | Controller 日志（app=controllers） |
| 有事件但没创建 PipelineRun | 注解/模板 | 注解匹配（on-event/on-target-branch）、模板变量解析 |
| PipelineRun 创建但无结果上报 | **Watcher** | Watcher 日志（app=watchers）、Token 写权限 |
| 运行中失败 | **TaskRun** | TaskRun Pod 日志 |

## 常见错误表

| 错误 | 原因 | 处理 |
|------|------|------|
| Webhook 未触发 | Webhook 配置错误 | 检查 URL 是否与 Git 仓库完全一致（含 `.git` 后缀） |
| 仓库匹配失败 | Repository CR 的 `url` 不一致 | 修正为完整 URL |
| 注解匹配失败 | `.tekton` 触发注解不匹配 | 检查 `on-event`/`on-target-branch` |
| 模板变量解析失败 | `{{ var }}` 名称错误 | 对照 `03-pipelines-pac.md` 变量表 |
| git clone 失败 | Token 过期/权限不足 | 重新生成 Token（`provider.token`） |
| npm 构建退出码 1 | 依赖或脚本错误 | 查看 TaskRun 日志 |
| buildah 构建失败 | Dockerfile 路径 / Harbor 凭证 | 检查路径与 registry Secret |
| ImagePullBackOff | 镜像不存在/私有仓库凭证缺失 | 见 Pod 问题 |
| Pending | 节点资源/PVC/配额 | 见 Pod 问题 |
| access denied | Token 过期、GitHub App 过期 | 提示用户重新登录 KDO 刷新 Token |
| PipelineRun 创建无状态上报 | Watcher 异常/Token 写权限 | 检查 Watcher 日志 |

## Pod 问题速查

### CrashLoopBackOff

退出码含义：

| 退出码 | 含义 | 处理 |
|--------|------|------|
| 0 | 正常退出 | 检查存活探针配置 |
| 1 | 应用错误 | 查看日志 |
| 137 | OOM 被杀 | 见 OOMKilled |
| 139 | 段错误 | 应用崩溃，检查核心转储 |
| 143 | SIGTERM | 被终止，检查 Deployment 变更 |

```bash
kubectl logs <pod> --previous    # 查看上一次崩溃日志
```

### OOMKilled

```bash
kubectl top pod <pod> -n <ns>
kubectl describe pod <pod> -n <ns> | grep -A2 Limits   # 确认内存限制
kubectl get events -n <ns> | grep OOMKilling
# 调大限制（示例 512Mi/256Mi）
kubectl set resources deployment/<app> --limits=memory=512Mi --requests=memory=256Mi
```

### ImagePullBackOff

```bash
kubectl describe pod <pod> -n <ns> | grep -A10 Events
```

常见原因：镜像不存在 / 缺 `regcred` Secret / ServiceAccount 未关联 registry Secret。

### Pending

```bash
kubectl describe pod <pod> -n <ns>   # 看 Events 的 FailedScheduling
```

常见原因：节点资源不足 / nodeSelector 或 taint 不匹配 / PVC 未绑定 / 命名空间配额超限。

### CreateContainerConfigError

缺少 ConfigMap / Secret 引用。

## Token 过期处理

提示用户：
1. 重新登录 KDO 平台
2. 重新访问 CloudShell（触发 Token 刷新）
3. 若持续失败，联系平台管理员检查 Token 绑定

> 涉及删除、生产变更、Secret/RBAC 修改时，先审批再执行。