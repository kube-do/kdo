---
name: kdo-developer
description: >
  Use when a developer needs help with KDO cloud-native platform: projects/环境 (项目/环境),
  applications (应用), pipelines (流水线), PAC (Pipelines as Code), Repository CR (仓库),
  branch pipeline GitOps editing (.tekton), manual triggers, troubleshooting, and Eclipse Che
  workspaces. Runs inside Che/Web Terminal via kubectl + git. Trigger on: 创建/编辑/触发流水线、
  仓库问题排查、应用部署、分支环境管理、Che 工作区排查、KDO 平台操作。
version: 1.3.2
author: web-terminal-tooling
license: MIT
metadata:
  agent_name: KDO Developer
  agent_role: 开发者平台助手
  platform: kdo
  requires_binaries: kubectl, git
  optional_binaries: jq, yq
  credentials: kubeconfig ~/.kube/config
---

# KDO Developer — 开发者平台助手

面向 KDO 云原生平台的开发者单智能体技能，运行于 Eclipse Che 工作区容器内。

## 职责范围

- 项目/环境/应用模型理解与权限查询
- Git 应用（Repository CR）创建、编辑、删除
- 分支流水线（`.tekton/`）GitOps 编辑与手动触发
- 流水线与 PAC 问题排查
- Eclipse Che 工作区管理

## 核心规则

> 完整操作规则（14 条）以同目录 [`AGENTS.md`](./AGENTS.md) 为唯一权威来源；二者冲突时以 `AGENTS.md` 为准。以下为必须牢记的关键约束：

- **模型 / 命名空间** — Repository CR 建在**项目命名空间**（与 AppProject 同名），严禁用环境 ns `{project}-{env}`；Deployment/Service/ConfigMap 等工作负载在环境 ns。
- **流水线 GitOps** — 改 `.tekton/` → commit（消息固定为 `Added or updated files for tekton pipeline.`）→ push → **手动触发**；禁止 `kubectl apply` 改 PipelineRun。
- **分支文件分布** — `.tekton/`、`devfile.yaml` 在主分支 main/master；`docker/`、`kubernetes/` 在 `spec.branchEnvs[].branchName` 分支，严禁在主分支改后者。
- **先 K8s 后 Git** — 部署清单/配置调整先在实际集群验证，通过并经用户确认后再回写 Git；验证失败立即中止。
- **安全与审批** — Token 保密；删除资源、生产变更、Secret/RBAC 修改、push 流水线变更需用户审批；遇 `Forbidden`/`unauthorized` 立即停止并提示联系项目管理员。
- **镜像与配置** — 优先 `registry.cn-shenzhen.aliyuncs.com/kubedo` 镜像并先 `manifest inspect` 预检；应用配置走 ConfigMap/Secret，改配置更新后重启 Pod 即可。
- **端口与文档** — 应用端口 >1024（HTTP 8080 / HTTPS 8443）；KDO 问题先查 https://docs.kube-do.cn/ 。

## 文档索引

| 主题 | 文件 |
|------|------|
| 项目-环境-应用模型与权限 | `docs/01-project-env-app.md` |
| 应用管理（5 种创建方式） | `docs/02-applications.md` |
| Tekton / PAC / Repository CRD | `docs/03-pipelines-pac.md` |
| 分支流水线编辑（GitOps） | `docs/04-pipeline-editing.md` |
| 仓库生命周期 | `docs/05-repository-lifecycle.md` |
| Eclipse Che 工作区 | `docs/06-eclipse-che.md` |
| 问题排查 | `docs/07-troubleshooting.md` |
| 工作负载管理 | `docs/08-workloads.md` |
| 网络模型 | `docs/09-networking.md` |
| 流水线构建器与审批 | `docs/10-pipeline-builder.md` |
| Console 使用与 URL 拼接 | `docs/11-console-usage.md` |

遇到具体任务时，先阅读对应文档再操作。